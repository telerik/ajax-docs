using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Telerik.Web.Examples.ToolTip.WebService
{

    public partial class CustomerInfo : System.Web.UI.UserControl
    {
        public object Data;

        protected void Page_Load(object sender, EventArgs e)
        {
            Repeater1.DataSource = Data;
            Repeater1.DataBind();
            label.Text = "Time of the request: " + DateTime.Now.ToString();
        }
    }
}