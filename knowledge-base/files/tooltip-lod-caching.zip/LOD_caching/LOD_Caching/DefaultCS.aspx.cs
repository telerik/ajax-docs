using System;
using System.Collections;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Telerik.Web.UI;
using System.Configuration;

namespace Telerik.Web.Examples.ToolTip.WebService
{
    public partial class DefaultCS : System.Web.UI.Page
    {

        private void Page_Load(object sender, System.EventArgs e)
        {
        }

        protected void ItemsRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Control ctrl = e.Item.FindControl("smallImage");
            DataRowView rowView = (DataRowView)e.Item.DataItem;
            string val = rowView.Row["CustomerID"].ToString();
            if (!Object.Equals(ctrl, null))
            {
                string ID = (sender as Repeater).ID;
                switch (ID)
                {
                    case "Repeater1":
                        this.RadToolTipManager1.TargetControls.Add(ctrl.ClientID, val, true);
                        break;
                    case "Repeater2":
                        this.RadToolTipManager2.TargetControls.Add(ctrl.ClientID, val, true);
                        break;
                    case "Repeater3":
                        this.RadToolTipManager3.TargetControls.Add(ctrl.ClientID, val, true);
                        break;
                    case "Repeater4":
                        this.RadToolTipManager4.TargetControls.Add(ctrl.ClientID, val, true);
                        break;
                }
            }

        }
        public DataTable GetToolTipData(string elementID)
        {
            DataTable information = new DataTable();

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString);
            try
            {
                conn.Open();

                SqlDataAdapter adapter = new SqlDataAdapter();

                try
                {
                    adapter.SelectCommand = new SqlCommand("SELECT * FROM [Customers] WHERE CustomerID=@id", conn);
                    adapter.SelectCommand.Parameters.AddWithValue("@id", elementID);
                    adapter.Fill(information);
                }
                finally
                {
                    if (!Object.Equals(adapter.SelectCommand, null)) adapter.SelectCommand.Dispose();
                }
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return information;
        }
        protected void OnAjaxUpdate(object sender, ToolTipUpdateEventArgs e)
        {
            CustomerInfo ctrl = Page.LoadControl("~/CustomerInfo.ascx") as CustomerInfo;
            ctrl.Data = GetToolTipData(e.Value);
            e.UpdatePanel.ContentTemplateContainer.Controls.Add(ctrl);
        }
    }
}