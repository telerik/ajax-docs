﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

    public class PromptTemplate : ITemplate
    {
        private Page _page;

        public PromptTemplate(Page page)
        {
            this._page = page;
        }

        void ITemplate.InstantiateIn(Control owner)
        {
            Control ctrl = _page.LoadControl("~/Controls/PromptTemplate.ascx");
            owner.Controls.Add(ctrl);
        }
    }

