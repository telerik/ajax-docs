﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public class ConfirmTemplate : ITemplate
{
	private Page _page;

	public ConfirmTemplate(Page page)
	{
		this._page = page;
	}

	void ITemplate.InstantiateIn(Control owner)
	{
		Control ctrl = _page.LoadControl("~/Controls/ConfirmTemplate.ascx");
		owner.Controls.Add(ctrl);
	}
}
