using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;
using System.Data.OleDb;

public partial class _Default : System.Web.UI.Page 
{
    //Declare a global DataTable dtTable
    public static DataTable dtTable;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Function to select one Radio Button at a time
         setGrdRadioButtonOnClick();

    }
    protected void RadGrid1_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
    {
        //Populate the Radgrid 
        OleDbConnection MyOleDbConnection = new OleDbConnection
          ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("~//App_Data//NWind.mdb"));
        //the database in the web application root  

        OleDbDataAdapter MyOleDbDataAdapter = new OleDbDataAdapter();

        dtTable = new DataTable();

        MyOleDbConnection.Open();
        try
        {

            string query = "SELECT CategoryID,CategoryName FROM Categories";
            MyOleDbDataAdapter.SelectCommand = new OleDbCommand(query, MyOleDbConnection);
            MyOleDbDataAdapter.Fill(dtTable);

            RadGrid1.DataSource = dtTable;
        }
        finally
        {
            MyOleDbConnection.Close();
        }

    }
    public void setGrdRadioButtonOnClick()
    {
       
        //Create a Radio Button object
        RadioButton radioButton;
        for (int i = 0; i < RadGrid1.Items.Count; i++)
        {
            //Find the Radio Button which was selected by the User
            radioButton = (RadioButton)RadGrid1.Items[i].FindControl("rdSelect");
            //Call the javascript function SelectMeOnly in the OnClick event
            radioButton.Attributes.Add("OnClick", "SelectMeOnly(" + radioButton.ClientID + ", " + "'RadGrid1'" + ")");

        }
    }
    protected void rdSelect_CheckedChanged(object sender, EventArgs e)
    {
        //Select the row whose RadioButton is selected
        ((sender as RadioButton).NamingContainer as GridItem).Selected = (sender as RadioButton).Checked;
    }
}
