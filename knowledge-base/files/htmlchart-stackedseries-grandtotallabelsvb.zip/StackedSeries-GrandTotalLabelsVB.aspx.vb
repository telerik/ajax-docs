﻿Imports System.Data

Partial Class GrandTotalLabelsVB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        RadHtmlChart1.DataSource = GetData()
        RadHtmlChart1.DataBind()
    End Sub
    Protected Function GetData() As DataTable
        Dim tbl As New DataTable()
        tbl.Columns.Add(New DataColumn("ID", GetType(Integer)))
        tbl.Columns.Add(New DataColumn("Year", GetType(String)))
        tbl.Columns.Add(New DataColumn("Gold", GetType(Integer)))
        tbl.Columns.Add(New DataColumn("Silver", GetType(Integer)))
        tbl.Columns.Add(New DataColumn("Bronze", GetType(Integer)))
        tbl.Columns.Add(New DataColumn("GrandTotal", GetType(Decimal)))

        tbl.Rows.Add(New Object() {1, "1988", 10, 12, 13, 0.00001})
        tbl.Rows.Add(New Object() {2, "1980", 8, 16, 17, 0.01})
        tbl.Rows.Add(New Object() {3, "1976", 6, 9, 7, 0.01})

        Return tbl
    End Function

End Class
