﻿
Partial Class Default_Vb
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal args As EventArgs) Handles Me.Load
        RadFileExplorer1.Grid.ClientSettings.Scrolling.AllowScroll = True
        RadFileExplorer1.Grid.ClientSettings.Scrolling.EnableVirtualScrollPaging = True
        RadFileExplorer1.Grid.AllowCustomPaging = True
        RadFileExplorer1.Grid.PagerStyle.Visible = False
    End Sub

End Class
