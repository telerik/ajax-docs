﻿using System;
using Telerik.Web.UI;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.Services;
using System.Data;

namespace Protiviti.PAP.WebInterface.CoreWebUI
{
	public partial class test : System.Web.UI.Page
	{
		protected void Page_Init(object sender, EventArgs e)
		{
			RadHtmlChart1.DataSource = GetData();
			RadHtmlChart1.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			var relativePath = "~/api/export/file";

			RadClientExportManager1.PdfSettings.ProxyURL = ResolveUrl(relativePath);
			RadClientExportManager1.PdfSettings.Author = "Telerik ASP.NET AJAX";
		}

		protected DataTable GetData()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("ID", typeof(int));
			dt.Columns.Add("SoundPressureLevel", typeof(double));
			dt.Columns.Add("Frequency", typeof(double));
			dt.Rows.Add(1, 90, 15.6);
			dt.Rows.Add(2, 67, 31.2);
			dt.Rows.Add(3, 48, 62.5);
			dt.Rows.Add(4, 34, 125);
			dt.Rows.Add(5, 24, 250);
			dt.Rows.Add(6, 17, 500);
			dt.Rows.Add(7, 14, 1000);
			dt.Rows.Add(8, 18, 2000);
			dt.Rows.Add(9, 12, 4000);
			dt.Rows.Add(10, 30, 8000);
			dt.Rows.Add(11, 23, 12000);
			dt.Rows.Add(12, 40, 16000);
			return dt;
		}

	
	}
}