Imports System

Partial Public Class _Default
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
		Dim viewPaths As String() = New String() {"C:\PhysicalSource\ROOT", "\\Telerik.com\Path\SharedDir"}
		Dim uploadPaths As String() = New String() {"C:\PhysicalSource\ROOT\CanUpload", "C:\PhysicalSource\ROOT\CanUpload", "\\Telerik.com\Path\SharedDir\ROOT\Folder_11\CanDelAndUpload"}
		Dim deletePaths As String() = New String() {"C:\PhysicalSource\ROOT\Folder_1\CanDelete", "C:\PhysicalSource\ROOT\CanUpload", "C:\PhysicalSource\ROOT\Folder_11\CanDelAndUpload", "\\Telerik.com\Path\SharedDir\ROOT\Folder_1\CanDelete", "\\Telerik.com\Path\SharedDir\ROOT\Folder_11\CanDelAndUpload"}

		RadFileExplorer1.Configuration.ViewPaths = viewPaths
		RadFileExplorer1.Configuration.UploadPaths = uploadPaths
		RadFileExplorer1.Configuration.DeletePaths = deletePaths
		RadFileExplorer1.Configuration.SearchPatterns = New String() {"*.*"}
		RadFileExplorer1.Configuration.ContentProviderTypeName = GetType(CustomFileSystemProvider).AssemblyQualifiedName
	End Sub


End Class
