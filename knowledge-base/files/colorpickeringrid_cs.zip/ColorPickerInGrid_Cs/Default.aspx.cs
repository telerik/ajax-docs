﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Configuration;
using Telerik.Web.UI;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}

	RadColorPicker colorPicker;// Store the RadColorPickerEdit
	protected void RadGrid1_InsertCommand(object source, GridCommandEventArgs e)
	{
		RadGrid grid = source as RadGrid;
		colorPicker = e.Item.FindControl("RadColorPickerEdit") as RadColorPicker;// Get the RadColorPicker object
	}

	protected void RadGrid1_UpdateCommand(object source, GridCommandEventArgs e)
	{
		RadGrid grid = source as RadGrid;
		colorPicker = e.Item.FindControl("RadColorPickerEdit") as RadColorPicker;// Get the RadColorPicker object
	}

	protected void SqlDataSource1_Updating(object sender, SqlDataSourceCommandEventArgs e)
	{
		string color = System.Drawing.ColorTranslator.ToHtml(colorPicker.SelectedColor);//Get the selected color and convert it to text
		SqlParameter strParam = new SqlParameter("@FavoriteColor", color);
		e.Command.Parameters.Add(strParam);// Pass the selected color as text to the server 
	}
	protected void SqlDataSource1_Inserting(object sender, SqlDataSourceCommandEventArgs e)
	{
		string color = System.Drawing.ColorTranslator.ToHtml(colorPicker.SelectedColor);//Get the selected color and convert it to text
		SqlParameter strParam = new SqlParameter("@FavoriteColor", color);
		e.Command.Parameters.Add(strParam);// Pass the selected color as text to the server 
	}
}
