﻿using System;
using System.Web;
using System.Web.UI;
using Telerik.Web.UI;
using System.IO;

public partial class Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

	protected void Button1_Click(object sender, EventArgs e)
	{
		//obtain the necessary settings for exporting the chart
		HtmlChartExportSettings currentSettings = new HtmlChartExportSettings();

		currentSettings.Height = (int)RadHtmlChart1.Height.Value;
		currentSettings.Width = (int)RadHtmlChart1.Width.Value;

		//decodes the SVG string saved from the client
		string svgText = HttpUtility.UrlDecode(svgHolder.Value, System.Text.Encoding.Default);

		//create a temporary SVG file that Inkscape will use
		currentSettings.SvgFilePath = Server.MapPath("~/App_Data/temp.svg");
		System.IO.File.WriteAllText(currentSettings.SvgFilePath, svgText);

		//get the export format - png or pdf
		currentSettings.Extension = rbl_ExportFormat.SelectedValue;

		//the output file Inkscape will use, hardcoded to use App_Data as a temporary folder
		currentSettings.OutputFilePath = Server.MapPath("~/App_Data/exportedChart." + currentSettings.Extension);

		//you can change the name of the file the user will receive here. Extension is automatically added
		currentSettings.ClientFileName = "exportedChart";


		//the actual file is created
		HtmlChartExporter.ExportHtmlChart(currentSettings);

		//read the exported file and send it to the client
		byte[] fileForClient = HtmlChartExporter.ReadFile(currentSettings.OutputFilePath);
		Response.ContentType = HtmlChartExportSettings.ContentTypeList[currentSettings.Extension];
		Response.AddHeader("Content-Disposition", "attachment;filename=" + currentSettings.ClientFileName);
		Response.BinaryWrite(fileForClient);


		//delete the temporary files to avoid flooding the server
		File.Delete(currentSettings.OutputFilePath);
		File.Delete(currentSettings.SvgFilePath);
	}
}
