﻿Imports Telerik.Web.UI
Imports System.Data.SqlClient

Partial Class Default_Vb
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
	End Sub

	Private colorPicker As RadColorPicker
	' Store the RadColorPickerEdit
	Protected Sub RadGrid1_InsertCommand(ByVal source As Object, ByVal e As GridCommandEventArgs)
		Dim grid As RadGrid = TryCast(source, RadGrid)
		' Get the RadColorPicker object
		colorPicker = TryCast(e.Item.FindControl("RadColorPickerEdit"), RadColorPicker)
	End Sub

	Protected Sub RadGrid1_UpdateCommand(ByVal source As Object, ByVal e As GridCommandEventArgs)
		Dim grid As RadGrid = TryCast(source, RadGrid)
		' Get the RadColorPicker object
		colorPicker = TryCast(e.Item.FindControl("RadColorPickerEdit"), RadColorPicker)
	End Sub

	Protected Sub SqlDataSource1_Updating(ByVal sender As Object, ByVal e As SqlDataSourceCommandEventArgs)
		Dim color As String = System.Drawing.ColorTranslator.ToHtml(colorPicker.SelectedColor)
		'Get the selected color and convert it to text
		Dim strParam As New SqlParameter("@FavoriteColor", color)
		' Pass the selected color as text to the server 
		e.Command.Parameters.Add(strParam)
	End Sub
	Protected Sub SqlDataSource1_Inserting(ByVal sender As Object, ByVal e As SqlDataSourceCommandEventArgs)
		Dim color As String = System.Drawing.ColorTranslator.ToHtml(colorPicker.SelectedColor)
		'Get the selected color and convert it to text
		Dim strParam As New SqlParameter("@FavoriteColor", color)
		' Pass the selected color as text to the server 
		e.Command.Parameters.Add(strParam)
	End Sub

End Class
