﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;
using System.Data.SqlClient;
using System.IO;

public partial class Default : System.Web.UI.Page 
{
    public string newFileName { get; set; }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RadGrid1_DeleteCommand(object sender, GridCommandEventArgs e)
    {
        string filePath = Server.MapPath((string)(e.Item as GridDataItem).GetDataKeyValue("FilePath"));

        if (File.Exists(filePath))
            File.Delete(filePath);

        string updateQuery = "DELETE FROM PickupFiles WHERE FileID = @FileID";

        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
        {
            using (SqlCommand comm = new SqlCommand(updateQuery, conn))
            {
                comm.Parameters.Add(new SqlParameter("FileID", (e.Item as GridDataItem).GetDataKeyValue("FileID")));

                conn.Open();
                comm.ExecuteNonQuery();
            }
        }
    }

    protected void RadGrid1_InsertCommand(object sender, GridCommandEventArgs e)
    {
        // reference the AsyncUpload
        RadAsyncUpload upload = e.Item.FindControl("RadAsyncUpload1") as RadAsyncUpload;
        if (upload.UploadedFiles.Count > 0) // Verify if it has files uploaded
        {
            string updateQuery = "INSERT INTO PickupFiles (FilePath, FileName) VALUES(@FilePath, @FileName)"; // Prepare the update query

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
            {
                using (SqlCommand comm = new SqlCommand(updateQuery, conn))
                {
                    string FullPathToApplication = Request.PhysicalApplicationPath;
                    string FullPathToFiles = Server.MapPath("Files/" + newFileName).Replace(FullPathToApplication, string.Empty).Replace("\\", "/");

                    comm.Parameters.Add(new SqlParameter("FilePath", "~/" + FullPathToFiles.ToString()));
                    comm.Parameters.Add(new SqlParameter("FileName", newFileName));

                    conn.Open();
                    comm.ExecuteNonQuery();
                }
            }
        }
    }

    protected void RadGrid1_UpdateCommand(object sender, GridCommandEventArgs e)
    {
        // Get reference to the old filePath
        string oldFilePath = Server.MapPath((string)(e.Item as GridEditableItem).GetDataKeyValue("FilePath"));

        if (!string.IsNullOrEmpty(newFileName))
        {
            string updateQuery = "UPDATE PickupFiles SET FilePath=@FilePath, FileName=@FileName WHERE FileID=@FileID";

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
            {
                using (SqlCommand comm = new SqlCommand(updateQuery, conn))
                {
                    string FullPathToApplication = Request.PhysicalApplicationPath;
                    string FullPathToFiles = "~/" + Server.MapPath("Files/" + newFileName).Replace(FullPathToApplication, string.Empty).Replace("\\", "/");

                    comm.Parameters.Add(new SqlParameter("FileID", (e.Item as GridEditableItem).GetDataKeyValue("FileID")));
                    comm.Parameters.Add(new SqlParameter("FilePath", FullPathToFiles));
                    comm.Parameters.Add(new SqlParameter("FileName", newFileName));

                    conn.Open();
                    comm.ExecuteNonQuery();
                }
            }

            // If update was successfull, delete the old file
            if (File.Exists(oldFilePath))
                File.Delete(oldFilePath);
        }
    }

    protected void RadAsyncUpload1_FileUploaded(object sender, FileUploadedEventArgs e)
    {
        if ((sender as RadAsyncUpload).UploadedFiles.Count > 0)
        {
            newFileName = e.File.GetNameWithoutExtension() + User.Identity.Name.Replace("\\", String.Empty) + "_" + DateTime.Now.ToString("ddMMyyyyHHmmssffff") + e.File.GetExtension();
            e.File.SaveAs(Path.Combine(Server.MapPath("Files"), newFileName));
        }
    }
}
