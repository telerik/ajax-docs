﻿
Partial Class SelfClosingDialog
    Inherits System.Web.UI.Page

Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
    Dim script As String = "<script type='text/javascript'>CloseOnReload();</" + "script>"
    ClientScript.RegisterStartupScript(Me.[GetType](), "CloseOnReload", script)
End Sub

'Refresh parent page on reload
Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs)
    Dim script As String = "RefreshParentPage();"
    ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "RefreshParentPage", script, True)
End Sub

Protected Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs)
    'code to handle the generic AJAX request
    Dim newUrl As String = "http://www.google.com"
    Dim script As String = "RedirectParentPage('" + newUrl + "');"

    RadAjaxManager1.ResponseScripts.Add(script)
End Sub

'Calling a function defined on the parent page
Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs)
    'We do some server-side processing and we decide which function to call
    Dim fnName As String = "TestFunction"
    Dim script As String = "CallFunctionOnParentPage('" + fnName + "');"
    RadAjaxPanel1.ResponseScripts.Add(script)
End Sub

' Refresh parent page on reload without warning message 
Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs)
    Dim script As String = "RefreshParentPageWithoutWarning();"
    ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "RefreshParentPageWithoutWarning", script, True)
End Sub

End Class
