﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class custom_button_in_radwindow_titlebar : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		RadWindow1.RenderMode = (Telerik.Web.UI.RenderMode)Enum.Parse(typeof(Telerik.Web.UI.RenderMode), RadioButtonList1.SelectedValue);
	}
}