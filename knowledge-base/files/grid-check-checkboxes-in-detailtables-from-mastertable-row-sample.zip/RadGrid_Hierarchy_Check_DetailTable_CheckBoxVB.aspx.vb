﻿
Imports System.Data
Imports Telerik.Web.UI

Partial Class RadGrid_Hierarchy_Check_DetailTable_CheckBoxVB
    Inherits System.Web.UI.Page

    Protected Sub RadGrid1_NeedDataSource(ByVal sender As Object, ByVal e As GridNeedDataSourceEventArgs)
        RadGrid1.DataSource = OrdersTable()
    End Sub

    Protected Sub RadGrid1_DetailTableDataBind(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridDetailTableDataBindEventArgs)
        e.DetailTableView.DataSource = OrdersTable()
    End Sub

    Private Function OrdersTable() As DataTable
        Dim dt As DataTable = New DataTable()
        dt.Columns.Add(New DataColumn("OrderID", GetType(Integer)))
        dt.Columns.Add(New DataColumn("Freight", GetType(Decimal)))
        dt.Columns.Add(New DataColumn("ShipName", GetType(String)))
        dt.PrimaryKey = New DataColumn() {dt.Columns("OrderID")}

        For i As Integer = 0 To 5 - 1
            Dim index As Integer = i + 1
            Dim row As DataRow = dt.NewRow()
            row("OrderID") = index
            row("Freight") = index * 0.1 + index * 0.01
            row("ShipName") = "Name " & index
            dt.Rows.Add(row)
        Next

        Return dt
    End Function

    Protected Sub RadGrid1_PreRender(ByVal sender As Object, ByVal e As EventArgs)
        RadGrid1.MasterTableView.Items.OfType(Of GridDataItem)().First().Expanded = True
    End Sub

    Protected Sub RadCheckBox2_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim masterCheckBox As RadCheckBox = CType(sender, RadCheckBox)
        Dim dataItem As GridDataItem = TryCast(masterCheckBox.NamingContainer, GridDataItem)

        If dataItem.HasChildItems Then
            Dim detailTable As GridTableView = dataItem.ChildItem.NestedTableViews.First()

            For Each item As GridDataItem In detailTable.Items
                Dim detailCheckBox As RadCheckBox = TryCast(item("TempalteColumn3").FindControl("RadCheckBox3"), RadCheckBox)
                detailCheckBox.Checked = masterCheckBox.Checked
            Next
        End If
    End Sub
End Class
