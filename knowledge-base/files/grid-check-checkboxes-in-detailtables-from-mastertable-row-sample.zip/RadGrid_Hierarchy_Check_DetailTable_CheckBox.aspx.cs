﻿using System;
using System.Data;
using System.Linq;
using Telerik.Web.UI;

public partial class RadGrid_Hierarchy_Check_DetailTable_CheckBox : System.Web.UI.Page
{
    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        RadGrid1.DataSource = OrdersTable(); 
    }
    protected void RadGrid1_DetailTableDataBind(object sender, Telerik.Web.UI.GridDetailTableDataBindEventArgs e)
    {
        e.DetailTableView.DataSource = OrdersTable();
    }
    private DataTable OrdersTable()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add(new DataColumn("OrderID", typeof(int)));
        dt.Columns.Add(new DataColumn("Freight", typeof(decimal)));
        dt.Columns.Add(new DataColumn("ShipName", typeof(string)));

        dt.PrimaryKey = new DataColumn[] { dt.Columns["OrderID"] };

        for (int i = 0; i < 5; i++)
        {
            int index = i + 1;

            DataRow row = dt.NewRow();

            row["OrderID"] = index;
            row["Freight"] = index * 0.1 + index * 0.01;
            row["ShipName"] = "Name " + index;

            dt.Rows.Add(row);
        }

        return dt;
    }
    protected void RadGrid1_PreRender(object sender, EventArgs e)
    {
        RadGrid1.MasterTableView.Items.OfType<GridDataItem>().First().Expanded = true;
    }
    protected void RadCheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        // cast sender to RadCheckBox control
        RadCheckBox masterCheckBox = (RadCheckBox)sender;
        // get reference to the current MasterTable item 
        GridDataItem dataItem = masterCheckBox.NamingContainer as GridDataItem;
        // check whether it has child items/detail tables
        if (dataItem.HasChildItems)
        {
            // reference the DetailTable
            GridTableView detailTable = dataItem.ChildItem.NestedTableViews.First();
            // llop through the detailtable items
            foreach (GridDataItem item in detailTable.Items)
            {
                // find the checkbox of the item
                RadCheckBox detailCheckBox = item["TempalteColumn3"].FindControl("RadCheckBox3") as RadCheckBox;
                // check the checkbox based on the MasterCheckbox checked state
                detailCheckBox.Checked = masterCheckBox.Checked;
            }
        }
    }
}