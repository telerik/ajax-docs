﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

/// <summary>
/// Summary description for PromptTemplateLoader
/// </summary>
public class PromptTemplateLoader : ITemplate
{
	private Page _page;

	public PromptTemplateLoader(Page page)
	{
		this._page = page;
	}

	void ITemplate.InstantiateIn(Control owner)
	{
		Control ctrl = _page.LoadControl("~/PromptTemplateWithNameAttr.ascx");
		owner.Controls.Add(ctrl);
	}
}

