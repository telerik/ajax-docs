﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class FileExplorerAddendum : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		HttpContext.Current.Response.SuppressFormsAuthenticationRedirect = true;

		//You may want to pass the RenderMode of the FileExplorer as an argument as well, so the proper template can be loaded
		//even though this sample does not include such logic or the Lightweight template,
		//you can obtain the templates from this article: http://docs.telerik.com/devtools/aspnet-ajax/controls/window/alert,-confirm,-prompt-dialogs/how-to-change-the-dialog-templates
		FileExplorer1.WindowManager.PromptTemplate = new PromptTemplateLoader(Page);

        FileExplorer1.AsyncUpload.OnClientAdded = "addNameAttribute";
    }
	
	protected void rxhp1_ServiceRequest(object sender, RadXmlHttpPanelEventArgs e)
	{
		Label1.Text = DateTime.Now.ToString();
	}
}