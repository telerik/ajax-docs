﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class change_filter_item_picker_range : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

	protected void RadGrid1_ItemCreated(object sender, GridItemEventArgs e)
	{
		if (e.Item is GridFilteringItem)
		{
			GridFilteringItem fitem = (GridFilteringItem)e.Item;
			foreach (GridColumn col in (sender as RadGrid).MasterTableView.RenderColumns)
			{
				if (col is GridDateTimeColumn)
				{
					RadDatePicker rp = (RadDatePicker)fitem[col.UniqueName].Controls[1];
					RadDatePicker rp2 = (RadDatePicker)fitem[col.UniqueName].Controls[4];

					if (null != rp)
					{
						SetMinMaxDateToFilteringPicker(rp);
					}

					if (null != rp2)
					{
						SetMinMaxDateToFilteringPicker(rp2);
					}
				}
			}
		}

	}

	private void SetMinMaxDateToFilteringPicker(RadDatePicker picker)
	{
		//this is the solution to allow navigating such far ranges - see the corresponding JS function
		picker.ClientEvents.OnPopupOpening = "calendarPopUpOpening";
		//set min and max dates, the client code will use them
		DateTime dtMinVal = new DateTime(1500, 01, 01, 00, 00, 00);
		DateTime dtMaxVal = new DateTime(2500, 12, 31, 23, 59, 59);
		picker.MinDate = dtMinVal;
		picker.MaxDate = dtMaxVal;
	}

	

	protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
	{
		RadGrid1.DataSource = GetDatesData();
	}



	protected DataTable GetDatesData()
	{
		DataTable table = new DataTable();

		table.Columns.Add("theDates", typeof(DateTime));
		table.Columns.Add("someField", typeof(int));
		table.Columns.Add("otherField", typeof(int));

		table.Rows.Add(DateTime.Now.AddDays(1), 100, 2);
		table.Rows.Add(DateTime.Now.AddDays(2), 150, 10);
		table.Rows.Add(DateTime.Now.AddDays(3), 120, 5);
		table.Rows.Add(DateTime.Now.AddDays(4), 300, 10);

		return table;
	}

}
