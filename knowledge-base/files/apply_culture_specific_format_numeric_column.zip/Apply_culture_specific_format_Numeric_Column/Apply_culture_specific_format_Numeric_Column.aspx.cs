﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class Apply_culture_specific_format_Numeric_Column : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #region DataSources
    private DataTable GetGridSource()
    {
        DataTable dataTable = new DataTable();

        DataColumn column = new DataColumn();
        column.DataType = Type.GetType("System.Int32");
        column.ColumnName = "OrderID";
        dataTable.Columns.Add(column);
       
        column = new DataColumn();
        column.DataType = Type.GetType("System.Decimal");
        column.ColumnName = "NumericData";
        dataTable.Columns.Add(column);

        DataColumn[] PrimaryKeyColumns = new DataColumn[1];
        PrimaryKeyColumns[0] = dataTable.Columns["OrderID"];
        dataTable.PrimaryKey = PrimaryKeyColumns;

        for (int i = 0; i < 20; i++)
        {
            DataRow row = dataTable.NewRow();
            row["OrderID"] = i + 1;
            row["NumericData"] = 9000000000 * (i+1) * 0.01;

            dataTable.Rows.Add(row);
        }
        return dataTable;
    }
    #endregion
    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        RadGrid1.DataSource = GetGridSource();
    }


    protected void RadGrid1_ItemDataBound(object sender, GridItemEventArgs e)
    {
        if(e.Item is GridDataItem)
        {
            var dataItem = (GridDataItem)e.Item;

            decimal value = DataBinder.Eval(dataItem.DataItem, "NumericData") as decimal? ?? 0;
            dataItem["CultureUS"].Text = string.Format((new System.Globalization.CultureInfo("en-US")).NumberFormat, "{0:C}", value);

            value = DataBinder.Eval(dataItem.DataItem, "NumericData") as decimal? ?? 0;
            dataItem["CultureGB"].Text = string.Format((new System.Globalization.CultureInfo("en-GB")).NumberFormat, "{0:C}", value);

            value = DataBinder.Eval(dataItem.DataItem, "NumericData") as decimal? ?? 0;
            dataItem["CultureDE"].Text = string.Format((new System.Globalization.CultureInfo("en-DE")).NumberFormat, "{0:C}", value);
        }
    }
}