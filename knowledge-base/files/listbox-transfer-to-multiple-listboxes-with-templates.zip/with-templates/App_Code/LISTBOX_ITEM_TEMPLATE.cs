﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for LISTBOX_ITEM_TEMPLATE
/// </summary>
public class LISTBOX_ITEM_TEMPLATE : ITemplate
{
    public LISTBOX_ITEM_TEMPLATE()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void InstantiateIn(Control container)
    {
        Label l = new Label() { ID = "label1", Text = "Test 1" };

        container.Controls.Add(l);

    }

}