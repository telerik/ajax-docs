﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class multipleDragDropWithTemplates : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        RadListBox1.ItemTemplate = new LISTBOX_ITEM_TEMPLATE();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //a starting point item is created once so we can play with the example
        if (!Page.IsPostBack)
        {
            RadListBox1.Items.Add(new Telerik.Web.UI.RadListBoxItem("", "1"));
        }

        //needed so templates can be bound
        RadListBox1.DataBind();
        RadListBox2.DataBind();
        RadListBox3.DataBind();
    }
}