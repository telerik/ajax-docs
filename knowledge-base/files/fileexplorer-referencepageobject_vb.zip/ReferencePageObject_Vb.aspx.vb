﻿Imports Telerik.Web.UI.Widgets
Imports Telerik.Web.UI
Imports System.Drawing
Imports System.Drawing.Drawing2D

Partial Class ReferencePageObject_Vb
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        RadFileExplorer1.Configuration.ContentProviderTypeName = GetType(CustomProvider).AssemblyQualifiedName
    End Sub

    Public Class CustomProvider
        Inherits FileSystemContentProvider
        Public Sub New(ByVal context As HttpContext, ByVal searchPatterns As String(), ByVal viewPaths As String(), ByVal uploadPaths As String(), ByVal deletePaths As String(), ByVal selectedUrl As String, _
         ByVal selectedItemTag As String)

            MyBase.New(context, searchPatterns, viewPaths, uploadPaths, deletePaths, selectedUrl, _
             selectedItemTag)
        End Sub


        Public Overrides Function StoreFile(ByVal file As UploadedFile, ByVal path As String, ByVal name As String, ByVal ParamArray arguments As String()) As String
            Dim image As System.Drawing.Image = System.Drawing.Image.FromStream(file.InputStream)
            Dim physicalPath As String = Context.Server.MapPath(path)

            ' Get the Page object which hosts the RadFileExplorer control
            Dim _pageContainsRadFileExplorer As Page = TryCast(HttpContext.Current.Handler, Page)
            Dim newWidth As Integer = 0
            Dim newHeight As Integer = 0

            If _pageContainsRadFileExplorer IsNot Nothing Then
                ' Find the Width and Height textBoxes. 
                ' Please note that this may vary depending on the structure of the page (MasterPages, userControls etc.)
                '                 

                Try
                    ' Find the 'TextBoxWidth' control.
                    Dim tbWidth As TextBox = TryCast(_pageContainsRadFileExplorer.FindControl("TextBoxWidth"), TextBox)
                    newWidth = Integer.Parse(tbWidth.Text)

                    ' Find the 'TextBoxheight' control.
                    Dim tbHeight As TextBox = TryCast(_pageContainsRadFileExplorer.FindControl("TextBoxHeight"), TextBox)
                    newHeight = Integer.Parse(tbHeight.Text)
                Catch ex As Exception
                    Dim message As String = "Please enter valid Width and Height values"
                    ShowMessage(_pageContainsRadFileExplorer, message)

                    Return String.Empty
                End Try
            End If

            ' Change the size of the uploaded image
            Dim resultImage As System.Drawing.Image = ResizeImage(image, New Size(newWidth, newHeight))

            Try
                ' Save the image with the new size
                resultImage.Save(physicalPath & name)

                Dim message As String = String.Format("The image was successfuly saved with dimentions: {0}x{1}", newWidth, newHeight)
                ShowMessage(_pageContainsRadFileExplorer, message)
            Catch ex As Exception
                Dim message As String = "The image was not saved"
                ShowMessage(_pageContainsRadFileExplorer, message)

                Return String.Empty
            End Try

            Dim result As String = path & name
            Return result
        End Function

        Private Sub ShowMessage(ByVal _pageObject As Page, ByVal message As String)
            ' Output a information box (radalert):
            Dim script As String = String.Format("showradAlertFromServer('{0}');", message)

            ' Output a information box (standard browser dialog):
            '  string script = string.Format("alert('{0}');", message);

            ' regisers the script
            ScriptManager.RegisterStartupScript(_pageObject, _pageObject.[GetType](), "KEY", script, True)
        End Sub

        ''' <summary>
        ''' Resizes the image to the desired dimentions
        ''' </summary>
        ''' <param name="sourceImage"></param>
        ''' <param name="newSize"></param>
        ''' <returns></returns>
        Private Shared Function ResizeImage(ByVal sourceImage As System.Drawing.Image, ByVal newSize As Size) As System.Drawing.Image
            Dim bitmap As New Bitmap(newSize.Width, newSize.Height)
            Dim g As Graphics = Graphics.FromImage(DirectCast(bitmap, System.Drawing.Image))
            g.InterpolationMode = InterpolationMode.HighQualityBicubic

            g.DrawImage(sourceImage, 0, 0, newSize.Width, newSize.Height)
            g.Dispose()

            Return DirectCast(bitmap, System.Drawing.Image)
        End Function
    End Class


End Class
