﻿using System;
using System.Web;
using Telerik.Web.UI;

public partial class Default : System.Web.UI.Page 
{
    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        RadGrid1.DataSource = MyData.BusinessDataStorage.GetData();
    }

    protected void RadGrid1_ItemCommand(object sender, GridCommandEventArgs e)
    {
        if (e.CommandName.StartsWith("Export"))
        {
            if (!String.IsNullOrEmpty(Request["_downloadToken"]))
            {
                Response.Cookies.Add(new HttpCookie("_downloadToken", Request["_downloadToken"]));
                System.Threading.Thread.Sleep(5000);
            }
        }
    }
}
