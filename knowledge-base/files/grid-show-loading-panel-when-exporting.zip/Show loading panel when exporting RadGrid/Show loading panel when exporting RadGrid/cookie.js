﻿cookie = {
    get: function(name) {
        var part = document.cookie.split(name + "=")[1];
        return part ? decodeURIComponent(part.split(";")[0]) : null;
    },
    set: function(name, value, days, path, secure) {
        document.cookie = [
            name + "=" + encodeURIComponent(value),
            days ? "expires=" + new Date(new Date().getTime() + (days*24*60*60*1000)).toUTCString() : "",
            secure ? "secure" : "",
            path ? "path=" + path : "path=/"
        ].join("; ");
    },
    erase: function(name) {
        cookie.set(name, "", -1);
    },
    all: function() {
        var ret = {};
        var arr = document.cookie.split(";");
        for (var i = 0; i < arr.length; i++) {
            if (arr[i]) {
                var pair = arr[i].split("=");
                ret[pair[0]] = decodeURIComponent(pair[1]);
            }
        }
        return ret;
    }
}