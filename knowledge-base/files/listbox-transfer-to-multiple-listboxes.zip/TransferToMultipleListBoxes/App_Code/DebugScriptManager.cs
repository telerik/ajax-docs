﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;

namespace Telerik.Web.UI.Debug
{
	public class DebugScriptManager : ScriptManager
	{
		string _startPath;
		public string StartPath
		{
			get
			{
				return _startPath;
			}
			set
			{
				_startPath = value;
			}
		}

		bool _enableDebugOutput = true;
		public bool EnableDebugOutput
		{
			get
			{
				return _enableDebugOutput;
			}
			set
			{
				_enableDebugOutput = value;
			}
		}

		string _defaultNamespace;
		public string DefaultNamespace
		{
			get
			{
				return _defaultNamespace ?? "Telerik.Web.UI";
			}
			set
			{
				_defaultNamespace = value;
			}
		}

		string _scriptsAssembly;
		public string ScriptsAssembly
		{
			get
			{
				return _scriptsAssembly ?? "Telerik.Web.UI";
			}
			set
			{
				_scriptsAssembly = value;
			}
		}

		List<ScriptReference> _registeredScripts = new List<ScriptReference>();
		public List<ScriptReference> RegisteredScripts
		{
			get { return _registeredScripts; }
		}

		protected override void OnResolveScriptReference(ScriptReferenceEventArgs e)
		{
			base.OnResolveScriptReference(e);

			if (EnableDebugOutput)
			{
				if (e.Script.Assembly.StartsWith(ScriptsAssembly))
				{
					e.Script.Path = GetScriptPath(e.Script.Name);
				}
			}

			ScriptReference existingScript = RegisteredScripts.Find(
				delegate(ScriptReference s) { return s.Name == e.Script.Name && s.Assembly == e.Script.Assembly; });

			// Filter duplicates and MS AJAX scripts (no assembly)
			if (e.Script.Assembly != string.Empty && existingScript == null)
				RegisteredScripts.Add(e.Script);
		}

		private string GetScriptPath(string scriptName)
		{
			if (scriptName.StartsWith(DefaultNamespace))
			{
				scriptName = scriptName.Remove(0, DefaultNamespace.Length + 1);
			}
			string scriptPath = scriptName.Replace(".", "/").Replace("/js", ".js");

			if (StartPath == null)
			{
				return scriptPath;
			}
			return string.Concat(EndWithSlash(StartPath), scriptPath);
		}

		private string EndWithSlash(string url)
		{
			if (string.IsNullOrEmpty(url))
			{
				return string.Empty;
			}
			if (url.EndsWith("/"))
			{
				return url;
			}
			return string.Concat(url, "/");
		}
	}
}