using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SelfClosingDialog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, System.EventArgs e)
    {
        string script = "<script type='text/javascript'>CloseOnReload();</" + "script>";
        ClientScript.RegisterStartupScript(this.GetType(), "CloseOnReload", script);
    }

    //Refresh parent page on reload
    protected void Button2_Click(object sender, System.EventArgs e)
    {
        string script = "RefreshParentPage();";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "RefreshParentPage", script, true);
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        //code to handle the generic AJAX request
        string newUrl = "http://www.google.com";
        string script = "RedirectParentPage('" + newUrl + "');";

        RadAjaxManager1.ResponseScripts.Add(script);
    }

    //Calling a function defined on the parent page
    protected void Button4_Click(object sender, System.EventArgs e)
    {
        //We do some server-side processing and we decide which function to call
        string fnName = "TestFunction";
        string script = "CallFunctionOnParentPage('" + fnName + "');";

        RadAjaxPanel1.ResponseScripts.Add(script);
    }

    //Refresh parent page on reload without warning message 
    protected void Button5_Click(object sender, System.EventArgs e)
    {
        string script = "RefreshParentPageWithoutWarning();";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "RefreshParentPageWithoutWarning", script, true);
    }
}
