﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;

public partial class RadSchedulerWebForm : System.Web.UI.Page 
{
   

    protected void Page_Load(object sender, EventArgs e)
    {
            
    }
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
		RadScheduler1.Provider = new XmlSchedulerProvider(Server.MapPath("~/App_Data/Appointments.xml"), true);
    }


    protected void RadAjaxManager1_AjaxRequest(object sender, AjaxRequestEventArgs e)
    {
        char [] seps={'-'};
        string[] dates = new string[3];
        dates = e.Argument.Split(seps, StringSplitOptions.RemoveEmptyEntries);
        DateTime selectedDate = new DateTime(Int32.Parse(dates[0]), Int32.Parse(dates[1]), Int32.Parse(dates[2]));
        RadScheduler1.SelectedDate = selectedDate;
       
    }
  
}
