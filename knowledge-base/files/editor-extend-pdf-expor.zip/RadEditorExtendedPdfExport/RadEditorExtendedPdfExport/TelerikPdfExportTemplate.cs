﻿using System;
using Telerik.Web.UI;
using Telerik.Web.UI.Editor.Export;
using System.Net;
using System.IO;

using Telerik.Windows.Documents.Flow.Model;
using Telerik.Windows.Documents.Flow.FormatProviders.Html;
using Telerik.Windows.Documents.Flow.FormatProviders.Pdf;

public class TelerikPdfExportTemplate: RadEditorExportTemplate
{
	public TelerikPdfExportTemplate (RadEditor radEditor) : base(radEditor)
	{
	}

	//no need to initialize the XmlContent
	protected override void InitializeXmlContent()
	{
	}

	protected override string GenerateOutput()
	{
		string output = "";
        PdfFormatProvider pdfProvider = new PdfFormatProvider();

		RadFlowDocument document = this.ImportDocument();

        byte[] buffer = pdfProvider.Export(document);
		output = ResponseWriteEncoding.GetString(buffer);

    	return output;
	}
	
	private RadFlowDocument ImportDocument()
	{
		HtmlFormatProvider provider = new HtmlFormatProvider();
        provider.ImportSettings.LoadFromUri += ImportSettings_LoadImageFromUrl;

		return provider.Import(editor.Content);
	}

    private void ImportSettings_LoadImageFromUrl(object sender, LoadFromUriEventArgs e)
    {
        //This ensures images are properly loaded from url.
        WebRequest req = WebRequest.Create(e.Uri);
        WebResponse response = req.GetResponse();
        Stream imageStream = response.GetResponseStream();

        using (var memoryStream = new MemoryStream())
        {
            imageStream.CopyTo(memoryStream);
            e.SetData(memoryStream.ToArray());
        }
    }

    protected override string ContentType
	{
		get { return "application/pdf"; }
	}

	protected override string FileExtension
	{
		get { return ".pdf"; }
	}

	protected override ExportType ExportType
	{
		get { return ExportType.Pdf; }
	}
}
