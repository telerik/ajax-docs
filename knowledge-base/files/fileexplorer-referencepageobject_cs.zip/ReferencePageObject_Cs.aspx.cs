using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;
using Telerik.Web.UI.Editor.DialogControls;
using Telerik.Web.UI.Widgets;
using System.Drawing;
using System.Drawing.Drawing2D;

public partial class ReferencePageObject_Cs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RadFileExplorer1.Configuration.ContentProviderTypeName = typeof(CustomProvider).AssemblyQualifiedName;
    }

    public class CustomProvider : FileSystemContentProvider
    {
        public CustomProvider(HttpContext context, string[] searchPatterns, string[] viewPaths, string[] uploadPaths, string[] deletePaths, string selectedUrl, string selectedItemTag)
            : base(context, searchPatterns, viewPaths, uploadPaths, deletePaths, selectedUrl, selectedItemTag)
        {

        }


        public override string StoreFile(UploadedFile file, string path, string name, params string[] arguments)
        {
            System.Drawing.Image image = System.Drawing.Image.FromStream(file.InputStream);
            string physicalPath = Context.Server.MapPath(path);

            // Get the Page object which hosts the RadFileExplorer control
            Page _pageContainsRadFileExplorer = HttpContext.Current.Handler as Page;
            int newWidth = 0;
            int newHeight = 0;

            if (_pageContainsRadFileExplorer != null)
            {
                /* Find the Width and Height textBoxes. 
                 * Please note that this may vary depending on the structure of the page (MasterPages, userControls etc.)
                 */

                try
                {
                    // Find the 'TextBoxWidth' control.
                    TextBox tbWidth = _pageContainsRadFileExplorer.FindControl("TextBoxWidth") as TextBox;
                    newWidth = int.Parse(tbWidth.Text);

                    // Find the 'TextBoxheight' control.
                    TextBox tbHeight = _pageContainsRadFileExplorer.FindControl("TextBoxHeight") as TextBox;
                    newHeight = int.Parse(tbHeight.Text);
                }
                catch (Exception ex)
                {
                    string message = "Please enter valid Width and Height values";
                    ShowMessage(_pageContainsRadFileExplorer, message);

                    return string.Empty;
                }
            }

            // Change the size of the uploaded image
            System.Drawing.Image resultImage = ResizeImage(image, new Size(newWidth, newHeight));

            try
            {
                // Save the image with the new size
                resultImage.Save(physicalPath + name);

                string message = string.Format("The image was successfuly saved with dimentions: {0}x{1}", newWidth, newHeight);
                ShowMessage(_pageContainsRadFileExplorer, message);
            }
            catch (Exception ex)
            {
                string message = "The image was not saved";
                ShowMessage(_pageContainsRadFileExplorer, message);

                return string.Empty;
            }

            string result = path + name;
            return result;
        }

        private void ShowMessage(Page _pageObject, string message)
        {
            // Output a information box (radalert):
            string script = string.Format("showradAlertFromServer('{0}');", message);

            // Output a information box (standard browser dialog):
            //  string script = string.Format("alert('{0}');", message);

            // regisers the script
            ScriptManager.RegisterStartupScript(_pageObject, _pageObject.GetType(), "KEY", script, true);
        }

        /// <summary>
        /// Resizes the image to the desired dimentions
        /// </summary>
        /// <param name="sourceImage"></param>
        /// <param name="newSize"></param>
        /// <returns></returns>
        private static System.Drawing.Image ResizeImage(System.Drawing.Image sourceImage, Size newSize)
        {
            Bitmap bitmap = new Bitmap(newSize.Width, newSize.Height);
            Graphics g = Graphics.FromImage((System.Drawing.Image)bitmap);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(sourceImage, 0, 0, newSize.Width, newSize.Height);
            g.Dispose();

            return (System.Drawing.Image)bitmap;
        }
    }
}