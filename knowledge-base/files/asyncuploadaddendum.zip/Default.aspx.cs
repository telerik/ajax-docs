﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class _Default : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		HttpContext.Current.Response.SuppressFormsAuthenticationRedirect = true;
	}
	
	protected void rxhp1_ServiceRequest(object sender, RadXmlHttpPanelEventArgs e)
	{
		Label1.Text = DateTime.Now.ToString();
	}
}