﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class RadGridFilterButtonExpressionBuild : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        RadGrid1.DataSource = GetGridSource();
    }
    private DataTable GetGridSource()
    {
        DataTable dataTable = new DataTable();

        DataColumn column = new DataColumn();
        column.DataType = Type.GetType("System.Int32");
        column.ColumnName = "OrderID";
        dataTable.Columns.Add(column);

        column = new DataColumn();
        column.DataType = Type.GetType("System.DateTime");
        column.ColumnName = "OrderDate";
        dataTable.Columns.Add(column);

        column = new DataColumn();
        column.DataType = Type.GetType("System.Decimal");
        column.ColumnName = "Freight";
        dataTable.Columns.Add(column);

        column = new DataColumn();
        column.DataType = Type.GetType("System.String");
        column.ColumnName = "ShipName";
        dataTable.Columns.Add(column);

        column = new DataColumn();
        column.DataType = Type.GetType("System.String");
        column.ColumnName = "ShipCountry";
        dataTable.Columns.Add(column);

        DataColumn[] PrimaryKeyColumns = new DataColumn[1];
        PrimaryKeyColumns[0] = dataTable.Columns["OrderID"];
        dataTable.PrimaryKey = PrimaryKeyColumns;

        for (int i = 0; i <= 80; i++)
        {
            DataRow row = dataTable.NewRow();
            row["OrderID"] = i + 1;
            row["OrderDate"] = DateTime.Now;
            row["Freight"] = (i + 1) + (i + 1) * 0.1 + (i + 1) * 0.01;
            row["ShipName"] = "Name " + (i + 1);
            row["ShipCountry"] = "Country " + (i + 1);

            dataTable.Rows.Add(row);
        }

        return dataTable;
    }
    Dictionary<string, Pair> expressionDetails = new Dictionary<string, Pair>();
    protected void Button1_Click(object sender, EventArgs e)
    {
        GridFilteringItem filterItem = RadGrid1.MasterTableView.GetItems(GridItemType.FilteringItem)[0] as GridFilteringItem;
        foreach (GridColumn column in RadGrid1.MasterTableView.RenderColumns)
        {
            GridKnownFunction function = column.CurrentFilterFunction;

            column.ResetCurrentFilterValue();
            column.CurrentFilterFunction = function;
            column.RefreshCurrentFilterValue(filterItem);

            string expression = column.EvaluateFilterExpression();
            if (!string.IsNullOrWhiteSpace(expression))
            {
                expressionDetails[column.UniqueName] = new Pair(expression, column.CurrentFilterValue);
            }
        }
        //this is where you build the expression as desired
        RadGrid1.MasterTableView.FilterExpression = string.Join(" OR ", expressionDetails.Select(x => x.Value.First));
        RadGrid1.Rebind();
    }
    protected void RadGrid1_DataBinding(object sender, EventArgs e)
    {
        foreach (GridColumn column in RadGrid1.MasterTableView.RenderColumns)
        {
            if (expressionDetails.ContainsKey(column.UniqueName))
            {
                column.CurrentFilterValue = expressionDetails[column.UniqueName].Second.ToString();
            }
        }
    }
}