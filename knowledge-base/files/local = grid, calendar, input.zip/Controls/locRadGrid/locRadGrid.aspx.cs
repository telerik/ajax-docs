﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;

namespace Localization.Controls.locRadGrid
{
    public partial class locRadGrid : System.Web.UI.Page
    {
        private DataTable GetData()
        {
            DataTable table = new DataTable();
            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("Name", typeof(string));

            for (int i = 0; i < 50; i++)
                table.Rows.Add(i, "Name " + i / 2);
            return table;
        }
        protected override void InitializeCulture()
        {
            string currentCulture = Request["ddl1"] == null ? "" : Request["ddl1"].ToString();
            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(currentCulture);
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(currentCulture);
            base.InitializeCulture();
        }
        #region myRegion
        protected void RadGrid1_NeedDataSource(object source, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            (source as RadGrid).DataSource = GetData();
        }
        #endregion
    }
}
