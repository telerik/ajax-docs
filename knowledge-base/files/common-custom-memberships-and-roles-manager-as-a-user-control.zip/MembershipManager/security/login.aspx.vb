
Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Response.RedirectLocation = Request.Url.ToString()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Try
                Dim UserName As TextBox = CType(LoginView1.FindControl("Login1").FindControl("UserName"), TextBox)
                UserName.Focus()
            Catch
            End Try
        End If
        If User.Identity.IsAuthenticated Then
            Dim RoleView As MultiView = LoginView1.FindControl("MultiView1")
            If User.IsInRole("administrators") Then
                RoleView.ActiveViewIndex = 0
                Dim LastLoginDate As Label = LoginView1.FindControl("lblLastLoginDate1")
                LastLoginDate.Text = Membership.GetUser.LastLoginDate.ToString
            ElseIf User.IsInRole("publishers") Then
                RoleView.ActiveViewIndex = 1
                Dim LastLoginDate As Label = LoginView1.FindControl("lblLastLoginDate2")
                LastLoginDate.Text = Membership.GetUser.LastLoginDate.ToString
            Else
                RoleView.ActiveViewIndex = 2
                Dim LastLoginDate As Label = LoginView1.FindControl("lblLastLoginDate3")
                LastLoginDate.Text = Membership.GetUser.LastLoginDate.ToString
            End If

            If User.Identity.IsAuthenticated And User.Identity.Name = "bsolveit" Then
                Profile.Firstname = "Mark"
                Profile.Lastname = "McNeece"
                Profile.Company = "BSolve IT Limited"
            End If

        End If
    End Sub
End Class
