Imports System.Net.Mail
Imports System.Data.SqlClient
Imports System.Data

Partial Class security_create_user
    Inherits System.Web.UI.Page

    Protected Sub CreateUserWizard1_CreatedUser(ByVal sender As Object, ByVal e As System.EventArgs) Handles CreateUserWizard1.CreatedUser
        Roles.AddUserToRole(CreateUserWizard1.UserName, "users")
    End Sub

    Protected Sub CreateUserWizard1_NextButtonClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.WizardNavigationEventArgs) Handles CreateUserWizard1.NextButtonClick
        Dim Company As TextBox = CreateUserWizard1.FindControl("Company")
        If Company.Text = "" Then
            Company.Text = "None"
        End If
    End Sub

    Protected Sub CreateUserWizard1_SendingMail(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MailMessageEventArgs) 'Handles CreateUserWizard1.SendingMail
        Dim UserData As DataTable
        Dim sql As String = "SELECT aspnet_Membership.UserId, aspnet_Users.UserName, aspnet_Membership.PasswordQuestion, aspnet_Membership.PasswordAnswer FROM aspnet_Membership INNER JOIN aspnet_Users ON aspnet_Membership.UserId = aspnet_Users.UserId WHERE aspnet_Users.UserName = '{0}'"
        sql = [String].Format(sql, CreateUserWizard1.UserName)
        UserData = GetRoleData(sql)
        Dim newUser As DataRow = UserData.Rows(0)


        '*********************************************************************************************
        '*** If you want to send a confirmation email, uncomment these lines and populate as required
        '*********************************************************************************************

        'Dim NoReply As New MailAddress(Session("NoReplyAddress"), Session("CompanyName"))
        'e.Message.From = NoReply
        'e.Message.Body = e.Message.Body.Replace("<%FirstName%>", Trim(CType(CreateUserWizard1.FindControl("FirstName"), TextBox).Text))
        'e.Message.Body = e.Message.Body.Replace("<%LastName%>", Trim(CType(CreateUserWizard1.FindControl("LastName"), TextBox).Text))
        'e.Message.Body = e.Message.Body.Replace("<%CompanyName%>", Session("CompanyName"))
        'e.Message.Body = e.Message.Body.Replace("<%PasswordQuestion%>", CreateUserWizard1.Question)
        'e.Message.Body = e.Message.Body.Replace("<%PasswordAnswer%>", newUser("PasswordAnswer").ToString)
    End Sub

    Protected Sub CreateUserWizardStep1_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles CreateUserWizardStep1.Deactivate
        ProfileCommon.Create(CreateUserWizard1.UserName, True)

        Dim NewProfile As New ProfileCommon
        NewProfile = Profile.GetProfile(CreateUserWizard1.UserName)
        NewProfile.SetPropertyValue("Firstname", Trim(CType(CreateUserWizard1.FindControl("FirstName"), TextBox).Text))
        NewProfile.SetPropertyValue("Lastname", Trim(CType(CreateUserWizard1.FindControl("Lastname"), TextBox).Text))
        NewProfile.SetPropertyValue("Company", Trim(CType(CreateUserWizard1.FindControl("Company"), TextBox).Text))
        NewProfile.Save()
        LoadRoles()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            CreateUserWizard1.FindControl("FirstName").Focus()
        End If
        Dim RoleStep As WizardStep = CreateUserWizardStep2
        If Not User.IsInRole("administrators") Then
            CreateUserWizard1.WizardSteps.Remove(RoleStep)
        End If
    End Sub

    Private Function GetRoleData(ByVal query As String) As DataTable
        Dim dbCon As New SqlConnection(ConfigurationManager.ConnectionStrings("MembershipConnectionString").ConnectionString)
        dbCon.Open()

        Dim adapter As New SqlDataAdapter(query, dbCon)
        Dim dt As New DataTable()
        adapter.Fill(dt)
        dbCon.Close()

        Return dt
    End Function 'GetRoleData

    Private Sub LoadRoles()
        Dim dt As DataTable = GetRoleData("SELECT * FROM aspnet_Roles ORDER BY RoleName")
        CheckBoxList1.DataSource = dt
        CheckBoxList1.DataTextField = "RoleName"
        CheckBoxList1.DataValueField = "RoleID"
        CheckBoxList1.DataBind()

        Dim Query As String = "SELECT aspnet_Users.UserName, aspnet_Users.UserId, aspnet_Roles.RoleName FROM aspnet_UsersInRoles INNER JOIN aspnet_Users ON aspnet_UsersInRoles.UserId = aspnet_Users.UserId INNER JOIN aspnet_Roles ON aspnet_UsersInRoles.RoleId = aspnet_Roles.RoleId WHERE (aspnet_Users.UserName = '{0}')"
        Query = [String].Format(Query, CreateUserWizard1.UserName)
        Dim roles As DataTable = GetRoleData(Query)

        For Each row As DataRow In roles.Rows
            Dim RoleBox As ListItem = CheckBoxList1.Items.FindByText(row("RoleName"))
            RoleBox.Selected = True
            If RoleBox.Text = "users" Then
                RoleBox.Enabled = False
            End If
        Next
    End Sub

    Protected Sub CreateUserWizardStep2_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles CreateUserWizardStep2.Deactivate
        For Each rolebox As ListItem In CheckBoxList1.Items
            If rolebox.Selected = True Then
                If Not Roles.IsUserInRole(CreateUserWizard1.UserName, rolebox.Text) Then
                    Roles.AddUserToRole(CreateUserWizard1.UserName, rolebox.Text)
                End If
            Else
                If Roles.IsUserInRole(CreateUserWizard1.UserName, rolebox.Text) Then
                    Roles.RemoveUserFromRole(CreateUserWizard1.UserName, rolebox.Text)
                End If
            End If
        Next
    End Sub
End Class
