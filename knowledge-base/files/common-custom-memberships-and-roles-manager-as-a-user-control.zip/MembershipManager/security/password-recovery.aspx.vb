
Partial Class security_password_recovery
    Inherits System.Web.UI.Page

End Class
