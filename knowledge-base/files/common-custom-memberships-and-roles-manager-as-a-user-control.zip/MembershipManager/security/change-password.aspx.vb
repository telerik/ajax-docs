
Partial Class security_change_password
    Inherits System.Web.UI.Page

End Class
