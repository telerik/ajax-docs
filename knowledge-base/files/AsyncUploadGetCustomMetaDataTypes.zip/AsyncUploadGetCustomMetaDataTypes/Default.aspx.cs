﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;

public partial class Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = typeof(MySampleAsyncUploadConfiguration).AssemblyQualifiedName.Split(',')[0];


        // Populate the default (base) upload configuration into an object of type SampleAsyncUploadConfiguration
        MySampleAsyncUploadConfiguration config =
            RadAsyncUpload1.CreateDefaultUploadConfiguration<MySampleAsyncUploadConfiguration>();

        // Populate any additional fields
        config.SomeRandomValue = new Random().Next(1,5);

        // The upload configuration will be available in the handler
        RadAsyncUpload1.UploadConfiguration = config;

        RadAsyncUpload1.FileUploaded += new FileUploadedEventHandler(RadAsyncUpload1_FileUploaded);
    }

    protected void RadAsyncUpload1_FileUploaded(object sender, FileUploadedEventArgs e)
    {
        MySampleAsyncUploadResult result = e.UploadResult as MySampleAsyncUploadResult;
    }
}
