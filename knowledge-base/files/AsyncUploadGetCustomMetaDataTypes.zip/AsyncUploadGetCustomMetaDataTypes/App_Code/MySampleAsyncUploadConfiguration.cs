﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Web.UI;

/// <summary>
/// Summary description for MySampleAsyncUploadConfiguration
/// </summary>
public class MySampleAsyncUploadConfiguration : AsyncUploadConfiguration
{
    public int SomeRandomValue { get; set; }
}