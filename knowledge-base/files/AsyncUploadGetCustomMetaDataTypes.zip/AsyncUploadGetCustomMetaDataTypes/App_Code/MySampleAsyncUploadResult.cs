﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Web.UI;

/// <summary>
/// Summary description for MySampleAsyncUploadResult
/// </summary>
public class MySampleAsyncUploadResult : AsyncUploadResult
{
    public string CurrentTimeString { get; set; }
}
