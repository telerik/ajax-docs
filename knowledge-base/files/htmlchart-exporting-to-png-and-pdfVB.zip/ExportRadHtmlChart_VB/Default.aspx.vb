﻿Imports System.IO

Partial Class _Default
	Inherits System.Web.UI.Page

	Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
		'obtain the necessary settings for exporting the chart
		Dim currentSettings As New HtmlChartExportSettings()

		currentSettings.Height = CType(RadHtmlChart1.Height.Value, Integer)
		currentSettings.Width = CType(RadHtmlChart1.Width.Value, Integer)

		'decodes the SVG string saved from the client
        Dim svgText As String = HttpUtility.UrlDecode(svgHolder.Value, System.Text.Encoding.Default)

		'create a temporary SVG file that Inkscape will use
		currentSettings.SvgFilePath = Server.MapPath("~/App_Data/temp.svg")
		System.IO.File.WriteAllText(currentSettings.SvgFilePath, svgText)

		'get the export format - png or pdf
		currentSettings.Extension = rbl_ExportFormat.SelectedValue

		'the output file Inkscape will use, hardcoded to use App_Data as a temporary folder
		currentSettings.OutputFilePath = Server.MapPath("~/App_Data/exportedChart." + currentSettings.Extension)

		'you can change the name of the file the user will receive here. Extension is automatically added
		currentSettings.ClientFileName = "exportedChart"


		'the actual file is created
		HtmlChartExporter.ExportHtmlChart(currentSettings)

		'read the exported file and send it to the client
		Dim fileForClient As Byte() = HtmlChartExporter.ReadFile(currentSettings.OutputFilePath)
		Response.ContentType = HtmlChartExportSettings.ContentTypeList(currentSettings.Extension)
		Response.AddHeader("Content-Disposition", "attachment;filename=" + currentSettings.ClientFileName)
		Response.BinaryWrite(fileForClient)


		'delete the temporary files to avoid flooding the server
		File.Delete(currentSettings.OutputFilePath)
		File.Delete(currentSettings.SvgFilePath)

	End Sub
End Class
