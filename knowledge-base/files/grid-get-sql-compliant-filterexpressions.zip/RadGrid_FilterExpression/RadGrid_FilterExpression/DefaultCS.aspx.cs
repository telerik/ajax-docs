﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;
using System.Data.SqlClient;
using System.Text;
using System.Linq;

public partial class DefaultCS : System.Web.UI.Page
{
    public DataTable SessionDataSource
    {
        get
        {
            if (Session["SessionDataSource"] == null || !IsPostBack)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("OrderID");
                dt.Columns.Add("OrderDate");
                dt.Columns.Add("Freight");
                dt.Columns.Add("ShipName");
                dt.Columns.Add("ShipCountry");

                return dt;
            }

            return (DataTable)Session["SessionDataSource"];
        }

        set
        {
            Session["SessionDataSource"] = value;
        }
    }

    public string SqlFilterExpression
    {
        get
        {
            StringBuilder filterExpression = new StringBuilder();
            foreach (GridColumn column in RadGrid1.MasterTableView.RenderColumns)
            {
                if (!column.SupportsFiltering())
                {
                    continue;
                }

                string filterText = column.EvaluateFilterExpression();
                if (String.IsNullOrEmpty(filterText))
                {
                    continue;
                }

                GridDateTimeColumn dateTimeColumn = column as GridDateTimeColumn;
                if (dateTimeColumn != null && dateTimeColumn.EnableRangeFiltering)
                {
                    filterText = filterText.Replace(",", " ");
                }

                filterText = filterText.Replace(" True", " 'True'").Replace(" False", " 'False'");

                if (filterExpression.Length > 0)
                {
                    filterExpression.Append(" AND ");
                }

                filterExpression.AppendFormat("({0})", filterText);
            }

            return filterExpression.ToString();
        }
    }

    private string GetSqlFilterExpression(RadGrid grid)
    {
        StringBuilder filterExpression = new StringBuilder();
        foreach (GridColumn column in grid.MasterTableView.RenderColumns)
        {
            if (!column.SupportsFiltering())
            {
                continue;
            }

            string filterText = column.EvaluateFilterExpression();
            if (String.IsNullOrEmpty(filterText))
            {
                continue;
            }

            GridDateTimeColumn dateTimeColumn = column as GridDateTimeColumn;
            if (dateTimeColumn != null && dateTimeColumn.EnableRangeFiltering)
            {
                filterText = filterText.Replace(",", " ");
            }

            filterText = filterText.Replace(" True", " 'True'").Replace(" False", " 'False'");

            if (filterExpression.Length > 0)
            {
                filterExpression.Append(" AND ");
            }

            filterExpression.AppendFormat("({0})", filterText);
        }

        return filterExpression.ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        Label1.Text = RadGrid1.MasterTableView.FilterExpression;
        Label2.Text = SqlFilterExpression;
    }


    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        RadGrid1.DataSource = GetDataTable("SELECT OrderID, OrderDate, Freight, ShipName, ShipCountry, IsTrue FROM Orders");
    }


    public DataTable GetDataTable(string query)
    {
        DataTable myDataTable = new DataTable();

        if (!string.IsNullOrEmpty(query))
        {
            String ConnString = ConfigurationManager.ConnectionStrings["NorthwindConnection"].ConnectionString;
            SqlConnection conn = new SqlConnection(ConnString);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = new SqlCommand(query, conn);

            conn.Open();
            try
            {
                adapter.Fill(myDataTable);
            }
            finally
            {
                conn.Close();
            }
        }

        return myDataTable;
    }




    protected void RadButton1_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(SqlFilterExpression))
        {
            SessionDataSource = GetDataTable(string.Format("SELECT OrderID, OrderDate, Freight, ShipName, ShipCountry, IsTrue FROM Orders WHERE {0}", SqlFilterExpression));
        }
        RadGrid2.Rebind();
    }

    protected void RadGrid2_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        RadGrid2.DataSource = SessionDataSource;
    }
}
