﻿
Imports System.Data
Imports System.Data.SqlClient
Imports Telerik.Web.UI

Partial Class DefaultVB
    Inherits System.Web.UI.Page

    Public Property SessionDataSource As DataTable
        Get

            If Session("SessionDataSource") Is Nothing OrElse Not IsPostBack Then
                Dim dt As DataTable = New DataTable()
                dt.Columns.Add("OrderID")
                dt.Columns.Add("OrderDate")
                dt.Columns.Add("Freight")
                dt.Columns.Add("ShipName")
                dt.Columns.Add("ShipCountry")
                Return dt
            End If

            Return CType(Session("SessionDataSource"), DataTable)
        End Get
        Set(ByVal value As DataTable)
            Session("SessionDataSource") = value
        End Set
    End Property
    Public ReadOnly Property SqlFilterExpression As String
        Get
            Dim filterExpression As StringBuilder = New StringBuilder()

            For Each column As GridColumn In RadGrid1.MasterTableView.RenderColumns

                If Not column.SupportsFiltering() Then
                    Continue For
                End If

                Dim filterText As String = column.EvaluateFilterExpression()

                If String.IsNullOrEmpty(filterText) Then
                    Continue For
                End If

                Dim dateTimeColumn As GridDateTimeColumn = TryCast(column, GridDateTimeColumn)

                If dateTimeColumn IsNot Nothing AndAlso dateTimeColumn.EnableRangeFiltering Then
                    filterText = filterText.Replace(",", " ")
                End If

                filterText = filterText.Replace(" True", " 'True'").Replace(" False", " 'False'")

                If filterExpression.Length > 0 Then
                    filterExpression.Append(" AND ")
                End If

                filterExpression.AppendFormat("({0})", filterText)
            Next

            Return filterExpression.ToString()
        End Get
    End Property

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles Me.PreRender
        Label1.Text = RadGrid1.MasterTableView.FilterExpression
        Label2.Text = SqlFilterExpression
    End Sub

    Protected Sub RadGrid1_NeedDataSource(ByVal sender As Object, ByVal e As GridNeedDataSourceEventArgs)
        RadGrid1.DataSource = GetDataTable("SELECT OrderID, OrderDate, Freight, ShipName, ShipCountry, IsTrue FROM Orders")
    End Sub

    Public Function GetDataTable(ByVal query As String) As DataTable
        Dim myDataTable As DataTable = New DataTable()

        If Not String.IsNullOrEmpty(query) Then
            Dim ConnString As String = ConfigurationManager.ConnectionStrings("NorthwindConnection").ConnectionString
            Dim conn As SqlConnection = New SqlConnection(ConnString)
            Dim adapter As SqlDataAdapter = New SqlDataAdapter()
            adapter.SelectCommand = New SqlCommand(query, conn)
            conn.Open()

            Try
                adapter.Fill(myDataTable)
            Finally
                conn.Close()
            End Try
        End If

        Return myDataTable
    End Function

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As EventArgs)
        If Not String.IsNullOrEmpty(SqlFilterExpression) Then
            SessionDataSource = GetDataTable(String.Format("SELECT OrderID, OrderDate, Freight, ShipName, ShipCountry, IsTrue FROM Orders WHERE {0}", SqlFilterExpression))
        End If

        RadGrid2.Rebind()
    End Sub

    Public Function GetSqlFilterExpressions(ByVal grid As RadGrid) As String
        Dim filterExpression As StringBuilder = New StringBuilder()

        For Each column As GridColumn In grid.MasterTableView.RenderColumns

            If Not column.SupportsFiltering() Then
                Continue For
            End If

            Dim filterText As String = column.EvaluateFilterExpression()

            If String.IsNullOrEmpty(filterText) Then
                Continue For
            End If

            Dim dateTimeColumn As GridDateTimeColumn = TryCast(column, GridDateTimeColumn)

            If dateTimeColumn IsNot Nothing AndAlso dateTimeColumn.EnableRangeFiltering Then
                filterText = filterText.Replace(",", " ")
            End If

            filterText = filterText.Replace(" True", " 'True'").Replace(" False", " 'False'")

            If filterExpression.Length > 0 Then
                filterExpression.Append(" AND ")
            End If

            filterExpression.AppendFormat("({0})", filterText)
        Next

        Return filterExpression.ToString()
    End Function

    Protected Sub RadGrid2_NeedDataSource(ByVal sender As Object, ByVal e As GridNeedDataSourceEventArgs)
        RadGrid2.DataSource = SessionDataSource
    End Sub
End Class
