﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Text.RegularExpressions;

namespace MyExtensions.MyMailMerge
{
	public class MailMerge
	{
		private string content;
		private static readonly string startingMatchString = "#{";
		private static readonly string endingMatchString = "}";

		public static string StartMatchString 
		{
			get { return startingMatchString; }
		}

		public static string EndMatchString
		{
			get { return endingMatchString; }
		}

		public MailMerge(string htmlContent)
		{
			this.content = htmlContent;
		}

		public IEnumerable<string> GetMergedHtmlDocs(DataTable dataSource)
		{
			string template = GenerateTemplate(dataSource);

			List<string> docs = new List<string>(dataSource.Rows.Count);

			foreach (DataRow row in dataSource.Rows)
			{
				object[] rowAsArray = row.ItemArray;
				docs.Add(String.Format(template, rowAsArray));
			}

			return docs;
		}

		public string GetMergedHtml(DataRow dataRow)
		{
			string template = GenerateTemplate(dataRow.Table);

			if (template == null) return null;

			string result = String.Format(template, dataRow.ItemArray);

			return result;
		}

		private string GenerateTemplate(DataTable dataSource)
		{
			string template = this.content;
			Regex regex = new Regex(startingMatchString + "[^" + endingMatchString + "]*" + endingMatchString);
			Match match = regex.Match(template);

			while (match.Success)
			{
				string originalValue = match.Value;
				string trimmedValue = originalValue.TrimStart(startingMatchString.ToCharArray())
					.TrimEnd(endingMatchString.ToCharArray());

				MailMergeField field = new MailMergeField(trimmedValue, dataSource);
				string fieldExpression = field.GetFieldExpression();

				template = template.Replace(originalValue, "{" + fieldExpression + "}");

				match = match.NextMatch();
			}

			return template;
		}

		
	}


}