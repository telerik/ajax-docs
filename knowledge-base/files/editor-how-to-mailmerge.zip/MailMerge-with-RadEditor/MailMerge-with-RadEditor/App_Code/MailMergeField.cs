﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MyExtensions.MyMailMerge
{
	public class MailMergeField
	{
		private string originalField;
		private int fieldIndex;
		private string fieldAlignment;
		private string fieldFormatting;
		private DataTable dataTable;

		public int FieldIndex
		{
			get { return this.fieldIndex; }
		}

		public string FieldAlignment
		{
			get { return this.fieldAlignment; }
		}

		public string FieldFormatting
		{
			get { return this.fieldFormatting; }
		}

		public MailMergeField(string fieldValue, DataTable dataTable)
		{
			this.originalField = fieldValue;
			this.dataTable = dataTable;
			ProcessFieldExpression();
		}

		internal void ProcessFieldExpression()
		{
			string[] attributes = GetAttributes();

			this.fieldIndex = dataTable.Columns.IndexOf(attributes[0]);
			this.fieldAlignment = attributes[1];
			this.fieldFormatting = attributes[2];
		}

		private string[] GetAttributes()
		{
			int alignmentIndex = this.originalField.IndexOf(',');
			int formattingIndex = this.originalField.IndexOf(':');
			int fieldLenght = this.originalField.Length;

			string[] attributes = new string[3];

			if (alignmentIndex < 0 && formattingIndex < 0)
			{
				attributes[0] = this.originalField;
			}
			else if (alignmentIndex >= 0 && formattingIndex >= 0)
			{
				attributes = this.originalField.Split(new char[] { ':', ',' });
			}
			else if (formattingIndex >= 0)
			{
				string[] textAndFormat = this.originalField.Split(new char[] { ':' });
				attributes[0] = textAndFormat[0];
				attributes[2] = textAndFormat[1];
			}

			return attributes;
		}

		public string GetFieldExpression() 
		{
			string fieldExpression = this.fieldIndex.ToString();

			if (this.fieldAlignment != null) 
			{
				fieldExpression += "," + this.fieldAlignment;
			}

			if (this.fieldFormatting != null)
			{
				fieldExpression += ":" + this.fieldFormatting;
			}

			return fieldExpression;
		}
	}
}
