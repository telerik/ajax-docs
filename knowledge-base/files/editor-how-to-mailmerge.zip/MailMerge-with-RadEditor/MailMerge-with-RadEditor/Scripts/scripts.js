﻿(function (global, $, undefined) {
	var MailMerge = global.MailMerge = {};
	var _editorCommandList = _ajaxPanel = _previewWindow = undefined;
	var _MailMergeClass = "reMailMerge";
	var _FormatValueAttr = "mmformatvalue";

	/* The following variables should be set to the same values as the 
	   startingMatchString and endingMatchString readonly fields of 
	   the server-side MailMerge class.                                */
	var _StartingMatchString = "#{"
	var _EndingMatchString = "}";
	

	var registerMailMergeTools = function () {
		_editorCommandList["MailMergeFields"] = MailMerge.addField;
		_editorCommandList["EditFieldFormat"] = MailMerge.editFormat;
		_editorCommandList["PreviewMailMerge"] = MailMerge.previewDialog;
	}

	var registerMailMergeFilter = function (editor) {
		MailMerge.MailMergeFilter.registerClass('MailMerge.MailMergeFilter', Telerik.Web.UI.Editor.Filter);
		editor.get_filtersManager().add(new MailMerge.MailMergeFilter());

	}

	/* Initialization of the custom  client-side MailMerge tools and filter */

	MailMerge.init = function (sender, args) {
		var editor = sender;

		_editorCommandList = Telerik.Web.UI.Editor.CommandList;
		registerMailMergeTools();
		registerMailMergeFilter(editor);
	}

	MailMerge.registerAjaxPanel = function (stringId) {
		_ajaxPanel = $find(stringId);
	}

	MailMerge.registerPreviewDialog = function (stringId) {
		_previewWindow = $find(stringId);
	}

	/* Custom Tools */ 

	MailMerge.addField = function (commandName, editor, args) {
		editor.pasteHtml("<span class=" + _MailMergeClass + ">" + args.get_value() + "</span>");
	}

	MailMerge.editFormat = function (commandName, editor, args) {
		var selElm = $(editor.getSelectedElement());

		if (!selElm.is("." + _MailMergeClass)) return;

		selElm.attr(_FormatValueAttr, args.get_value());
	}

	MailMerge.previewDialog = function (commandName, editor, args) {
		_ajaxPanel.ajaxRequest();
		_previewWindow.show();
	}
	

	/* Custom MailMerge Filter */
	MailMerge.MailMergeFilter = function () {
		MailMerge.MailMergeFilter.initializeBase(this);
		this.set_isDom(true);
		this.set_enabled(true);
		this.set_name("MailMergeFilter");
		this.set_description("Replaces the custom formatting attributes to provide proper fields as per to the server-size MailMerge functionality.");
	};

	MailMerge.MailMergeFilter.prototype = {
		getHtmlContent: function (content) {
			var newContent = content;
			var mailMergeFields = $(newContent).find("." + _MailMergeClass);
			
			for (var i = 0; i < mailMergeFields.length; i++) {
				var field = $(mailMergeFields[i]);
				var formattingValue = field.attr(_FormatValueAttr);

				if (!formattingValue) continue;

				field.removeAttr(_FormatValueAttr);

				var fieldText = field.text();
				var regexp = new RegExp(_StartingMatchString + "(.*)" + _EndingMatchString, "gi");
				var replaceString = _StartingMatchString + "$1:" + formattingValue + _EndingMatchString;

				fieldText = fieldText.replace(regexp, replaceString);
				field.text(fieldText);
			};

			return newContent;
		},

		getDesignContent: function (content) {
			var newContent = content;
			var mailMergeFields = $(newContent).find("." + _MailMergeClass);


			for (var i = 0; i < mailMergeFields.length; i++) {
				var field = $(mailMergeFields[i]);
				var fieldValue = field.text();
				var fieldOptions = fieldValue.split(":");

				if (fieldOptions.length <= 1) continue;

				var fieldText = fieldOptions[0] + "}";
				var formattingValue = fieldOptions[1].replace("}", "");

				field.attr(_FormatValueAttr, formattingValue);
				field.text(fieldText);
			}

			return newContent;
		}
	};
})(window, $telerik.$, undefined);