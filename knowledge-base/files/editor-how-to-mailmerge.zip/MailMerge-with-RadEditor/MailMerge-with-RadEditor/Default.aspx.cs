﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Net.Mail;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Telerik.Web.UI;
using MyExtensions.MyMailMerge;

public partial class Default : System.Web.UI.Page
{

	# region Page Load
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			Grid.DataSource = GetDataSource();
			ConfigureMailMergeTools();
		}

	}
	# endregion

	# region Send Emails
	protected void SendEmails_Click(object sender, EventArgs e)
	{
		MailMerge mailMerge = new MailMerge(RadEditor1.Content);
		DataTable dataSource = GetDataSource();

		foreach (DataRow row in dataSource.Rows)
		{
			
			string emailBody = mailMerge.GetMergedHtml(row);
			
			//ToDo: Generate emails and send them.

		}
	}
	# endregion

	# region Creating MailMerge tools
	private void ConfigureMailMergeTools()
	{
		EditorToolGroup mailMergeTools = new EditorToolGroup();

		EditorDropDown addFieldTool = new EditorDropDown("MailMergeFields");
		addFieldTool.Text = "Insert Merge Field";
		addFieldTool.ShowText = true;
		addFieldTool.ShowIcon = false;

		PopulateFieldsTool(addFieldTool);
		mailMergeTools.Tools.Add(addFieldTool);

		EditorDropDown editFieldFormat = new EditorDropDown("EditFieldFormat");
		editFieldFormat.Text = "Edit Field Format";
		editFieldFormat.ShowText = true;
		editFieldFormat.ShowIcon = false;

		PopulateFormattingTools(editFieldFormat);
		mailMergeTools.Tools.Add(editFieldFormat);

		EditorTool previewTool = new EditorTool("PreviewMailMerge");
		previewTool.Text = "Preview Results";
		previewTool.ShowText = true;
		previewTool.ShowIcon = false;

		mailMergeTools.Tools.Add(previewTool);

		RadEditor1.Tools.Add(mailMergeTools);
	}

	private void PopulateFieldsTool(EditorDropDown addFieldTool)
	{
		DataColumnCollection columns = GetDataSource().Columns;
		string start = MailMerge.StartMatchString;
		string end = MailMerge.EndMatchString;


		foreach (DataColumn column in columns)
		{
			EditorDropDownItem item = new EditorDropDownItem();
			item.Name = column.ColumnName;
			item.Value = start + column.ColumnName + end;

			addFieldTool.Items.Add(item);
		}
	}

	private static void PopulateFormattingTools(EditorDropDown editFieldFormat)
	{
		// Generate DateTime formatting 
		EditorDropDownItem shortDateFormat = new EditorDropDownItem();
		shortDateFormat.Name = String.Format("Date & Time - <strong>{0:d}</strong>", new DateTime(2012, 11, 15)); // Description with example
		shortDateFormat.Value = "d"; // Modifier

		editFieldFormat.Items.Add(shortDateFormat);

		EditorDropDownItem stringDateFormat = new EditorDropDownItem();
		stringDateFormat.Name = String.Format("Date & Time - <strong>{0:D}</strong>", new DateTime(2012, 11, 15));
		stringDateFormat.Value = "D";

		editFieldFormat.Items.Add(stringDateFormat);

		EditorDropDownItem timeFormat = new EditorDropDownItem();
		timeFormat.Name = String.Format("Date & Time - <strong>{0:T}</strong>", new DateTime(2012, 11, 15, 12, 54, 36));
		timeFormat.Value = "T";

		editFieldFormat.Items.Add(timeFormat);

		EditorDropDownItem shortTimeFormat = new EditorDropDownItem();
		shortTimeFormat.Name = String.Format("Date & Time - <strong>{0:t}</strong>", new DateTime(2012, 11, 15, 12, 54, 36));
		shortTimeFormat.Value = "t";

		editFieldFormat.Items.Add(shortTimeFormat);

		// Generate Currency formatting for decimal values
		for (int i = 0; i < 4; i++)
		{
			EditorDropDownItem currencyFormat = new EditorDropDownItem();
			currencyFormat.Name = String.Format("Currency - <strong>{0:C"+ i +"}</strong>", 75.86d);
			currencyFormat.Value = "C" + i;

			editFieldFormat.Items.Add(currencyFormat);
		}
	}
	# endregion

	# region Preview MailMerge results dialog's binding
	protected void PreviewDocuments_NeedDataSource(object sender, RadDataFormNeedDataSourceEventArgs e)
	{
		MailMerge mailMerge = new MailMerge(RadEditor1.Content);
		string[] documents = mailMerge.GetMergedHtmlDocs(GetDataSource()).ToArray<string>();

		PreviewDocuments.DataSource = documents;
	}

	protected void RadAjaxPanel1_AjaxRequest(object sender, AjaxRequestEventArgs e)
	{
		PreviewDocuments_NeedDataSource(PreviewDocuments, new RadDataFormNeedDataSourceEventArgs(RadDataFormRebindReason.NotSpecified));
	}
	# endregion

	# region Data Source
	private DataTable GetDataSource()
	{
		DataTable dataSource = new DataTable("DummyDataSource");
		dataSource.Columns.Add("FirstName", typeof(String));
		dataSource.Columns.Add("LastName", typeof(String));
		dataSource.Columns.Add("Product", typeof(String));
		dataSource.Columns.Add("BoughtOn", typeof(DateTime));
		dataSource.Columns.Add("Price", typeof(Decimal));
		dataSource.Columns.Add("Email", typeof(String));

		dataSource.Rows.Add("Ana", "Trujillo", "Laptop ASUS", new DateTime(2012, 12, 20, 16, 35, 00), 998.52d, "fake1@fakemail.at");
		dataSource.Rows.Add("Alejandra", "Camino", "PC HP", new DateTime(2014, 05, 20, 05, 45, 00), 200.265d, "fake2@fakemail.at");
		dataSource.Rows.Add("Alexander", "Feuer", "MacBook Pro", new DateTime(2015, 01, 15, 12, 16, 00), 3356.52d, "fake3@fakemail.at");

		return dataSource;
	}
	# endregion
}
