﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using Telerik.Web.UI;
using System.Collections;
using System.Threading;

public partial class _Default : System.Web.UI.Page
{
    private static readonly Random random = new Random();

    static string[] contactNames = new string[] { "Antonio Moreno", "Elizabeth Lincoln", "Hanna Moos", "Jaime Yorres", "Georg Pipps", 
        "Pascale Cartrain", "Paul Henriot", "Matti Karttunen", "Patricio Simpson","Howard Snyder"};
    static string[] companyNames = new string[] { "Blauer See Delikatessen", "Folies gourmandes", "Hungry Coyote Import Store", "Let's Stop N Shop", 
            "B's Beverages", "QUICK-Stop", "Split Rail Beer & Ale", "Wartian Herkku","Sant� Gourmet","Romero y tomillo" };
    static string[] contactTitles = new string[] { "Marketing Assistant", "Sales Associate", "Sales Agent", "Sales Representative", 
            "Owner", "Sales Manager", "Accounting Manager","Marketing Manager","Sales Consultant","Accountant"};
    static string[] countries = new string[] { "Bulgaria", "USA", "Austria", "Germany", "Italy", "England", "Argentina", "Brazil", "France", "Spain" };
    static double[] ratings = { 2.5, 3.4, 1.5, 5.9, 7, 1.1, 5.5, 6.1, 3, 6.7 };

    public List<Customer> dataSource
    {
        get
        {
            object obj = Session["VirtualizationDataSource"];
            if (obj == null)
            {
                List<Customer> customers = new List<Customer>();
                for (int i = 0; i < 30017; i++) //30017
                {
                    int titlesIndex = random.Next() % 10;
                    int companyIndex = random.Next() % 10;
                    int contactIndex = random.Next() % 10;
                    int ratingIndex = random.Next() % 10;
                    int countryIndex = random.Next() % 10;
                    Customer customer = new Customer();
                    customer.ID = i;
                    customer.ContactTitle = contactTitles[titlesIndex];
                    customer.CompanyName = companyNames[companyIndex];
                    customer.ContactName = contactNames[contactIndex];
                    customer.Rating = ratings[ratingIndex];
                    customer.Country = countries[countryIndex];
                    customers.Add(customer);
                }
                Session["VirtualizationDataSource"] = customers;
            }
            return (List<Customer>)Session["VirtualizationDataSource"];
        }
        set
        {
            Session["VirtualizationDataSource"] = value;
        }
    }

    protected void RadGrid1_NeedDataSource(object source, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        RadGrid1.MasterTableView.VirtualItemCount = dataSource.Count;
        RadGrid1.DataSource = dataSource.GetRange(e.StartRowIndex, e.RowsCount);
    }

    [Serializable]
    public class Customer
    {
        public int ID { get; set; }
        public string CompanyName { get; set; }
        public string ContactName { get; set; }
        public string ContactTitle { get; set; }
        public string Country { get; set; }
        public double Rating { get; set; }
    }

  
}


