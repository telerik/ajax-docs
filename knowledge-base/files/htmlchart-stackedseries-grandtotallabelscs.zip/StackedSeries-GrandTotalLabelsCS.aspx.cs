﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GrandTotalLabelsCS : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		RadHtmlChart1.DataSource = GetData();
		RadHtmlChart1.DataBind();
	}
	protected DataTable GetData()
	{
		DataTable tbl = new DataTable();
		tbl.Columns.Add(new DataColumn("ID", typeof(int)));
		tbl.Columns.Add(new DataColumn("Year", typeof(string)));
		tbl.Columns.Add(new DataColumn("Gold", typeof(int)));
		tbl.Columns.Add(new DataColumn("Silver", typeof(int)));
		tbl.Columns.Add(new DataColumn("Bronze", typeof(int)));
		tbl.Columns.Add(new DataColumn("GrandTotal", typeof(decimal)));

		tbl.Rows.Add(new object[] { 1, "1988", 10, 12, 13, 0.00001 });
		tbl.Rows.Add(new object[] { 2, "1980", 08, 16, 17, 0.01 });
		tbl.Rows.Add(new object[] { 3, "1976", 06, 09, 07, 0.01 });

		return tbl;
	}
}