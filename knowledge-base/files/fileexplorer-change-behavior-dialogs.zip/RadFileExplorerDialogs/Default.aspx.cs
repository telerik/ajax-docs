﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Telerik.Web.UI.Widgets;
using System.IO;
using System.Reflection;
using System.Text;
using System.Data;
using System.Globalization;

public partial class _Default : RadAjaxPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}
