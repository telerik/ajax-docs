﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;
using System.Linq;

public partial class Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }


    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = OrdersTable(); 
    }
    private DataTable OrdersTable()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add(new DataColumn("OrderID", typeof(int)));
        dt.Columns.Add(new DataColumn("OrderDate", typeof(DateTime)));
        dt.Columns.Add(new DataColumn("Freight", typeof(double)));
        dt.Columns.Add(new DataColumn("ShipName", typeof(string)));
        dt.Columns.Add(new DataColumn("ShipCountry", typeof(string)));

        dt.PrimaryKey = new DataColumn[] { dt.Columns["OrderID"] };

        for (int i = 0; i < 100; i++)
        {
            int index = i + 1;

            DataRow row = dt.NewRow();

            row["OrderID"] = index;
            row["OrderDate"] = DateTime.Now.Date.AddDays(index);
            row["Freight"] = index * 0.01;
            row["ShipName"] = "Name " + index;
            row["ShipCountry"] = "Country " + index;

            dt.Rows.Add(row);
        }

        return dt;
    }


    protected void RadGrid1_ItemCreated(object sender, GridItemEventArgs e)
    {
        if (RadGrid1.IsExporting && e.Item is GridCommandItem)
        {
            e.Item.PrepareItemStyle();  //needed to span the image over the CommandItem cells
        }
    }


    protected void RadGrid1_InfrastructureExporting(object sender, GridInfrastructureExportingEventArgs e)
    {
        Telerik.Web.UI.ExportInfrastructure.Table table = e.ExportStructure.Tables[0];
        table.Rows[1].Height = 132;
        table.InsertImage(table.Cells[1, 1], "Img/small_banner.jpg", false);
    }

    protected void RadButton1_Click(object sender, EventArgs e)
    {
        RadGrid1.ExportToPdf();
    }

    protected void RadButton2_Click(object sender, EventArgs e)
    {
        RadGrid1.ExportToExcel();
    }

    protected void RadGrid1_PreRender(object sender, EventArgs e)
    {
        if (RadGrid1.IsExporting)
        {
            RadGrid1.MasterTableView.CommandItemDisplay = GridCommandItemDisplay.None;
            foreach (GridTemplateColumn col in RadGrid1.MasterTableView.RenderColumns.OfType<GridTemplateColumn>())
            {
                col.HeaderStyle.Width = Unit.Pixel(382);
            }

            foreach (GridDataItem item in RadGrid1.Items)
            {
                item.Height = Unit.Pixel(136);
            }
        }
    }

}
