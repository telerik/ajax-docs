﻿
Partial Class _Default
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim paths As String() = New String() {"/ROOT/"}
        RadFileExplorer1.Configuration.ViewPaths = paths

        Dim deletePaths As String() = New String() {"/ROOT/CanDelete/", "ROOT/CanDelAndUpload/"}
        RadFileExplorer1.Configuration.DeletePaths = deletePaths

        Dim uploadPaths As String() = New String() {"/ROOT/CanUpload/", "/ROOT/CanDelAndUpload/"}
        RadFileExplorer1.Configuration.UploadPaths = uploadPaths

        ' The "ROOT/CanDelAndUpload/" folder is configured with full permissions
        RadFileExplorer1.Configuration.ContentProviderTypeName = GetType(FtpContentProvider).AssemblyQualifiedName
    End Sub

End Class
