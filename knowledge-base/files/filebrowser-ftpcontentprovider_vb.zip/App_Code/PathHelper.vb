﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

''' <summary>
''' Supports features that are not implemented in the System.Web.VirtualPathUtility and SystemIO.Pat classes
''' </summary>
Public Class PathHelper
    ''' <summary>
    ''' Adds a symbol at the begining of a path if the symblol does not exist
    ''' </summary>
    ''' <param name="path"></param>
    ''' <param name="symbolToAdd"></param>
    ''' <returns>The modified path</returns>
    Public Shared Function AddStartingSymbol(ByVal path As String, ByVal symbolToAdd As Char) As String
        If path.StartsWith(symbolToAdd.ToString()) Then
            Return path
        Else
            Return symbolToAdd & path
        End If
    End Function

    ''' <summary>
    ''' Removes a symblol from the begining of a path
    ''' </summary>
    ''' <param name="path"></param>
    ''' <param name="symbolToRemove"></param>
    ''' <returns></returns>
    ''' 
    Public Shared Function RemoveStartingSymbol(ByVal path As String, ByVal symbolToRemove As Char) As String
        If path.StartsWith(symbolToRemove.ToString()) Then
            Return path.Substring(1)
        Else
            Return path
        End If
    End Function


    ''' <summary>
    ''' Adds a symbol at the end of a path if the symbol does not exist
    ''' </summary>
    ''' <param name="path"></param>
    ''' <param name="symbolToRemove"></param>
    ''' <returns>The modified path</returns>
    Public Shared Function AddEndingSymbol(ByVal path As String, ByVal symbolToAdd As Char) As String
        If path.EndsWith(symbolToAdd.ToString()) Then
            Return path
        Else
            Return path & symbolToAdd
        End If
    End Function

    ''' <summary>
    ''' Removes a backslash from the end of a path
    ''' </summary>
    ''' <param name="path"></param>
    ''' <returns>The modified path</returns>
    Public Shared Function RemoveEndingSymbol(ByVal path As String, ByVal symbolToRemove As Char) As String
        If path.EndsWith(symbolToRemove.ToString()) Then
            Return path.Substring(0, path.Length - 1)
        Else
            Return path
        End If
    End Function

    ''' <summary>
    ''' Gets the name of a directory.
    ''' Example C:\Folder1\Folder2 ==> the function returns 'Folder2' 
    ''' </summary>
    ''' <param name="ftpPath">A real path</param>
    ''' <returns></returns>
    Public Shared Function GetDirectoryName(ByVal ftpPath As String) As String
        ftpPath = RemoveEndingSymbol(ftpPath, "/"c)

        Dim lastIndexOfSlash As Integer = ftpPath.LastIndexOf("/")
        Dim name As String = ftpPath.Substring(lastIndexOfSlash + 1)
        Return name
    End Function

    ''' <summary>
    ''' Checks whether a path is child of another path
    ''' </summary>
    ''' <param name="virtualParent">Should be the virtual parent directory's path</param>
    ''' <param name="virtualChild">Should be the virtual child path. This parameter can be a path to file as well</param>
    ''' <returns></returns>
    Public Shared Function IsParentOf(ByVal virtualParent As String, ByVal virtualChild As String) As Boolean
        ' EXAMPLE :
        ' child : /F1/AAA_WW/F2/
        ' parent: /F1/AAA/F2/

        'ToDo: 
        ' This case is not handled:
        '   /F1/AAAAAA/F2/
        '   /F1/AAA
        If virtualChild.Equals(virtualParent, StringComparison.CurrentCultureIgnoreCase) Then
            Return False
        End If

        ' else if
        If virtualChild.StartsWith(virtualParent, StringComparison.CurrentCultureIgnoreCase) Then
            Return True
        End If

        ' else
        Return False
    End Function
End Class
