﻿Imports System.Collections.Generic
Imports System.Web
Imports Telerik.Web.UI.Widgets
Imports System.IO
Imports System.Xml
Imports System.Text.RegularExpressions
Imports FTP
Imports System.Configuration
Imports Utilities.FTP
Imports Utilities

''' <summary>
''' Summary description for FtpContentProvider
''' </summary>
Public Class FtpContentProvider
    Inherits FileBrowserContentProvider
    Private _itemHandlerPath As String

    ' A virtual folder, where the ftp files can be cached
    ' or the Path.GetTempFileName() method can be used instead
    Private _tempDirectory As String
    Private _protocolAndServer As String
    Private _userName As String
    Private _password As String
    Private _ftpConnection As FTPclient

    Public ReadOnly Property FtpConnection() As FTPclient
        Get
            Return Me._ftpConnection
        End Get
    End Property

    Protected ReadOnly Property ItemHandlerPath() As String
        Get
            Return Me._itemHandlerPath
        End Get
    End Property

    Public Sub New(ByVal context As HttpContext, ByVal searchPatterns As String(), ByVal viewPaths As String(), ByVal uploadPaths As String(), ByVal deletePaths As String(), ByVal selectedUrl As String, _
     ByVal selectedItemTag As String)
        MyBase.New(context, searchPatterns, viewPaths, uploadPaths, deletePaths, selectedUrl, _
         selectedItemTag)
        ' Read the configuration first
        Me.ReadConfiguration()

        ' User name is provided
        If Not String.IsNullOrEmpty(_userName) AndAlso Not String.IsNullOrEmpty(_password) Then
            ' Password is provided
            ' Use them
            Me._ftpConnection = New FTPclient(_protocolAndServer, _userName, _password)
        Else
            ' initialize FTPClient without user name and password
            Me._ftpConnection = New FTPclient(_protocolAndServer)
        End If

        Me._ftpConnection.UsePassive = True
        Me._ftpConnection.KeepAlive = True
    End Sub

    Private Sub ReadConfiguration()
        _protocolAndServer = VirtualPathUtility.RemoveTrailingSlash(ConfigurationManager.AppSettings("FtpServerName"))
        _userName = ConfigurationManager.AppSettings("UserName")
        _password = ConfigurationManager.AppSettings("Password")
        _tempDirectory = Context.Server.MapPath(VirtualPathUtility.AppendTrailingSlash(ConfigurationManager.AppSettings("TempDirectoryPath")))
        ' Use the physical path
        _itemHandlerPath = ConfigurationManager.AppSettings("ItemHandlerPath").Replace("~/", "")
        ' Remove the starting "~/" 
    End Sub

    Public Overrides Function ResolveRootDirectoryAsTree(ByVal path As String) As DirectoryItem
        path = VirtualPathUtility.RemoveTrailingSlash(path)
        path = PathHelper.AddStartingSymbol(path, "/"c)
        ' adds "/" to the beginning of the path Example: ROOT/FOLDER ==> /ROOT/FOLDER
        Dim subDirs As DirectoryItem() = Me.GetDirectories(path)
        Dim result As New DirectoryItem(PathHelper.GetDirectoryName(path), String.Empty, path, String.Empty, Me.GetPermissions(path), New FileItem() {}, _
         subDirs)

        Return result
    End Function

    Public Overrides Function ResolveDirectory(ByVal path As String) As DirectoryItem
        Dim childFiles As FileItem() = Me.GetFiles(path)
        Dim result As New DirectoryItem(PathHelper.GetDirectoryName(path), String.Empty, path, String.Empty, GetPermissions(path), childFiles, _
         New DirectoryItem() {})
        Return result
    End Function

    Public Overrides Function MoveDirectory(ByVal sourcePath As String, ByVal destPath As String) As String
        ' FtpCopyDirectory can return an error message
        Dim result As String = FtpCopyDirectory(sourcePath, destPath)

        If result <> String.Empty Then
            Return result
        End If
        ' Return the error message
        ' Else 
        result = DeleteDirectory(sourcePath)
        Return result
    End Function

    Public Overrides Function MoveFile(ByVal sourcePath As String, ByVal destPath As String) As String
        sourcePath = PathHelper.AddStartingSymbol(sourcePath, "/"c)
        destPath = PathHelper.AddStartingSymbol(destPath, "/"c)

        ' Check whether the file already exists in the destination folder ;
        If FtpConnection.FtpFileExists(destPath) Then
            ' Yes the file exists :
            Dim message As String = String.Format("The file '{0}' already exists", destPath)
            Return message
        End If

        ' There is not a permission issue with the FileExplorer's permissions ==> Move can be performed
        ' But, there can be some FtpFileSystem error 
        Try
            ' use rename for moving files ;
            Dim isSuccessful As Boolean = FtpConnection.FtpRename(sourcePath, destPath)

            If isSuccessful Then
                Return String.Empty
            Else

                Return "Unhandled exeption occured in 'CopyFile' method"
            End If
        Catch ex As Exception
            Return "Unhandled exeption occured in 'CopyFile' method"
        End Try
    End Function

    Public Overrides Function DeleteDirectory(ByVal targetPath As String) As String
        targetPath = VirtualPathUtility.RemoveTrailingSlash(targetPath)
        targetPath = PathHelper.AddStartingSymbol(targetPath, "/"c)

        ' First delete the files in the directory
        For Each fItem As FileItem In Me.GetFiles(targetPath)
            Dim err As String = DeleteFile(fItem.Path)
            If err <> String.Empty Then
                Return err
            End If
        Next

        ' then recursively delete the sub dirtectories 
        For Each dirItem As DirectoryItem In Me.GetDirectories(targetPath)
            Dim err As String = DeleteDirectory(dirItem.Path)
            If err <> String.Empty Then
                Return err
            End If
        Next

        ' Finally delete the current directory 
        Dim isDeleted As Boolean = FtpConnection.FtpDeleteDirectory(targetPath)
        If isDeleted Then
            Return String.Empty
        End If
        ' else 
        Return String.Format("The directory '{0}' cannot be deleted", targetPath)
    End Function

    Public Overrides Function DeleteFile(ByVal targetPath As String) As String
        Dim isDeleted As Boolean = FtpConnection.FtpDelete(targetPath)

        If isDeleted Then
            Return String.Empty
        End If

        ' else 
        Return String.Format("The file '{0}' cannot be deleted", targetPath)
    End Function

    Public Overrides Function CopyDirectory(ByVal sourcePath As String, ByVal destPath As String) As String
        sourcePath = PathHelper.AddStartingSymbol(sourcePath, "/"c)
        destPath = PathHelper.AddStartingSymbol(destPath, "/"c)

        ' The name of the folder that will be created
        Dim newFolderName As String = VirtualPathUtility.AppendTrailingSlash(destPath) & PathHelper.GetDirectoryName(sourcePath)

        ' FileSystem.CopyDirectory can return a string that contains the error or an empty string ;
        Dim errorMessage As String = FtpCopyDirectory(sourcePath, VirtualPathUtility.AppendTrailingSlash(newFolderName))
        Return errorMessage
    End Function

    Public Overrides Function CopyFile(ByVal sourcePath As String, ByVal destPath As String) As String
        ' Check whether the file already exists in the destination folder ;
        If FtpConnection.FtpFileExists(destPath) Then
            ' Yes the file exists
            Dim message As String = String.Format("The file '{0}' already exists. Operation is canceled!", destPath)
            Return message
        End If

        ' There is not a permission issue with the FileExplorer's permissions ==> Copy can be performed
        Try
            ' Get the file
            Dim fileStream As Stream = GetFile(sourcePath)

            If fileStream IsNot Nothing Then
                destPath = PathHelper.AddStartingSymbol(destPath, "/"c)
                ' Starting slash should be removed
                ' Upload the file to the new location
                Dim isSuccessful As Boolean = FtpConnection.Upload(fileStream, destPath)

                If isSuccessful Then
                    Return String.Empty
                Else
                    ' The operation is successful
                    Return "Unhandled exeption occured in 'CopyFile' method"
                End If
            Else
                Return "Unhandled exeption occured in 'CopyFile' method"
            End If
        Catch ex As Exception
            Return "Unhandled exeption occured in 'CopyFile' method"
        End Try
    End Function

    Public Overrides Function CreateDirectory(ByVal targetPath As String, ByVal name As String) As String
        targetPath = VirtualPathUtility.AppendTrailingSlash(targetPath)
        targetPath = PathHelper.AddStartingSymbol(targetPath, "/"c)
        Dim newFolderPath As String = targetPath & name

        If FtpConnection.FtpDirectoryExists(newFolderPath) Then
            Dim [error] As String = String.Format("The directory '{0}' already exists", newFolderPath)
            Return [error]
        End If

        ' There is not a restriction with the FileExplorer's permissions ==> Create can be performed
        ' but there can be some FtpFileSystems restrictions  
        Dim isCreated As Boolean = FtpConnection.FtpCreateDirectory(newFolderPath)
        If isCreated Then
            Return String.Empty
        Else
            ' no error
            Return "Unhandled exeption occured in 'CreateDirectory' method"
        End If
    End Function

    Public Overrides Function CheckReadPermissions(ByVal folderPath As String) As Boolean
        Dim hasPermission As Boolean = CheckPermissions(folderPath, PathPermissions.Read)
        Return hasPermission
    End Function

    Public Overrides Function CheckWritePermissions(ByVal virtualTargetPath As String) As Boolean
        Dim hasPermission As Boolean = CheckPermissions(virtualTargetPath, PathPermissions.Upload)
        Return hasPermission
    End Function

    Public Overrides Function CheckDeletePermissions(ByVal folderPath As String) As Boolean
        Dim hasPermission As Boolean = CheckPermissions(folderPath, PathPermissions.Delete)
        Return hasPermission
    End Function

    Public Overrides Function StoreFile(ByVal file As Telerik.Web.UI.UploadedFile, ByVal path As String, ByVal name As String, ByVal ParamArray arguments As String()) As String
        path = PathHelper.AddStartingSymbol(path, "/"c)
        Dim realPath As String = path & file.GetName()

        Try
            Dim isUploaded As Boolean = FtpConnection.Upload(file.InputStream, realPath)
            If isUploaded Then
                Return realPath
            Else

                ' or throw an exception:
                ' throw new ArgumentException("The new file was not uploaded!");
                Return Nothing
            End If
        Catch ex As Exception
            Return "Unhandled exeption occured in 'CreateDirectory' method"
        End Try
    End Function

    ' This function is obsolete
    Public Overrides Function StoreFile(ByVal file As HttpPostedFile, ByVal path As String, ByVal name As String, ByVal ParamArray arguments As String()) As String
        Throw New NotFiniteNumberException()
    End Function

    Public Overrides Function StoreBitmap(ByVal bitmap As System.Drawing.Bitmap, ByVal url As String, ByVal format As System.Drawing.Imaging.ImageFormat) As String
        Dim realPath As String = RemoveProtocolNameAndServerName(url)
        realPath = PathHelper.AddStartingSymbol(realPath, "/"c)
        Dim memStream As New MemoryStream()
        bitmap.Save(memStream, format)
        Try

            Dim isUploaded As Boolean = FtpConnection.Upload(memStream, realPath)
            If isUploaded Then
                Return realPath
            Else
                ' Or throw new ArgumentException("The new file was not uploaded!");
                Return Nothing
            End If
        Catch ex As Exception
            Return "Unhandled exeption occured in 'CreateDirectory' method"
        End Try
    End Function

    Public Overrides Function GetFileName(ByVal url As String) As String
        Return Path.GetFileName(RemoveProtocolNameAndServerName(url))
    End Function

    Public Overrides Function GetFile(ByVal url As String) As Stream
        Dim path As String = RemoveProtocolNameAndServerName(url)
        path = PathHelper.AddStartingSymbol(path, "/"c)

        While Not FtpConnection.FtpFileExists(path)
            Return Nothing
        End While

        Try
            Dim pathToCachFile As String = _tempDirectory & VirtualPathUtility.GetFileName(path)
            Dim isSuccessful As Boolean = FtpConnection.Download(path, pathToCachFile, True)

            If isSuccessful Then
                Dim fileStream As FileStream = File.OpenRead(pathToCachFile)
                Dim fileContent As Byte() = New Byte(fileStream.Length - 1) {}
                fileStream.Read(fileContent, 0, CInt(fileStream.Length))
                Dim memStream As New MemoryStream(fileContent)
                fileStream.Close()
                File.Delete(pathToCachFile)
                Return memStream
            Else
                If File.Exists(pathToCachFile) Then
                    File.Delete(pathToCachFile)
                End If

                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Overrides ReadOnly Property CanCreateDirectory() As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function GetPath(ByVal path As String) As String
        ' First add the '/' sign at the begining of the path in order to use the VirtualPathUtility.GetDirectory() method
        Dim pathWithTilde As String = PathHelper.AddStartingSymbol(path, "/"c)
        Dim virtualPath As String = VirtualPathUtility.GetDirectory(pathWithTilde)
        ' gets the parent directory's path
        Return virtualPath
    End Function

    Public Overrides ReadOnly Property PathSeparator() As Char
        Get
            Return "/"c
        End Get
    End Property

#Region "Helper functions"


    Private Function CheckPermissions(ByVal folderPath As String, ByVal permToCheck As PathPermissions) As Boolean
        'add a ending slash to the upload folder
        folderPath = folderPath.TrimEnd(PathSeparator) & PathSeparator


        Dim pathsToCheck As String()
        If (permToCheck And PathPermissions.Upload) <> 0 Then
            pathsToCheck = UploadPaths
        ElseIf (permToCheck And PathPermissions.Delete) <> 0 Then
            pathsToCheck = DeletePaths
        Else
            pathsToCheck = ViewPaths
        End If


        'Compare the 'folderPath' to all paths in the 'pathsToCheck' collection and check if it is a child or one of them.
        For Each pathToCheck As String In pathsToCheck
            If Not [String].IsNullOrEmpty(pathToCheck) AndAlso folderPath.StartsWith(pathToCheck, StringComparison.OrdinalIgnoreCase) Then
                ' Remove trailing slash from the path
                Dim trimmedPath As String = pathToCheck.TrimEnd(PathSeparator)
                'if (trimmedPath.Length == 0)
                '{
                '    //Path contains only the Path separator ==> give permissions everywhere
                '    return true;
                '}
                If folderPath.Length > trimmedPath.Length AndAlso folderPath(trimmedPath.Length) = PathSeparator Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    ''' <summary>
    ''' Returns the permissions for the provided virtual folder or file path
    ''' </summary>
    ''' <param name="virtualPath">The path to check the permissions</param>
    ''' <returns></returns>
    Private Function GetPermissions(ByVal virtualPath As String) As PathPermissions
        Dim permission As PathPermissions = PathPermissions.Read
        permission = If(CheckWritePermissions(virtualPath), permission Or PathPermissions.Upload, permission)
        permission = If(CheckDeletePermissions(virtualPath), permission Or PathPermissions.Delete, permission)

        Return permission
    End Function

    ''' <summary>
    ''' Gets the child directories of the passed virtual directory on the FTP server
    ''' </summary>
    ''' <param name="parentDirectoryPath">Path on the FTP server. 
    ''' Example: If the paths is somethisng like this:
    ''' ftp://localhost/rootfolder/PathToFolder/SubFolder/
    ''' The passed value is somethisng like this : /rootfolder/PathToFolder/SubFolder/ without the protocol and server name
    ''' </param>
    ''' <returns></returns>
    Private Function GetDirectories(ByVal parentDirectoryPath As String) As DirectoryItem()
        parentDirectoryPath = VirtualPathUtility.RemoveTrailingSlash(parentDirectoryPath)
        parentDirectoryPath = PathHelper.AddStartingSymbol(parentDirectoryPath, "/"c)
        Dim directoriesResult As New List(Of DirectoryItem)()
        ' Contains the result
        Try
            Dim dir As FTP.FTPdirectory = FtpConnection.ListDirectoryDetail(parentDirectoryPath)
            Dim ftpDirectories As FTP.FTPdirectory = dir.GetDirectories()
            For Each ftpDirInfo As FTPfileInfo In ftpDirectories.ToArray()

                ' The files and subfolders are added respectively in the 
                ' ResolveRootDirectory and ResolveRootDirectoryAsTree methods
                Dim dirItem As New DirectoryItem(ftpDirInfo.Filename, String.Empty, VirtualPathUtility.AppendTrailingSlash(ftpDirInfo.FullName), String.Empty, GetPermissions(ftpDirInfo.FullName), New FileItem() {}, _
                 New DirectoryItem() {})
                directoriesResult.Add(dirItem)
            Next
            ' Directory is not found 
        Catch ex As Exception
        End Try

        Return directoriesResult.ToArray()
    End Function


    ''' <summary>
    ''' Gets the child files of the passed virtual directory
    ''' </summary>
    ''' <param name="parentDirectoryPath">Path on the FTP server 
    ''' Example: If the paths is somethisng like this :
    ''' ftp://localhost/rootfolder/PathToFolder/SubFolder/
    ''' The passed value is somethisng like this : /rootfolder/PathToFolder/SubFolder/ without the protocol and server name
    ''' </param>
    ''' <returns></returns>
    Private Function GetFiles(ByVal parentDirectoryPath As String) As FileItem()
        Dim filesResult As New List(Of FileItem)()
        parentDirectoryPath = VirtualPathUtility.RemoveTrailingSlash(parentDirectoryPath)
        parentDirectoryPath = PathHelper.AddStartingSymbol(parentDirectoryPath, "/"c)

        Try
            Dim dir As FTP.FTPdirectory = FtpConnection.ListDirectoryDetail(parentDirectoryPath)
            Dim filteredFiles As New List(Of FTPfileInfo)()

            For Each filter As String In Me.SearchPatterns
                If filter = "*.*" Then
                    Dim ftpFiles As FTP.FTPdirectory = dir.GetFiles("")
                    filteredFiles.AddRange(ftpFiles.ToArray())
                Else
                    ' The filters cannot contain wildcards. The filtering is performed only by file extension. See the FTP.FTPdirectory.GetFiles method
                    Dim ftpDirectories As FTP.FTPdirectory = dir.GetFiles(filter)
                    filteredFiles.AddRange(ftpDirectories.ToArray())
                End If
            Next

            For Each ftpFileInfo As FTPfileInfo In filteredFiles
                Dim size As Long = ftpFileInfo.Size
                Dim url As String = (ItemHandlerPath & "?path=") + ftpFileInfo.FullName

                Dim fileItem As New FileItem(ftpFileInfo.Filename, ftpFileInfo.Extension, CInt(size), String.Empty, url, String.Empty, _
                 GetPermissions(ftpFileInfo.FullName))

                filesResult.Add(fileItem)
            Next
            ' The parent directory is moved or deleted
        Catch generatedExceptionName As Exception
        End Try

        Return filesResult.ToArray()
    End Function

    ''' <summary>
    ''' Physicaly copies a directory on the FTP server
    ''' </summary>
    ''' <param name="sourcePath">Path to the source directory, without the protocol and server name, e.g /Directory</param>
    ''' <param name="destPath">Path to the destination directory, without the protocol and server name, e.g /Directory</param>
    ''' <returns></returns>
    Private Function FtpCopyDirectory(ByVal sourcePath As String, ByVal destPath As String) As String
        sourcePath = PathHelper.AddStartingSymbol(sourcePath, "/"c)
        destPath = PathHelper.AddStartingSymbol(destPath, "/"c)

        ' Check whether the folder already exists in the destination folder ;
        If FtpConnection.FtpDirectoryExists(destPath) Then
            ' Yes the folder exists :
            Dim message As String = String.Format("The folder '{0}' already exists", destPath)
            Return message
        End If

        ' Check whether the source directory is parent of the destination directory ;
        If PathHelper.IsParentOf(sourcePath, destPath) Then
            Dim message As String = String.Format("The folder '{0}' is parent of the '{1} directory. Operation is canceled!", sourcePath, destPath)
            Return message
        End If

        Try
            destPath = VirtualPathUtility.RemoveTrailingSlash(destPath)
            ' The path should not have ending '/' symbol
            Dim isSuccessful As Boolean = FtpConnection.FtpCreateDirectory(VirtualPathUtility.RemoveTrailingSlash(destPath))
            If Not isSuccessful Then
                Return "Unhandled exeption occured in 'CopyDirectory' method"
            End If
            ' Else 
            ' Directory is created ==> copy the files
            Dim sourceFiles As FileItem() = Me.GetFiles(sourcePath)
            For Each fileItem As FileItem In sourceFiles
                Dim currentElementTarget As String = VirtualPathUtility.AppendTrailingSlash(destPath) & PathHelper.RemoveStartingSymbol(fileItem.Path.Replace(sourcePath, ""), "/"c)
                Dim err As String = CopyFile(fileItem.Path, currentElementTarget)
                If err <> String.Empty Then
                    Return err
                End If
            Next
            ' Files are copird

            ' Copy the sub folders
            Dim sourceDirectories As DirectoryItem() = Me.GetDirectories(sourcePath)
            For Each dirItem As DirectoryItem In sourceDirectories
                Dim currentFolderTarget As String = VirtualPathUtility.AppendTrailingSlash(destPath) + dirItem.Name
                Dim err As String = FtpCopyDirectory(dirItem.Path, currentFolderTarget)
                If err <> String.Empty Then
                    Return err
                End If
            Next

            Return String.Empty
        Catch ex As Exception
            Return "Unhandled exeption occured in 'CopyDirectory' method"
        End Try
    End Function

#End Region
End Class

