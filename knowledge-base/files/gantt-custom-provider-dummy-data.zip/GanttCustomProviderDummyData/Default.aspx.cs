﻿using System;

public partial class Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RadGantt1.Provider = new MyCustomProvider();
    }
}
