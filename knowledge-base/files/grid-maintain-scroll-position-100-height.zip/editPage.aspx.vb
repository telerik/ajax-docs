﻿
Partial Class editPage
    Inherits System.Web.UI.Page

End Class
