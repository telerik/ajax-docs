﻿
Imports System.Data
Imports Telerik.Web.UI

Partial Class mainPage
    Inherits System.Web.UI.Page

    Protected Sub RadAjaxManager1_AjaxRequest(sender As Object, e As AjaxRequestEventArgs) Handles RadAjaxManager1.AjaxRequest
        System.Threading.Thread.Sleep(2000) 'so that the loading panel is shown and you can see how the scrolling is persisted
        If e.Argument = "Rebind" Then
            rg1.MasterTableView.SortExpressions.Clear()
            rg1.MasterTableView.GroupByExpressions.Clear()
            rg1.Rebind()
        ElseIf e.Argument = "RebindAndNavigate" Then
            rg1.MasterTableView.SortExpressions.Clear()
            rg1.MasterTableView.GroupByExpressions.Clear()
            ' removed from the demo so the page does not change and persisting the scroll to the current item is possible
            'rg1.MasterTableView.CurrentPageIndex = rg1.MasterTableView.PageCount - 1
            rg1.Rebind()
        End If
    End Sub

    Protected Sub rg1_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles rg1.NeedDataSource

        Dim dataTable As New DataTable()

        Dim column As New DataColumn()
        column.DataType = Type.[GetType]("System.Int32")
        column.ColumnName = "OrderID"
        dataTable.Columns.Add(column)

        column = New DataColumn()
        column.DataType = Type.[GetType]("System.DateTime")
        column.ColumnName = "OrderDate"
        dataTable.Columns.Add(column)

        column = New DataColumn()
        column.DataType = Type.[GetType]("System.Decimal")
        column.ColumnName = "Freight"
        dataTable.Columns.Add(column)

        column = New DataColumn()
        column.DataType = Type.[GetType]("System.String")
        column.ColumnName = "ShipName"
        dataTable.Columns.Add(column)

        column = New DataColumn()
        column.DataType = Type.[GetType]("System.String")
        column.ColumnName = "ShipCountry"
        dataTable.Columns.Add(column)

        Dim PrimaryKeyColumns As DataColumn() = New DataColumn(0) {}
        PrimaryKeyColumns(0) = dataTable.Columns("OrderID")
        dataTable.PrimaryKey = PrimaryKeyColumns

        For i As Integer = 0 To 200
            Dim row As DataRow = dataTable.NewRow()
            row("OrderID") = i + 1
            row("OrderDate") = DateTime.Now
            row("Freight") = (i + 1) + (i + 1) * 0.1 + (i + 1) * 0.01
            row("ShipName") = "Name " & (i + 1)
            row("ShipCountry") = "Country " & (i + 1)

            dataTable.Rows.Add(row)
        Next

        DirectCast(sender, RadGrid).DataSource = dataTable

    End Sub


End Class
