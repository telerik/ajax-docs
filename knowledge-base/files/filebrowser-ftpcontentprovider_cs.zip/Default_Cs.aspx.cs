using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] paths = new string[] { "/ROOT/" };
        RadFileExplorer1.Configuration.ViewPaths = paths;

        string[] deletePaths = new string[] { "/ROOT/CanDelete/", "/ROOT/CanDelAndUpload/" };
        RadFileExplorer1.Configuration.DeletePaths = deletePaths;

        string[] uploadPaths = new string[] { "/ROOT/CanUpload/", "/ROOT/CanDelAndUpload/" };
        RadFileExplorer1.Configuration.UploadPaths = uploadPaths;

        // The "ROOT/CanDelAndUpload/" folder is configured with full permissions
        RadFileExplorer1.Configuration.ContentProviderTypeName = typeof(FtpContentProvider).AssemblyQualifiedName;
    }
}