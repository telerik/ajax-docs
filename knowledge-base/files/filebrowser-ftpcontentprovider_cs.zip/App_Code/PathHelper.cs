﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Supports features that are not implemented in the System.Web.VirtualPathUtility and SystemIO.Pat classes
/// </summary>
public class PathHelper
{
	/// <summary>
	/// Adds a symbol at the begining of a path if the symblol does not exist
	/// </summary>
	/// <param name="path"></param>
	/// <param name="symbolToAdd"></param>
	/// <returns>The modified path</returns>
	public static string AddStartingSymbol(string path, char symbolToAdd)
	{
		if (path.StartsWith(symbolToAdd.ToString()))
		{
			return path;
		}
		else
		{
			return symbolToAdd + path;
		}
	}

	/// <summary>
	/// Removes a symblol from the begining of a path
	/// </summary>
	/// <param name="path"></param>
	/// <param name="symbolToRemove"></param>
	/// <returns></returns>
	/// 
	public static string RemoveStartingSymbol(string path, char symbolToRemove)
	{
		if (path.StartsWith(symbolToRemove.ToString()))
		{
			return path.Substring(1);
		}
		else
		{
			return path;
		}
	}


	/// <summary>
	/// Adds a symbol at the end of a path if the symbol does not exist
	/// </summary>
	/// <param name="path"></param>
	/// <param name="symbolToRemove"></param>
	/// <returns>The modified path</returns>
	public static string AddEndingSymbol(string path, char symbolToAdd)
	{
		if (path.EndsWith(symbolToAdd.ToString()))
		{
			return path;
		}
		else
		{
			return path + symbolToAdd;
		}
	}

	/// <summary>
	/// Removes a backslash from the end of a path
	/// </summary>
	/// <param name="path"></param>
	/// <returns>The modified path</returns>
	public static string RemoveEndingSymbol(string path, char symbolToRemove)
	{
		if (path.EndsWith(symbolToRemove.ToString()))
		{
			return path.Substring(0, path.Length - 1);
		}
		else
		{
			return path;
		}
	}

	/// <summary>
	/// Gets the name of a directory.
	/// Example C:\Folder1\Folder2 ==> the function returns 'Folder2' 
	/// </summary>
	/// <param name="ftpPath">A real path</param>
	/// <returns></returns>
	public static string GetDirectoryName(string ftpPath)
	{
		ftpPath = RemoveEndingSymbol(ftpPath, '/');

		int lastIndexOfSlash = ftpPath.LastIndexOf("/");
		string name = ftpPath.Substring(lastIndexOfSlash + 1);
		return name;
	}

	/// <summary>
	/// Checks whether a path is child of another path
	/// </summary>
	/// <param name="virtualParent">Should be the virtual parent directory's path</param>
	/// <param name="virtualChild">Should be the virtual child path. This parameter can be a path to file as well</param>
	/// <returns></returns>
	public static bool IsParentOf(string virtualParent, string virtualChild)
	{
		// EXAMPLE :
		// child : /F1/AAA_WW/F2/
		// parent: /F1/AAA/F2/

		//ToDo: 
		// This case is not handled:
		//   /F1/AAAAAA/F2/
		//   /F1/AAA
		if (virtualChild.Equals(virtualParent, StringComparison.CurrentCultureIgnoreCase))
		{
			return false;
		}

		// else if
		if (virtualChild.StartsWith(virtualParent, StringComparison.CurrentCultureIgnoreCase))
		{
			return true;
		}

		// else
		return false;
	}
}
