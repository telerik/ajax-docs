﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class nested_ucs_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void rg1_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetData();
    }

    protected DataTable GetData()
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("data", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("text", typeof(string)));
        tbl.Columns.Add(new DataColumn("moreData", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("someColumn", typeof(string)));
        tbl.Rows.Add(new object[] { 1, "one", 2, "5" });
        tbl.Rows.Add(new object[] { 2, "two", 3, null/*SIMULATE EMPTY VALUE*/ });
        tbl.Rows.Add(new object[] { 3, "three", 4, "5" });
        tbl.Rows.Add(new object[] { 4, "four", 5, "5" });

        return tbl;
    }
}