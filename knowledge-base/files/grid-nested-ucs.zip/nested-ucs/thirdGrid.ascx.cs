﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class nested_ucs_thirdGrid : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        Label2.Text = ((this.NamingContainer as GridEditableItem).OwnerTableView.OwnerGrid.NamingContainer as nested_ucs_secondGrid).GetDataFromItem("text").ToString();
    }
}