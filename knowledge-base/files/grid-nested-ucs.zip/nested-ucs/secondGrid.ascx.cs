﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class nested_ucs_secondGrid : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        Label1.Text = GetDataFromItem("text");
    }

    public string GetDataFromItem(string field)
    {
        return (this.NamingContainer as GridEditableItem).GetDataKeyValue(field).ToString();
    }


    protected void rg1_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetData();
    }

    protected DataTable GetData()
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("data", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("labels", typeof(string)));
        tbl.Columns.Add(new DataColumn("moreData", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("someColumn", typeof(string)));
        tbl.Rows.Add(new object[] { 1, "the first", 2, "5" });
        tbl.Rows.Add(new object[] { 2, "the second", 3, null/*SIMULATE EMPTY VALUE*/ });
        tbl.Rows.Add(new object[] { 3, "the third", 4, "5" });
        tbl.Rows.Add(new object[] { 4, "the fourth", 5, "5" });

        return tbl;
    }
}