﻿using Telerik.Web.UI.Gantt;

public class CustomGanttTaskFactory : ITaskFactory
{
    Task ITaskFactory.CreateTask()
    {
        return new CustomTask();
    }
}
