﻿
using System.Collections.Generic;
using Telerik.Web.UI.Gantt;

public class CustomTask : Task
{
    public CustomTask()
        : base()
    {
    }

    public string Description
    {
        get { return (string) (ViewState["Description"] ?? ""); }
        set { ViewState["Description"] = value; }
    }

    public string MyCustomField
    {
        get { return (string) (ViewState["MyCustomField"] ?? ""); }
        set { ViewState["MyCustomField"] = value; }
    }

    protected override IDictionary<string, object> GetSerializationData()
    {
        var dict = base.GetSerializationData();
        dict["Description"] = Description;
        dict["MyCustomField"] = MyCustomField; 
        return dict;
    }

    public override void LoadFromDictionary(System.Collections.IDictionary values)
    {
        base.LoadFromDictionary(values);

        Description = (string) values["Description"];
        MyCustomField = (string) values["MyCustomField"];
    }
}