﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SourceListBox.DataSource = GetData();
            SourceListBox.DataBind();
        }
    }
    private static DataTable GetData()
    {
        string sql = "SELECT [SupplierID], [CompanyName], [ContactName], [City] FROM [Suppliers] ";
        SqlDataAdapter adapter = new SqlDataAdapter(sql,
            ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString);

        DataTable dt = new DataTable();
        adapter.Fill(dt);
        return dt;
    }
    protected void SourceListBox_ItemDataBound(object sender, RadListBoxItemEventArgs e)
    {
        e.Item.Text = ((DataRowView)e.Item.DataItem)["CompanyName"].ToString();
        e.Item.Value = ((DataRowView)e.Item.DataItem)["SupplierID"].ToString();

        e.Item.Attributes.Add("ContactName", "<b>" + ((DataRowView)e.Item.DataItem)["ContactName"].ToString() + "</b>");
        e.Item.Attributes.Add("City", ((DataRowView)e.Item.DataItem)["City"].ToString());

        e.Item.DataBind();
    }
    protected void SourceListBox_Transferred(object sender, RadListBoxTransferredEventArgs e)
    {
        foreach (RadListBoxItem item in e.Items)
        {
            item.DataBind();
        }

    }
}