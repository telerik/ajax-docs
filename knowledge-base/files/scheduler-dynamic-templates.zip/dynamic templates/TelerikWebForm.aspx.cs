﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;

public partial class TelerikWebForm : System.Web.UI.Page 
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (RadScheduler1.SelectedView != SchedulerViewType.MonthView)
            {
                RadScheduler1.AppointmentTemplate = new AppTemplate();
            }
            
        }
       
    }
    protected override void OnInit(EventArgs e)
    {
       
        base.OnInit(e);
        RadScheduler1.Provider = new XmlSchedulerProvider(Server.MapPath("~/App_Data/Appointments.xml"), true);
      
    }
    public class AppTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            Literal subject = new Literal();
            subject.DataBinding += subject_DataBinding;
            container.Controls.Add(subject);
        }

        private void subject_DataBinding(object sender, EventArgs e)
        {
           
            Literal subject = (Literal)sender;
            IDataItemContainer aptContainer = (IDataItemContainer)subject.BindingContainer;

            //Access the appointment object and set its AllowEdit property:
            SchedulerAppointmentContainer aptCont = (SchedulerAppointmentContainer)subject.Parent;
            Appointment app = aptCont.Appointment;
            app.AllowEdit = false;

            string strSubject = HttpUtility.HtmlEncode((string)DataBinder.Eval(aptContainer.DataItem, "Subject"));
            subject.Text = strSubject;
        }
    }
    protected void RadScheduler1_NavigationComplete(object sender, Telerik.Web.UI.SchedulerNavigationCompleteEventArgs e)
    {
        if (e.Command != SchedulerNavigationCommand.SwitchToMonthView)
        {
            RadScheduler1.AppointmentTemplate = new AppTemplate();
        }
    }
   
}
