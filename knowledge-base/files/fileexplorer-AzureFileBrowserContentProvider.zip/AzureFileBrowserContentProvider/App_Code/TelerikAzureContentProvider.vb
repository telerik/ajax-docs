﻿Imports Telerik.Web.UI.Widgets
Imports Microsoft.WindowsAzure.StorageClient
Imports Microsoft.WindowsAzure
Imports System.Collections.Generic

'=======================================================
'Built by Panos Tzirakis 
'Powered by http://www.hiweb.gr 
'=======================================================
Public Class TelerikAzureContentProvider
    Inherits FileBrowserContentProvider

    Private _cacheDuration As Integer = 600
    Private _Cache As Cache
    Private BatchProcess As Boolean = False
    Private fullPermissions As PathPermissions = PathPermissions.Read Or PathPermissions.Delete Or PathPermissions.Upload

    ''' <summary>
    ''' Dummmy file that is used in order to create folders
    ''' </summary>
    ''' <remarks></remarks>
    Private EmptyFileName As String = "deleteme.$$$"

    ''' <summary>
    ''' Defines the caching duration of the files and folders list. Whenever changes to the list occur, the cache is cleared.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property cacheDuration() As Integer
        Get
            Return _cacheDuration
        End Get
        Set(ByVal value As Integer)
            _cacheDuration = value
        End Set
    End Property
    Private ReadOnly Property Cache() As Cache
        Get
            If _Cache Is Nothing Then _Cache = Context.Cache
            Return _Cache
        End Get
    End Property
    Private Sub CacheData(ByRef key As String, ByRef data As Object)
        CacheData(key, data, cacheDuration)
    End Sub
    Private Sub CacheData(ByRef key As String, ByRef data As Object, ByVal cacheDuration As Integer)
        If Not IsNothing(data) Then
            Cache.Insert(key, data, Nothing, DateTime.Now.AddSeconds(cacheDuration), TimeSpan.Zero)
        End If
    End Sub
    Private Sub PurgeCacheItems(ByVal prefix As String)
        prefix = prefix.ToLower
        Dim itemsToRemove As New List(Of String)

        Dim enumerator As IDictionaryEnumerator = Cache.GetEnumerator()
        While enumerator.MoveNext
            If enumerator.Key.ToString.ToLower.StartsWith(prefix) Then
                itemsToRemove.Add(enumerator.Key.ToString)
            End If
        End While

        For Each itemToRemove As String In itemsToRemove
            Cache.Remove(itemToRemove)
        Next
    End Sub
    Private ReadOnly Property Root() As String
        Get
            Return GetAzureClient.BaseUri.ToString.TrimEnd("/") & "/" & GetTelerikContainer.Name
        End Get
    End Property

    ''' <summary>
    ''' Loads the files and folders structure and caches the result
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadContainerItems()
        If Not (IsNothing(Cache("TelerikAzure_Files")) Or IsNothing(Cache("TelerikAzure_Directories"))) Then
            Return
        End If

        Dim wFiles As New Dictionary(Of String, List(Of FileItem))
        Dim wDirectories As New Dictionary(Of String, List(Of String))

        EnsureContainerExists(GetTelerikContainer)

        wFiles.Clear()
        wDirectories.Clear()
        Dim options As BlobRequestOptions = New BlobRequestOptions()
        options.BlobListingDetails = BlobListingDetails.All
        options.UseFlatBlobListing = True
        For Each blobItem As IListBlobItem In GetAzureClient.ListBlobsWithPrefix(GetTelerikContainer.Name & "/", options)
            Dim blob = GetTelerikContainer().GetBlobReference(blobItem.Uri.ToString)
            Dim wFileName As String = blob.Uri.ToString.Replace(Root, "").TrimStart("/")
            Dim wDirectoryName As String = "/" & wFileName.Replace(IO.Path.GetFileName(wFileName), "").TrimEnd("/")
            blob.FetchAttributes()
            Dim wFileItem As New FileItem(IO.Path.GetFileName(wFileName), IO.Path.GetExtension(wFileName), blob.Attributes.Properties.Length, wFileName, blobItem.Uri.ToString, "", fullPermissions)

            If Not wFiles.ContainsKey(wDirectoryName) Then
                Dim Path As String = ""
                Dim ParentFolder = ""
                For Each wDirectory As String In wDirectoryName.Split("/")
                    Path = Path.TrimEnd("/") & "/" & wDirectory
                    If Not wDirectories.ContainsKey(Path) Then
                        wDirectories.Add(Path, New List(Of String))
                        If ParentFolder.Length > 0 Then
                            wDirectories(ParentFolder).Add(Path)
                        End If
                    End If
                    ParentFolder = Path
                Next
                wFiles.Add(wDirectoryName, New List(Of FileItem))
            End If
            If Not wFileItem.Name = EmptyFileName Then
                wFiles(wDirectoryName).Add(wFileItem)
            End If
        Next

        CacheData("TelerikAzure_Files", wFiles, cacheDuration)
        CacheData("TelerikAzure_Directories", wDirectories, cacheDuration)
    End Sub

    ''' <summary>
    ''' Gets the container name through a key in web.config AppSettings section. E.g. <add key="TelerikContainer" value="body"/>
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTelerikContainer() As CloudBlobContainer
        Dim client = GetAzureClient()

        Return client.GetContainerReference(ConfigurationManager.AppSettings("TelerikContainer").ToString)
    End Function

    ''' <summary>
    ''' Gets the Azure storage name through a key in web.config AppSettings section. E.g. <add key="DataConnectionString" value="UseDevelopmentStorage=true"/>
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetAzureClient() As CloudBlobClient
        ' Get a handle on account, create a blob storage client and get container proxy
        Dim account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString")
        Return account.CreateCloudBlobClient
    End Function
    Private Sub EnsureContainerExists(ByRef container As CloudBlobContainer)
        container.CreateIfNotExist()
        Dim permissions = container.GetPermissions()
        permissions.PublicAccess = BlobContainerPublicAccessType.Container
        container.SetPermissions(permissions)
    End Sub

    Public Sub New(ByVal context As HttpContext, ByVal searchPatterns As String(), ByVal viewPaths As String(), ByVal uploadPaths As String(), ByVal deletePaths As String(), ByVal selectedUrl As String, _
     ByVal selectedItemTag__1 As String)
        MyBase.New(context, searchPatterns, viewPaths, uploadPaths, deletePaths, selectedUrl, selectedItemTag__1)

        LoadContainerItems()
    End Sub

    Public Overrides Function CreateDirectory(ByVal path As String, ByVal name As String) As String
        Dim Filename As String = (path & name).TrimStart("/")
        Dim blob = GetTelerikContainer.GetBlobReference(Filename & "/" & EmptyFileName)
        blob.UploadText(".")
        PurgeCacheItems("TelerikAzure_")

        Return String.Empty
    End Function
    Public Overrides Function DeleteDirectory(ByVal path As String) As String
        BatchProcess = True

        Dim options As BlobRequestOptions = New BlobRequestOptions()
        options.BlobListingDetails = BlobListingDetails.All
        options.UseFlatBlobListing = True
        For Each blobItem As IListBlobItem In GetAzureClient.ListBlobsWithPrefix(GetTelerikContainer.Name & path, options)
            Dim wFileName As String = blobItem.Uri.ToString.Replace(Root, "")
            DeleteFile(wFileName)
        Next
        PurgeCacheItems("TelerikAzure_")
        BatchProcess = False
        Return String.Empty
    End Function

    Public Overrides Function DeleteFile(ByVal path As String) As String
        Dim blob = GetTelerikContainer.GetBlobReference(path.TrimStart("/"))
        blob.DeleteIfExists()
        If Not BatchProcess Then
            PurgeCacheItems("TelerikAzure_")
        End If

        Return String.Empty
    End Function

    Public Overrides Function GetFile(ByVal url As String) As System.IO.Stream
        url = url.TrimStart("/")
        Dim blob = GetTelerikContainer().GetBlobReference(url)
        Try
            Dim content As Byte() = blob.DownloadByteArray
            If Not [Object].Equals(content, Nothing) Then
                Return New IO.MemoryStream(content)
            End If
            Return Nothing
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Overrides Function GetFileName(ByVal url As String) As String
        Return IO.Path.GetFileName(url)
    End Function

    Public Overrides Function GetPath(ByVal url As String) As String
        Return url.Replace(GetFileName(url), "")
    End Function

    Private Function GetChildDirectories(ByVal path As String) As DirectoryItem()
        Dim wDirectories As Dictionary(Of String, List(Of String)) = Cache("TelerikAzure_Directories")

        Dim directories As New List(Of DirectoryItem)()
        Try
            For Each wDirectory As String In wDirectories(path)
                Dim wDirectoryName As String = IO.Path.GetFileName(wDirectory)

                directories.Add(New DirectoryItem(wDirectoryName, wDirectory, wDirectory, String.Empty, fullPermissions, GetChildFiles(wDirectory), GetChildDirectories(wDirectory)))
                'For Older Telerik Version
                'directories.Add(New DirectoryItem(wDirectoryName, String.Empty, wDirectory, String.Empty, fullPermissions, GetChildFiles(wDirectory), GetChildDirectories(wDirectory)))
            Next
            Return directories.ToArray()
        Catch generatedExceptionName As Exception
            Return New DirectoryItem() {}
        End Try
    End Function

    Private Function GetChildFiles(ByVal path As String) As FileItem()
        Dim wFiles As Dictionary(Of String, List(Of FileItem)) = Cache("TelerikAzure_Files")
        Try
            Dim wReturn As New List(Of FileItem)
            For Each wFile As FileItem In wFiles(path)
                If IsExtensionAllowed(wFile.Extension) Then
                    wReturn.Add(wFile)
                End If
            Next
            Return wReturn.ToArray

        Catch ex As Exception
            Return New FileItem() {}
        End Try
    End Function

    Public Overrides Function ResolveDirectory(ByVal path As String) As Telerik.Web.UI.Widgets.DirectoryItem
        Dim directories As DirectoryItem() = GetChildDirectories(path)
        Dim wDirectoryName As String = IO.Path.GetFileName(path)

        Return New DirectoryItem(wDirectoryName, path, path, String.Empty, fullPermissions, GetChildFiles(path), directories)
    End Function

    ''' <summary>
    ''' Loads a root directory with given path, where all subdirectories 
    ''' contained in the SelectedUrl property are loaded
    ''' </summary>
    ''' <remarks>
    ''' The ImagesPaths, DocumentsPaths, etc properties of RadEditor
    ''' allow multiple root items to be specified, separated by comma, e.g.
    ''' Photos,Paintings,Diagrams. The FileBrowser class calls the 
    ''' ResolveRootDirectoryAsTree method for each of them.
    ''' </remarks>
    ''' <param name="path">the root directory path, passed by the FileBrowser</param>
    ''' <returns>The root DirectoryItem or null if such does not exist</returns>
    Public Overrides Function ResolveRootDirectoryAsTree(ByVal path As String) As Telerik.Web.UI.Widgets.DirectoryItem
        Dim wDirectoryName As String = IO.Path.GetFileName(path)

        Dim returnValue As New DirectoryItem(wDirectoryName, path, path, String.Empty, fullPermissions, GetChildFiles(path), GetChildDirectories(path))
        Return returnValue
    End Function

    Public Overrides Function ResolveRootDirectoryAsList(ByVal path As String) As Telerik.Web.UI.Widgets.DirectoryItem()
        Return GetChildDirectories(path)
    End Function

    Public Overrides Function StoreBitmap(ByVal bitmap As System.Drawing.Bitmap, ByVal url As String, ByVal format As System.Drawing.Imaging.ImageFormat) As String
        Dim blob = GetTelerikContainer.GetBlobReference(url)
        Dim imgStream As New IO.MemoryStream
        If format.Equals(Drawing.Imaging.ImageFormat.Jpeg) Then
            blob.Properties.ContentType = "image/jpeg"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Gif) Then
            blob.Properties.ContentType = "image/gif"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Png) Then
            blob.Properties.ContentType = "image/png"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Icon) Then
            blob.Properties.ContentType = "image/icon"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Tiff) Then
            blob.Properties.ContentType = "image/tiff"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Wmf) Then
            blob.Properties.ContentType = "image/wmf"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Emf) Then
            blob.Properties.ContentType = "image/emf"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Exif) Then
            blob.Properties.ContentType = "image/exif"
        ElseIf format.Equals(Drawing.Imaging.ImageFormat.Bmp) Or format.Equals(Drawing.Imaging.ImageFormat.MemoryBmp) Then
            blob.Properties.ContentType = "image/bmp"
        End If
        bitmap.Save(imgStream, format)

        imgStream.Position = 0
        blob.UploadFromStream(imgStream)

        imgStream.Close()
        PurgeCacheItems("TelerikAzure_")

        Return String.Empty
    End Function

    Public Overloads Overrides Function StoreFile(ByVal file As Telerik.Web.UI.UploadedFile, ByVal path As String, ByVal name As String, ByVal ParamArray arguments() As String) As String
        Dim Filename As String = (path & name).TrimStart("/")

        Dim blob = GetTelerikContainer.GetBlobReference(Filename)
        blob.Properties.ContentType = file.ContentType
        blob.UploadFromStream(file.InputStream)
        PurgeCacheItems("TelerikAzure_")

        Return String.Empty
    End Function

    Public Overrides Function MoveFile(ByVal path As String, ByVal newPath As String) As String
        Dim Filename As String = path.TrimStart("/")
        Dim blobSource = GetTelerikContainer.GetBlobReference(Filename)
        Dim blobDestination = GetTelerikContainer.GetBlobReference(newPath.TrimStart("/"))
        Try
            blobDestination.CopyFromBlob(blobSource)
        Catch ex As Exception
        End Try
        blobSource.DeleteIfExists()
        If Not BatchProcess Then
            PurgeCacheItems("TelerikAzure_")
        End If

        Return String.Empty
    End Function

    Public Overrides Function MoveDirectory(ByVal path As String, ByVal newPath As String) As String
        BatchProcess = True

        Dim options As BlobRequestOptions = New BlobRequestOptions()
        options.BlobListingDetails = BlobListingDetails.All
        options.UseFlatBlobListing = True
        For Each blobItem As IListBlobItem In GetAzureClient.ListBlobsWithPrefix(GetTelerikContainer.Name & path, options)
            Dim wFileName As String = blobItem.Uri.ToString.Replace(Root, "")
            Dim wNewFileName As String = Replace(wFileName, path, newPath, , 1)
            MoveFile(wFileName, wNewFileName)
        Next

        PurgeCacheItems("TelerikAzure_")
        BatchProcess = False
        Return String.Empty
    End Function

    Public Overrides ReadOnly Property CanCreateDirectory() As Boolean
        Get
            Return True
        End Get
    End Property

    'For Older Telerik Version Delete keyword "Overrides"
    Public Overrides Function CheckWritePermissions(ByVal folderPath As String) As Boolean
        Return True
    End Function

    Private Function IsExtensionAllowed(ByVal extension As String) As Boolean
        Return Array.IndexOf(SearchPatterns, "*.*") >= 0 OrElse Array.IndexOf(SearchPatterns, "*" & extension.ToLower()) >= 0
    End Function

End Class

