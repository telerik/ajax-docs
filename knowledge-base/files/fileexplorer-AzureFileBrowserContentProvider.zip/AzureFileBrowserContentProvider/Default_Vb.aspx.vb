﻿


Partial Class Default_Vb
	Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        RadEditor1.ImageManager.ContentProviderTypeName = GetType(TelerikAzureContentProvider).AssemblyQualifiedName
        RadEditor1.MediaManager.ContentProviderTypeName = RadEditor1.ImageManager.ContentProviderTypeName
        RadEditor1.FlashManager.ContentProviderTypeName = RadEditor1.ImageManager.ContentProviderTypeName
        RadEditor1.TemplateManager.ContentProviderTypeName = RadEditor1.ImageManager.ContentProviderTypeName
        RadEditor1.DocumentManager.ContentProviderTypeName = RadEditor1.ImageManager.ContentProviderTypeName

        Dim Path() As String = New String() {"/"}
        RadEditor1.ImageManager.ViewPaths = Path
        RadEditor1.ImageManager.UploadPaths = Path
        RadEditor1.ImageManager.DeletePaths = Path

        RadEditor1.MediaManager.ViewPaths = RadEditor1.ImageManager.ViewPaths
        RadEditor1.MediaManager.UploadPaths = RadEditor1.ImageManager.UploadPaths
        RadEditor1.MediaManager.DeletePaths = RadEditor1.ImageManager.DeletePaths

        RadEditor1.FlashManager.ViewPaths = RadEditor1.ImageManager.ViewPaths
        RadEditor1.FlashManager.UploadPaths = RadEditor1.ImageManager.UploadPaths
        RadEditor1.FlashManager.DeletePaths = RadEditor1.ImageManager.DeletePaths

        RadEditor1.TemplateManager.ViewPaths = RadEditor1.ImageManager.ViewPaths
        RadEditor1.TemplateManager.UploadPaths = RadEditor1.ImageManager.UploadPaths
        RadEditor1.TemplateManager.DeletePaths = RadEditor1.ImageManager.DeletePaths

        RadEditor1.DocumentManager.ViewPaths = RadEditor1.ImageManager.ViewPaths
        RadEditor1.DocumentManager.UploadPaths = RadEditor1.ImageManager.UploadPaths
        RadEditor1.DocumentManager.DeletePaths = RadEditor1.ImageManager.DeletePaths
    End Sub
End Class
