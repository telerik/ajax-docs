﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class send_file_from_tooltip_WebUserControl : System.Web.UI.UserControl
{
    //a standarda approach for sending data from the main page to the user control when it is being loaded
    public string ProductID
    {
        get
        {
            if (ViewState["ProductID"] == null)
            {
                return "";
            }
            return (string)ViewState["ProductID"];
        }
        set
        {
            ViewState["ProductID"] = value;
        }
    }

    //used for getting a reference to the button
    public Button theExportButton
    {
        get
        {
            return Button1;
        }
    }

    //exports the grid. Normally, won't work from withing a toltip manager because it would be a partial postback
    //the code in the aspx page makes it a full postback by registering the button as a postback trigger
    protected void Button1_Click(object sender, EventArgs e)
    {
        rg1.ExportToExcel();
    }

    //get some dummy data for the grid based on the target the tooltip is associated with
    protected void rg1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetData(int.Parse(ProductID));
    }

    protected DataTable GetData(int startIndex)
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("someField", typeof(int)));
        for (int i = 0; i < 5; i++)
        {
            tbl.Rows.Add(new object[] { startIndex + i });
        }

        return tbl;
    }
}