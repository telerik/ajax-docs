﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class send_file_from_tooltip_Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //a postback occurs, a tooltip had been shown, we re-create its contents
        if (ViewState["tooltipIsShown"] != null &&
            RadToolTipManager1.UpdatePanel.ContentTemplateContainer.Controls.Count == 0)
        {
            //the viewstate flag can store the value needed for the tooltip so it can be passed to UpdateToolTip()
            UpdateToolTip(ViewState["tooltipIsShown"].ToString(), RadToolTipManager1.UpdatePanel);
        }

        //recognize the postback from the button and attach a handler to it
        if (ViewState["tooltipIsShown"] != null &&
            RadToolTipManager1.UpdatePanel.ContentTemplateContainer.Controls.Count > 0)
        {
            //note for the cast to work you must register the user control in the aspx page
            send_file_from_tooltip_WebUserControl uc = RadToolTipManager1.UpdatePanel.ContentTemplateContainer.Controls[0] as send_file_from_tooltip_WebUserControl;
            //properties in the user control can expose controls, events, data as needed
            Button btn = uc.theExportButton;
            if (btn != null)
            {
                //one way to attach a handler that will live in the page, alternatively, use the user control events
                //btn.Click += new EventHandler(ucCredentialNumberDetail_ButtonReportDetail_Click);
                ScriptManager.GetCurrent(Page).RegisterPostBackControl(btn);
            }
        }
    }

    protected void OnAjaxUpdate(object sender, ToolTipUpdateEventArgs args)
    {
        if (args.TargetControlID == "target") //recognize the concrete target you want to do this for, skip the check if you want to do it for all targets
        {
            ViewState["tooltipIsShown"] = args.Value;
            //store the args.Value information to the ViewState here for later use so the user control can be re-created with the proper data
        }
        else
        {
            ViewState["tooltipIsShown"] = null;
        }
        UpdateToolTip(args.Value, args.UpdatePanel);
    }

    private void UpdateToolTip(string identifier, UpdatePanel panel)
    {
        //the class name depends on the project's structure, it should not be relevant to the case
        Control ctrl = Page.LoadControl("WebUserControl.ascx");
        panel.ContentTemplateContainer.Controls.Add(ctrl);
        send_file_from_tooltip_WebUserControl details = (send_file_from_tooltip_WebUserControl)ctrl;
        details.ProductID = identifier;
    }

    protected void ucCredentialNumberDetail_ButtonReportDetail_Click(object sender, EventArgs e)
    {
        //a simple example in case the content you want to send is generic and not dependent on the tooltip but on the page
        //you need to uncomment the line that adds this event handler from Page_Load since you can't send two files at a time

        HttpContext.Current.Response.Clear();

        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + "someFile.txt");
        HttpContext.Current.Response.ContentType = "application/octet-stream";
        HttpContext.Current.Response.WriteFile("~/send_file_from_tooltip/testFile.txt");
        HttpContext.Current.Response.End();

        Response.Clear();
    }

}