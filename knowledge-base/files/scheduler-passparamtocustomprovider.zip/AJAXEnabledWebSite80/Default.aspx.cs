using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;

public partial class _Default : MyPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            RadScheduler1.SelectedView = SchedulerViewType.WeekView;
        }
        //Show only lectures by Mr John Doe
        MyParam = "Mr John Doe";

        //Show only lectures by Mrs Jane Smith
        //MyParam = "Mrs Jane Smith";         
    }
}