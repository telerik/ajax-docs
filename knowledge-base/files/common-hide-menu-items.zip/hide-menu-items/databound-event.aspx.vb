﻿
Imports System.Data
Imports Telerik.Web.UI
Partial Class hide_menu_items_databound_event
    Inherits System.Web.UI.Page
    Protected Function GetData() As DataTable
        Dim tbl As New DataTable()
        tbl.Columns.Add(New DataColumn("textField"))
        tbl.Columns.Add(New DataColumn("metaData"))
        tbl.Columns.Add(New DataColumn("ID"))
        tbl.Columns.Add(New DataColumn("role"))
        tbl.Rows.Add(New Object() {"first", "all", 1, "one"})
        tbl.Rows.Add(New Object() {"second", "restricted", 2, "two"})
        tbl.Rows.Add(New Object() {"third", "all", 3, "three"})
        'OPTION 1 -  add a check when building the data source
        If Not True Then 'replace with actual check, of course
            tbl.Rows.Add(New Object() {"fourth", "all", 4, "four"})
        End If
        Return tbl
    End Function
    Protected Sub RadMenu1_ItemDataBound(ByVal sender As Object, ByVal e As RadMenuEventArgs) Handles RadMenu1.ItemDataBound
        'OPTION 2 - set the Visible property to false for particular items after they are data bound
        If e.Item.Text = "third" Then 'replace with real check
            'or use the DataItem in case you have meta data https://docs.telerik.com/devtools/aspnet-ajax/controls/menu/server-side-programming/itemdatabound
            e.Item.Visible = False
        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            RadMenu1.DataSource = GetData()
            RadMenu1.DataBind()
        End If
    End Sub
End Class
