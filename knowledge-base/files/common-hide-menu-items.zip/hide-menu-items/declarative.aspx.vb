﻿
Imports Telerik.Web.UI

Partial Class hide_menu_items_declarative
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If True Then 'replace with actual user rights check
            Dim itemToHide As RadMenuItem = RadMenu1.FindItemByValue("payroll") 'you can use the other FindItem... options as well
            If Not Object.Equals(itemToHide, Nothing) Then
                itemToHide.Visible = False
            End If
        End If
    End Sub


End Class
