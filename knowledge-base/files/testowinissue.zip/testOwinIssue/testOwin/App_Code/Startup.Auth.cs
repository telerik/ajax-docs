﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IdentityModel.Claims;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OpenIdConnect;
using Owin;


/// <summary>
/// Summary description for Startup
/// </summary>
namespace CP
{
    public partial class Startup
    {
        public void ConfigureAuth(IAppBuilder app)
        {
            string ClientId ="";
            //fixed address for multitenant apps in the public cloud
            string Authority = "https://login.microsoftonline.com/common/";

            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);

            app.UseCookieAuthentication(new CookieAuthenticationOptions { });
           
            app.UseOpenIdConnectAuthentication(
                new OpenIdConnectAuthenticationOptions
                {
                    ClientId = ClientId,
                    Authority = Authority,
                    TokenValidationParameters = new System.IdentityModel.Tokens.TokenValidationParameters
                    {
                        // instead of using the default validation (validating against a single issuer value, as we do in line of business apps), 
                        // we inject our own multitenant validation logic
                        ValidateIssuer = false,
                    },
                    Notifications = new OpenIdConnectAuthenticationNotifications()
                    {
                        AuthorizationCodeReceived = (context) =>
                        {
                            var code = context.Code;
                            var tenantId = context.AuthenticationTicket.Identity.FindFirst("http://schemas.microsoft.com/identity/claims/tenantid").Value;

                            ClientCredential credential = new ClientCredential("asa", "asas");
                            String UserObjectId = context.AuthenticationTicket.Identity.FindFirst(ClaimTypes.NameIdentifier).Value;
                            Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext authContext = new Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext("");
                            authContext.AcquireTokenByAuthorizationCode(code, new Uri(HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Path)), credential, "");
                            return Task.FromResult(0);
                        },
                        RedirectToIdentityProvider = (context) =>
                        {
                            // This ensures that the address used for sign in and sign out is picked up dynamically from the request
                            // this allows you to deploy your app (to Azure Web Sites, for example)without having to change settings
                            // Remember that the base URL of the address used here must be provisioned in Azure AD beforehand.
                            string appBaseUrl = "";// clsCommon.p_ApplicationUrl_WithoutPort + "mcologinhandle.aspx";//context.Request.Scheme + "://" + context.Request.Host + context.Request.PathBase;
                            context.ProtocolMessage.RedirectUri = appBaseUrl;
                            context.ProtocolMessage.PostLogoutRedirectUri = "";// clsCommon.p_ApplicationUrl_WithoutPort + "login.aspx";
                            return Task.FromResult(0);
                        },
                        // we use this notification for injecting our custom logic
                        SecurityTokenValidated = (context) =>
                        {
                            // retriever caller data from the incoming principal
                            string issuer = context.AuthenticationTicket.Identity.FindFirst("iss").Value;
                            string UPN = context.AuthenticationTicket.Identity.FindFirst(ClaimTypes.Name).Value;
                            string tenantID = context.AuthenticationTicket.Identity.FindFirst("http://schemas.microsoft.com/identity/claims/tenantid").Value;

                            //clsClientTenantEAL objClientTenantEAL = new clsClientTenantEAL();
                            //clsClientTenantDAL objClientTenantDAL = new clsClientTenantDAL();


                            // Is this a response to a request we generated? Let's see if the state is carrying an ID we previously saved
                            // ---if we don't, return an error            
                            //objClientTenantEAL.issValue = "1";
                            //objClientTenantEAL.adminConsented = true;

                            DataTable dt = new DataTable();//objClientTenantDAL.Validate_Tenant(issuer);

                            if (dt.Rows[0]["IsValid"].ToString() == "0")
                                //if (
                                //    // the caller comes from an admin-consented, recorded issuer
                                //    (db.Tenants.FirstOrDefault(a => ((a.IssValue == issuer) && (a.AdminConsented))) == null)
                                //    // the caller is recorded in the db of users who went through the individual onboardoing
                                //    && (db.Users.FirstOrDefault(b => ((b.UPN == UPN) && (b.TenantID == tenantID))) == null)
                                //    )
                                // the caller was neither from a trusted issuer or a registered user - throw to block the authentication flow
                                throw new SecurityTokenValidationException();
                            return Task.FromResult(0);
                        },
                        AuthenticationFailed = (context) =>
                        {
                            System.Web.HttpContext.Current.Response.Redirect("~/login.aspx?gf=1");
                            context.HandleResponse(); // Suppress the exception
                            return Task.FromResult(0);
                        }
                    }
                });
        }
    }
}