﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class programmatic_sm_and_ram : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //when creating the script manager programmatically, you need to create
        //the RadAjaxManager programmatically as well
        ScriptManager scriptMgr = RadScriptManager.GetCurrent(this.Page);
        RadScriptManager telScriptMgr = scriptMgr as RadScriptManager;
        if (scriptMgr == null)
        {
            telScriptMgr = new RadScriptManager();
            telScriptMgr.ID = "rsm1";
            this.Page.Form.Controls.AddAt(0, telScriptMgr);
        }

        RadAjaxManager ram = RadAjaxManager.GetCurrent(this.Page);
        if (ram == null)
        {
            ram = new RadAjaxManager();
            ram.ID = "RadAjaxManager1";
            ram.DefaultLoadingPanelID = "ralp1";
            ram.AjaxRequest += RadAjaxManager1_AjaxRequest;
            this.Page.Form.Controls.AddAt(1, ram);
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //AjaxSettings must be added in Page_Load: https://docs.telerik.com/devtools/aspnet-ajax/controls/ajaxmanager/how-to/add-ajaxsettings-programmatically
        RadAjaxManager ram = RadAjaxManager.GetCurrent(this.Page);
        ram.AjaxSettings.AddAjaxSetting(ram, Panel1);
        ram.AjaxSettings.AddAjaxSetting(Panel1, Panel1);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(1000);
        lblResult.Text = string.Format("submit from button at: <strong>{0}</strong>", DateTime.Now.ToString());
    }

    protected void RadAjaxManager1_AjaxRequest(object sender, Telerik.Web.UI.AjaxRequestEventArgs e)
    {
        System.Threading.Thread.Sleep(1000);
        lblResult.Text = string.Format("POST from RAM at: <strong>{0}</strong> with arg: {1}", DateTime.Now.ToString(), e.Argument);
    }
}