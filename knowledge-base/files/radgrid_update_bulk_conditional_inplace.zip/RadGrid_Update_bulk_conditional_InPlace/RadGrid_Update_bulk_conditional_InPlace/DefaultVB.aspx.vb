﻿
Imports System.Data
Imports Telerik.Web.UI

Partial Class DefaultVB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
    End Sub

    Public ReadOnly Property SessionDataSource As DataTable
        Get
            Dim sessionKey As String = "SessionDataSource"

            If Session(sessionKey) Is Nothing OrElse Not IsPostBack Then
                Session(sessionKey) = OrdersTable()
            End If

            Return CType(Session(sessionKey), DataTable)
        End Get
    End Property

    Protected Sub RadGrid1_NeedDataSource(ByVal sender As Object, ByVal e As GridNeedDataSourceEventArgs)
        RadGrid1.DataSource = SessionDataSource
    End Sub

    Protected Sub RadGrid1_UpdateCommand(ByVal sender As Object, ByVal e As GridCommandEventArgs)
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        If Not UpdateRow(editedItem) Then
            e.Canceled = True
        End If
    End Sub

    Private Function UpdateRow(ByVal editableItem As GridEditableItem) As Boolean
        Dim changedRows As DataRow() = SessionDataSource.[Select](String.Format("OrderID = {0}", editableItem.GetDataKeyValue("OrderID")))

        If changedRows.Length <> 1 Then
            Me.Label1.Text += "Unable to locate the Order for updating."
            Return False
        End If

        Dim newValues As Hashtable = New Hashtable()
        editableItem.OwnerTableView.ExtractValuesFromItem(newValues, editableItem)
        changedRows(0).BeginEdit()

        Try

            For Each entry As DictionaryEntry In newValues
                changedRows(0)(CStr(entry.Key)) = entry.Value
            Next

            changedRows(0).EndEdit()
        Catch ex As Exception
            changedRows(0).CancelEdit()
            Label1.Text += String.Format("Unable to update Orders. Reason: {0}", ex.Message)
            Return False
        End Try

        Return True
    End Function

    Private Function OrdersTable() As DataTable
        Dim dt As DataTable = New DataTable()
        dt.Columns.Add(New DataColumn("OrderID", GetType(Integer)))
        dt.Columns.Add(New DataColumn("OrderDate", GetType(DateTime)))
        dt.Columns.Add(New DataColumn("Freight", GetType(Decimal)))
        dt.Columns.Add(New DataColumn("ShipName", GetType(String)))
        dt.Columns.Add(New DataColumn("ShipCountry", GetType(String)))
        dt.Columns.Add(New DataColumn("IsChecked", GetType(Boolean)))
        dt.PrimaryKey = New DataColumn() {dt.Columns("OrderID")}

        For i As Integer = 0 To 10 - 1
            Dim index As Integer = i + 1
            Dim row As DataRow = dt.NewRow()
            row("OrderID") = index
            row("OrderDate") = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0).AddHours(index)
            row("Freight") = index * 0.1 + index * 0.01
            row("ShipName") = "Name " & index
            row("ShipCountry") = "Country " & index
            row("IsChecked") = index Mod 3 = 0
            dt.Rows.Add(row)
        Next

        Return dt
    End Function

    Protected Sub RadGrid1_PreRender(ByVal sender As Object, ByVal e As EventArgs)
        For Each item As GridItem In RadGrid1.MasterTableView.Items

            If TypeOf item Is GridEditableItem Then
                Dim editableItem As GridEditableItem = TryCast(item, GridDataItem)
                editableItem.Edit = True
            End If
        Next

        RadGrid1.Rebind()
    End Sub

    Protected Sub btnUpdateAll_Click(ByVal sender As Object, ByVal e As EventArgs)
        For Each item As GridEditableItem In RadGrid1.Items

            If item.IsInEditMode Then
                UpdateRow(item)
            End If
        Next
    End Sub

    Protected Sub btnUpdateSelected_Click(ByVal sender As Object, ByVal e As EventArgs)
        For Each item As GridEditableItem In RadGrid1.Items

            If item.IsInEditMode Then
                Dim rCheckBox As RadCheckBox = TryCast(item("TemplateCheckboxColumn").FindControl("RowCheckBox"), RadCheckBox)

                If rCheckBox.Checked = True Then
                    UpdateRow(item)
                End If
            End If
        Next
    End Sub
End Class
