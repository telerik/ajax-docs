using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using Telerik.Web.UI;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RadGrid1_NeedDataSource(object source, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        if (Session["DataSource"] == null)
        {
            OleDbConnection MyOleDbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("~/App_Data/Nwind.mdb"));
            OleDbDataAdapter MyOleDbDataAdapter = new OleDbDataAdapter();
            MyOleDbDataAdapter.SelectCommand = new OleDbCommand("SELECT TOP 5 CustomerID, ContactName, Address FROM Customers", MyOleDbConnection);
            DataTable myDataTable = new DataTable();
            MyOleDbConnection.Open();
            try
            {
                MyOleDbDataAdapter.Fill(myDataTable);
            }
            finally
            {
                MyOleDbConnection.Close();
            }
            RadGrid1.DataSource = myDataTable.DefaultView;
            Session["DataSource"] = myDataTable;
        }
        else
        {
            RadGrid1.DataSource = Session["DataSource"];
        }

    }
    
    protected void RadGrid1_UpdateCommand(object source, Telerik.Web.UI.GridCommandEventArgs e)
    {
        GridEditableItem editedItem = (e.Item as GridEditableItem);
        GridEditManager editMan = editedItem.EditManager;

        foreach (GridColumn column in RadGrid1.MasterTableView.RenderColumns)
        {
            if (column is IGridEditableColumn)
            {
                IGridEditableColumn editableCol = column as IGridEditableColumn;
                if (editableCol.IsEditable)
                {
                    IGridColumnEditor editor = editMan.GetColumnEditor(editableCol);
                    string editorType = editor.ToString();

                    object editorValue = null;

                    if (editor is GridDropDownColumnEditor)
                    {
                        editorValue = (editor as GridDropDownColumnEditor).SelectedText;
                    }

                    if (editor is GridTemplateColumnEditor)
                    {
                        RadComboBox combo = (RadComboBox)(editedItem.FindControl("RadComboBox1"));
                        editorValue = combo.Text;
                    }
                    try
                    {
                        DataTable sourceTable = Session["DataSource"] as DataTable;                        
                        DataRow[] changedRows = sourceTable.Select("CustomerID = '" + editedItem.OwnerTableView.DataKeyValues[editedItem.ItemIndex]["CustomerID"] + "'");


                        if (column.UniqueName == "ComboColumn")
                        {
                            changedRows[0]["ContactName"] = editorValue;
                        }
                        else if (column.UniqueName == "ComboColumn2")
                        {
                            changedRows[0]["Address"] = editorValue;
                        }
                        else
                        {
                            changedRows[0][column.UniqueName] = editorValue;
                        }

                        sourceTable.AcceptChanges();
                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.StackTrace);
                    }
                }
            }
        }

    }
    protected void RadGrid1_ItemCreated(object sender, GridItemEventArgs e)
    {
        if (e.Item is GridEditableItem && e.Item.IsInEditMode)
        {
            if (e.Item.OwnerTableView.IsItemInserted)
            {
                //item is about to be inserted
            }
            else
            {
                //item is about to be edited
                GridEditableItem item = e.Item as GridEditableItem;
                RadComboBox combo = item["ComboColumn"].Controls[0] as RadComboBox;
                combo.MarkFirstMatch = true;                
                combo.EnableLoadOnDemand = true;
                combo.WebServiceSettings.Method = "GetProducts";
                combo.WebServiceSettings.Path = "Products.asmx";
            }
        }
    }
    protected void RadComboBox1_ItemsRequested(object o, RadComboBoxItemsRequestedEventArgs e)
    {
        RadComboBox combo = o as RadComboBox;

        DataTable dt = (DataTable)Session["DataSource"];
        DataRow[] changedRows = dt.Select("Address like '" + e.Context["text"].ToString().Replace("%20"," ") + "%'");

        foreach (DataRow dr in changedRows)
        {
            combo.Items.Add(new RadComboBoxItem(dr["Address"].ToString() + " _added on demand_"));
        }
    }
}