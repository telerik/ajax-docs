﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.Services.Protocols;
using Telerik.Web.UI;
using System.Web.Script.Serialization;
using System.Data.OleDb;


[ScriptService]
public class Countries : System.Web.Services.WebService
{
	[WebMethod]
	public RadComboBoxItemData[] GetProducts(object context)
	{		
        OleDbConnection MyOleDbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Server.MapPath("~/App_Data/Nwind.mdb"));
        OleDbDataAdapter MyOleDbDataAdapter = new OleDbDataAdapter();
        MyOleDbDataAdapter.SelectCommand = new OleDbCommand("SELECT TOP 5 CustomerID, ContactName, Address FROM Customers", MyOleDbConnection);
        DataTable products = new DataTable();
        MyOleDbConnection.Open();
        try
        {
            MyOleDbDataAdapter.Fill(products);
        }
        finally
        {
            MyOleDbConnection.Close();
        }
		
		List<RadComboBoxItemData> result = new List<RadComboBoxItemData>(products.Rows.Count);
		foreach (DataRow row in products.Rows)
		{
			RadComboBoxItemData itemData = new RadComboBoxItemData();
			itemData.Text = row["ContactName"].ToString();
			itemData.Value = row["CustomerID"].ToString();
			result.Add(itemData);
		}

		return result.ToArray();
	}

	
	
}

