﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Editor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            RadEditor1.ImageManager.ContentProviderTypeName = typeof(DBContentProvider).AssemblyQualifiedName;
		    RadEditor1.ImageManager.ViewPaths = new string[] { "ROOT/Images/Nature/Fruits", "ROOT/Images/Nature/Animals" };
		    RadEditor1.ImageManager.UploadPaths = new string[] { "ROOT/Images/Nature/Fruits", "ROOT/Images/Nature/Animals" };
		    RadEditor1.ImageManager.DeletePaths = new string[] { "ROOT/Images/Nature/Fruits", "ROOT/Images/Nature/Animals" };
        }
    }
}