﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FileExplorer : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		RadFileExplorer1.Configuration.ContentProviderTypeName = typeof(DBContentProvider).AssemblyQualifiedName;
		RadFileExplorer1.Configuration.ViewPaths = new string[] { "ROOT/Images/Nature/Fruits", "ROOT/Images/Nature/Animals" };
		RadFileExplorer1.Configuration.UploadPaths = new string[] { "ROOT/Images/Nature/Fruits", "ROOT/Images/Nature/Animals" };
		RadFileExplorer1.Configuration.DeletePaths = new string[] { "ROOT/Images/Nature/Fruits", "ROOT/Images/Nature/Animals" };
	}
}
