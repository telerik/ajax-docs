﻿using System;
using System.IO;
using System.Text.RegularExpressions;

public partial class MakeSelectorsStronger : System.Web.UI.Page
{
    public static string SkinName = "";

    public static string SelectorStrenghEnhancer(Match match)
    {
        var matchString = match.Value;
        var control = matchString.Substring(0, matchString.Length - ("_"+SkinName).Length);
        var finalString = control + matchString;
       
        return finalString;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SkinName = tbSkinName.Text;

        var inputPath = Server.MapPath("~/Input");
        var outputPath = Server.MapPath("~/Output");

        var files = Directory.GetFiles(inputPath, "*.css");
        MatchEvaluator evaluator = new MatchEvaluator(SelectorStrenghEnhancer);

        foreach (var filePath in files)
        {
            string text = File.ReadAllText(filePath);
            var filename = Path.GetFileName(filePath);
            text = Regex.Replace(text, @"\.Rad.*?_"+ SkinName, evaluator, RegexOptions.IgnorePatternWhitespace);
            File.WriteAllText(Path.Combine(outputPath,filename), text);
        }

        Label1.Text = "Styles selectors increased successfully";
    }
}