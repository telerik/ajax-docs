﻿Imports ICSharpCode.SharpZipLib.Zip
Imports System.IO
Imports Telerik.Web.UI
Imports Telerik.Web.UI.Widgets

Public Class UnzipFileSystemContentProvider
  Inherits FileSystemContentProvider

  Public Sub New(ByVal context As HttpContext, ByVal searchPatterns As String(), ByVal viewPaths As String(), ByVal uploadPaths As String(), ByVal deletePaths As String(), ByVal selectedUrl As String, ByVal selectedItemTag As String)
    MyBase.New(context, searchPatterns, viewPaths, uploadPaths, deletePaths, selectedUrl, selectedItemTag)
    Me.ProcessPaths(MyBase.ViewPaths)
    Me.ProcessPaths(MyBase.UploadPaths)
    Me.ProcessPaths(MyBase.DeletePaths)
    MyBase.SelectedUrl = FileBrowserContentProvider.RemoveProtocolNameAndServerName(Me.GetAbsolutePath(MyBase.SelectedUrl))
  End Sub

  Public Overrides Function StoreFile(ByVal file As UploadedFile, ByVal path As String, ByVal name As String, ByVal ParamArray arguments As String()) As String
    Dim relFolder As String = path
    Dim relFull = IO.Path.Combine(relFolder, name)
    Dim mapFolder As String = MyBase.Context.Server.MapPath(relFolder)
    Dim mapFull As String = MyBase.Context.Server.MapPath(relFull)
    If file.GetExtension = ".zip" Then
      Dim lastValidFile As String = ""
      Using ZIS As New ZipInputStream(file.InputStream)
        Dim ZE As ZipEntry = ZIS.GetNextEntry
        While Not IsNothing(ZE)
          Dim strDir As String = IO.Path.GetDirectoryName(ZE.Name)
          Dim strFil As String = IO.Path.GetFileName(ZE.Name)
          If strDir.Length > 0 Then
            IO.Directory.CreateDirectory(mapFolder & strDir)
          End If
          If strFil <> String.Empty Then
            If IsValidFileTypeAfterUnZip(ZE.Name) Then
              DeleteFileIfAlreadyExists(mapFolder & ZE.Name)
              lastValidFile = relFolder & ZE.Name
              Using FS As FileStream = IO.File.Create(mapFolder & ZE.Name)
                Dim i As Integer = 2048
                Dim b As Byte() = New Byte(2048) {}
                While True
                  i = ZIS.Read(b, 0, b.Length)
                  If i > 0 Then
                    FS.Write(b, 0, i)
                  Else
                    Exit While
                  End If
                End While
              End Using
            End If
          End If
          ZE = ZIS.GetNextEntry
        End While
      End Using
      DeleteEmptyDirectoriesAfterZip(mapFolder)
      Return lastValidFile
    Else
      DeleteFileIfAlreadyExists(mapFull)
      file.SaveAs(mapFull)
      Return relFull
    End If
  End Function

  Private Sub DeleteFileIfAlreadyExists(ByVal mapFull As String)
    If IO.File.Exists(mapFull) Then
      IO.File.Delete(mapFull)
    End If
  End Sub

  Private Sub DeleteEmptyDirectoriesAfterZip(ByVal mapFolder As String)
    For Each Dir As String In IO.Directory.GetDirectories(mapFolder)
      DeleteEmptyDirectoriesAfterZip(Dir)
      If IO.Directory.GetFiles(Dir).Count = 0 And IO.Directory.GetDirectories(Dir).Count = 0 Then
        IO.Directory.Delete(Dir)
      End If
    Next
  End Sub

  Private Function IsValidFileTypeAfterUnZip(ByVal fileName As String) As Boolean
    Dim strExt As String = Right(fileName, fileName.Length - fileName.LastIndexOf(".")).ToLower
    If strExt = ".zip" Then
      Return False
    Else
      For Each s As String In MyBase.SearchPatterns
        s = Right(s, s.Length - s.LastIndexOf(".")).ToLower
        If s = strExt Then Return True
      Next
    End If
    Return False
  End Function

End Class
