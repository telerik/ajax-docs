﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;

public partial class custom_aggregate_example_cs : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{

	}



	protected void RadGrid1_CustomAggregate(object sender, Telerik.Web.UI.GridCustomAggregateEventArgs e)
	{
		//get the column name it will be used for determining what to aggregate and for fetching data
		string colName = e.Column.UniqueName;

		//the group footer calculation is to be performed, we need only the corresponding group items data
		if (e.Item is GridGroupFooterItem)
		{
			string msg = "group footer aggregate: ";

			//get the corresponding group header as it provides child items from which we can obtain data
			GridGroupHeaderItem correspondingHeader = (e.Item as GridGroupFooterItem).GroupHeaderItem;

			//check column name to determine aggregation logic
			if (colName == "moreData")
			{
				decimal counter = 0;
				//get corresponding group items to iterate through and aggregate
				GridItem[] groupChildItems = correspondingHeader.GetChildItems();
				for (int i = 0; i < groupChildItems.Length; i++)
				{
					decimal currValue = (decimal)DataBinder.Eval((groupChildItems[i] as GridDataItem).DataItem, colName);
					counter += currValue; //custom sum aggregate, implement aggregation here
				}
				e.Result = msg + counter;
			}

			if (colName == "someColumn")
			{
				TimeSpan totalTime = new TimeSpan(0);
				GridItem[] groupChildItems = correspondingHeader.GetChildItems();
				for (int i = 0; i < groupChildItems.Length; i++)
				{
					TimeSpan currValue = (TimeSpan)DataBinder.Eval((groupChildItems[i] as GridDataItem).DataItem, colName);
					totalTime = totalTime.Add(currValue);
				}
				e.Result = msg + totalTime;
			}
		}

		//the total grid footer that is not specific to a group, we need to aggregate all data
		if (e.Item is GridFooterItem)
		{
			string msg = "Grid total footer aggregate: ";
			if (colName == "moreData")
			{
				decimal counter = 0;
				//Loop all items in the current grid to aggregate
				foreach (GridDataItem item in RadGrid1.MasterTableView.Items)
				{
					decimal currValue = (decimal)item.GetDataKeyValue(colName);
					counter += currValue;
				}
				e.Result = msg + counter;
			}

			if (colName == "someColumn")
			{
				TimeSpan totalTime = new TimeSpan(0);
				foreach (GridDataItem item in RadGrid1.MasterTableView.Items)
				{
					TimeSpan currValue = (TimeSpan)item.GetDataKeyValue(colName);
					totalTime = totalTime.Add(currValue);
				}
				e.Result = msg + totalTime;
			}
		}
	}

	protected void RadGrid1_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
	{
		(sender as RadGrid).DataSource = GetData();
	}

	protected DataTable GetData()
	{
		DataTable tbl = new DataTable();
		tbl.Columns.Add(new DataColumn("id", typeof(decimal)));
		tbl.Columns.Add(new DataColumn("firstField", typeof(string)));
		tbl.Columns.Add(new DataColumn("moreData", typeof(decimal)));
		tbl.Columns.Add(new DataColumn("someColumn", typeof(TimeSpan)));
		tbl.Rows.Add(new object[] { 1, "one", 2, new TimeSpan(0, 10, 0) });
		tbl.Rows.Add(new object[] { 2, "two", 3, new TimeSpan(0, 20, 0) });
		tbl.Rows.Add(new object[] { 3, "three", 4, new TimeSpan(1, 10, 0) });
		tbl.Rows.Add(new object[] { 4, "four", 4, new TimeSpan(1, 30, 0) });

		return tbl;
	}
}