﻿
Imports System.Data
Imports Telerik.Web.UI

Partial Class custom_aggregate_example_vb
	Inherits System.Web.UI.Page

	Protected Sub RadGrid1_CustomAggregate(ByVal sender As Object, ByVal e As GridCustomAggregateEventArgs) Handles RadGrid1.CustomAggregate

		'get the column name it will be used for determining what to aggregate and for fetching data
		Dim colName As String = e.Column.UniqueName

		'the group footer calculation is to be performed, we need only the corresponding group items data
		If TypeOf e.Item Is GridGroupFooterItem Then
			Dim msg As String = "group footer aggregate: "
			'get the corresponding group header as it provides child items from which we can obtain data
			Dim correspondingHeader As GridGroupHeaderItem = DirectCast(e.Item, GridGroupFooterItem).GroupHeaderItem

			'check column name to determine aggregation logic
			If colName = "moreData" Then
				Dim counter As Decimal = 0
				'get corresponding group items to iterate through and aggregate
				Dim groupChildItems As GridItem() = correspondingHeader.GetChildItems()
				For i = 0 To groupChildItems.Count - 1
					Dim currValue As Decimal = DataBinder.Eval(DirectCast(groupChildItems(i), GridDataItem).DataItem, colName)
					counter += currValue 'custom sum aggregate, implement aggregation here
				Next
				e.Result = msg & counter
			End If

			If colName = "someColumn" Then
				Dim totalTime As TimeSpan = New TimeSpan(0)

				Dim groupChildItems As GridItem() = correspondingHeader.GetChildItems()
				For i = 0 To groupChildItems.Count - 1
					Dim currValue As TimeSpan = DataBinder.Eval(DirectCast(groupChildItems(i), GridDataItem).DataItem, colName)
					totalTime = totalTime.Add(currValue)
				Next
				e.Result = msg & totalTime.ToString()
			End If

			'the total grid footer that is not specific to a group, we need to aggregate all data
		ElseIf TypeOf e.Item Is GridFooterItem Then
			Dim msg As String = "Grid total footer aggregate: "

			If colName = "moreData" Then
				Dim counter As Decimal = 0
				'Loop all items in the current grid to aggregate
				For Each item As GridDataItem In RadGrid1.MasterTableView.Items
					Dim currValue As Decimal = item.GetDataKeyValue(colName)
					counter += currValue
				Next
				e.Result = msg & counter
			End If
			If colName = "someColumn" Then
				Dim totalTime As TimeSpan = New TimeSpan(0)
				For Each item As GridDataItem In RadGrid1.MasterTableView.Items
					Dim currValue2 As TimeSpan = item.GetDataKeyValue(colName)
					totalTime = totalTime.Add(currValue2)
				Next
				e.Result = msg & totalTime.ToString()
			End If

		End If

	End Sub

	Protected Function GetData() As DataTable
		Dim tbl As DataTable = New DataTable()
		tbl.Columns.Add(New DataColumn("id", GetType(Decimal)))
		tbl.Columns.Add(New DataColumn("firstField", GetType(String)))
		tbl.Columns.Add(New DataColumn("moreData", GetType(Decimal)))
		tbl.Columns.Add(New DataColumn("someColumn", GetType(TimeSpan)))
		tbl.Rows.Add(New Object() {1, "one", 2, New TimeSpan(0, 10, 0)})
		tbl.Rows.Add(New Object() {2, "two", 3, New TimeSpan(0, 20, 0)})
		tbl.Rows.Add(New Object() {3, "three", 4, New TimeSpan(1, 10, 0)})
		tbl.Rows.Add(New Object() {4, "four", 4, New TimeSpan(1, 30, 0)})
		Return tbl
	End Function

	Protected Sub RadGrid1_NeedDataSource(ByVal sender As Object, ByVal e As GridNeedDataSourceEventArgs) Handles RadGrid1.NeedDataSource
		TryCast(sender, RadGrid).DataSource = GetData()
	End Sub
End Class
