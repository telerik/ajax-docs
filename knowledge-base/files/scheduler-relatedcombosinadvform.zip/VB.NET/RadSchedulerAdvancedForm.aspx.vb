﻿Imports System
Imports System.Collections.Generic
Imports System.Web.UI
Imports System.Drawing
Imports System.Web.UI.WebControls
Imports Telerik.Web.UI

Partial Class RadSchedulerAdvancedForm
    Inherits System.Web.UI.Page
	

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)

    End Sub

   

    Protected Sub RadScheduler1_AppointmentDataBound(ByVal sender As Object, ByVal e As SchedulerEventArgs)
        Dim colorAttribute As String = e.Appointment.Attributes("AppointmentColor")
        If Not String.IsNullOrEmpty(colorAttribute) Then
            Dim colorValue As Integer
            If Integer.TryParse(colorAttribute, colorValue) Then
                Dim appointmentColor As Color = Color.FromArgb(colorValue)
                e.Appointment.BackColor = appointmentColor
                e.Appointment.BorderColor = Color.Black
                e.Appointment.BorderStyle = BorderStyle.Solid
                e.Appointment.BorderWidth = Unit.Pixel(1)
            End If
        End If
        e.Appointment.ToolTip = e.Appointment.Subject + ": " + e.Appointment.Description
    End Sub
End Class
