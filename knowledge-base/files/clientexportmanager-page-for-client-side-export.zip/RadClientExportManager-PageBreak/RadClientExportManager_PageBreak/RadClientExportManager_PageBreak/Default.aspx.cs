﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;

public partial class Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetTestData();
    }

    protected DataTable GetTestData()
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("id", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("theDates", typeof(DateTime)));
        tbl.Columns.Add(new DataColumn("anotherField", typeof(string)));
        for (int i = 0; i < 20; i++)
        {

            tbl.Rows.Add(new object[] { i, DateTime.Now.AddHours(i), i + " item" });
        }

        return tbl;
    }

    protected void RadAjaxManager1_AjaxRequest(object sender, AjaxRequestEventArgs e)
    {
        if (e.Argument == "disablePaging")
        {
            RadGrid1.AllowPaging = false;
            RadGrid1.Rebind();
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "someKey", "Sys.Application.add_load(performExport);", true); // register a startup script that will be executed once the page finished loading
        }
        if (e.Argument == "enablePaging")
        {
            RadGrid1.AllowPaging = true;
            RadGrid1.Rebind();
        }
    }
}
