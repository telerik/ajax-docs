﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Web.Http;
/// <summary>
/// Summary description for ExportController
/// </summary>
public class ExportController : ApiController
{
    [HttpPost]
    public HttpResponseMessage File(FormDataCollection values)
    {
        var contentType = values.Get("contentType");
        var base64 = values.Get("base64");
        var fileName = values.Get("fileName");

        var fileContents = Convert.FromBase64String(base64);

        var response = new HttpResponseMessage();

        response.Content = new ByteArrayContent(fileContents);
        response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
        response.Content.Headers.ContentDisposition.FileName = fileName;
        response.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
        response.Content.Headers.ContentLength = fileContents.Length;

        return response;
    }

    [HttpPost]
    public HttpResponseMessage SaveFile(FormDataCollection values)
    {
        var contentType = values.Get("contentType");
        var base64 = values.Get("base64");
        var fileName = values.Get("fileName");

        var path = System.Web.Hosting.HostingEnvironment.MapPath("~/files") + "\\" + Guid.NewGuid() + "_" + fileName;

        System.IO.File.WriteAllBytes(path, Convert.FromBase64String(base64));

        var response = new HttpResponseMessage();

        return response;
    }
}