﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class ExportOrgChart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var relativePath = "~/api/export/file";

        CEM1.PdfSettings.ProxyURL = ResolveUrl(relativePath);

        if (!Page.IsPostBack)
        {
            CreateEmployees();
        }
    }

    private void CreateEmployees()
    {
        DataTable employees = new DataTable();
        employees.Columns.Add("EmployeeID");
        employees.Columns.Add("ReportsTo");
        employees.Columns.Add("FullName");
        employees.Columns.Add("Position");

        employees.Rows.Add(new string[] { "1", null, "Robert C. King", "Director of Marketing" });
        employees.Rows.Add(new string[] { "2", "1", "Laura Callahan", "Brand Manager" });
        employees.Rows.Add(new string[] { "3", "2", "Anne Dodsworth", "Marketing Executive" });
        employees.Rows.Add(new string[] { "4", "1", "Kevin Buchanan", "Senior Graphic Designer" });
        employees.Rows.Add(new string[] { "5", "4", "Kate Buchanan", "Junior Graphic Designer" });
        RadOrgChart1.DataSource = employees;
        RadOrgChart1.DataBind();
    }
}