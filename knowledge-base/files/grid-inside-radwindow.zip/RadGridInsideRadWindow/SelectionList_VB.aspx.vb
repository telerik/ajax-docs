﻿Imports Telerik.Web.UI

Partial Class SelectionList_VB
	Inherits System.Web.UI.Page


	Protected returnedValues As New List(Of String)()

	Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
		Dim checkBox As CheckBox = CType(sender, CheckBox)
		If Session("returnedValues") IsNot Nothing Then
			returnedValues = DirectCast(Session("returnedValues"), List(Of String))
		End If
		Dim dataItem As GridDataItem = DirectCast((TryCast(sender, CheckBox)).NamingContainer, GridDataItem)
		Dim selectedCustomer As String = "<b>Selected customer data:</b> " & dataItem("CustomerID").Text & " : " & dataItem("ContactName").Text & " : " & dataItem("ContactTitle").Text & "<br/>"
		If checkBox.Checked Then
			returnedValues.Add(selectedCustomer)
		Else
			returnedValues.Remove(selectedCustomer)
		End If
		Session("returnedValues") = returnedValues
	End Sub

End Class
