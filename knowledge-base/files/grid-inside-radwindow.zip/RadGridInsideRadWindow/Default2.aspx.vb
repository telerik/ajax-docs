﻿
Partial Class Default2
	Inherits System.Web.UI.Page


	Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
		If Session("returnedValues") IsNot Nothing Then
			Dim results As List(Of String) = DirectCast(Session("returnedValues"), List(Of String))
			While results.Count > 0
				Label1.Text += results(results.Count - 1)
				results.RemoveAt(results.Count - 1)
			End While
		End If
	End Sub

End Class
