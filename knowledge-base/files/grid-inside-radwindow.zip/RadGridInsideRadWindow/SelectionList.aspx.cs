﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Telerik.Web.UI;

public partial class SelectionList : System.Web.UI.Page
{
    protected List<string> returnedValues = new List<string>();    

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox checkBox = sender as CheckBox;

        if (Session["returnedValues"] != null)
        {
            returnedValues = (List<string>)Session["returnedValues"];
        }
        GridDataItem dataItem = (GridDataItem)(sender as CheckBox).NamingContainer;
        string selectedCustomer = "<b>Selected customer data:</b> " + dataItem["CustomerID"].Text +
            " : " + dataItem["ContactName"].Text + " : " + dataItem["ContactTitle"].Text + "<br/>";
        if (checkBox.Checked)
        {
            returnedValues.Add(selectedCustomer);            
        }
        else
        {
            returnedValues.Remove(selectedCustomer);
        }
        Session["returnedValues"] = returnedValues;
    }
}