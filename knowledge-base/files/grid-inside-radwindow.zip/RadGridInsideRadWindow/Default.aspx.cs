﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["returnedValues"] != null)
        {
            List<string> results = (List<string>)Session["returnedValues"];
            while (results.Count > 0)
            {
                Label1.Text += results[results.Count-1];
                results.RemoveAt(results.Count - 1); 
            }
        }
    }
}