﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProdcutsApp.Models
{
    public class ProductRepository : IProductRepository
    {
        private List<Product> products;
        private int currentID = 12;

        public ProductRepository()
        {
            products = new List<Product>(new Product[] 
            { 
                new Product { ID = 1, Name = "Product1", Category = "Category1", Price = 1.05M }, 
                new Product { ID = 2, Name = "Product2", Category = "Category2", Price = 3.75M }, 
                new Product { ID = 3, Name = "Product3", Category = "Category2", Price = 2.34M }, 
                new Product { ID = 4, Name = "Product4", Category = "Category3", Price = 1.63M }, 
                new Product { ID = 5, Name = "Product5", Category = "Category4", Price = 5.62M }, 
                new Product { ID = 6, Name = "Product6", Category = "Category1", Price = 7.68M }, 
                new Product { ID = 7, Name = "Product7", Category = "Category1", Price = 8.23M }, 
                new Product { ID = 8, Name = "Product8", Category = "Category2", Price = 9.44M }, 
                new Product { ID = 9, Name = "Product9", Category = "Category2", Price = 0.43M }, 
                new Product { ID = 10, Name = "Product10", Category = "Category3", Price = 2.12M }, 
                new Product { ID = 11, Name = "Product11", Category = "Category4", Price = 1.79M }, 
                new Product { ID = 12, Name = "Product12", Category = "Category4", Price = 4.22M } 
            });
        }

        public IEnumerable<Product> GetAll()
        {
            return products;
        }

        public Product Get(int id)
        {
            return products.FirstOrDefault(p => p.ID == id);
        }

        public Product Add(Product item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.ID = ++currentID;
            products.Add(item);
            return item;
        }

        public void Remove(int id)
        {
            products.RemoveAll(p => p.ID == id);
        }

        public bool Update(Product item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            int index = products.FindIndex(p => p.ID == item.ID);
            if (index == -1)
            {
                return false;
            }
            products.RemoveAt(index);
            products.Add(item);
            return true;
        }
    }
}