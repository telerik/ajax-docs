﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class save_batch_grids_and_page : System.Web.UI.Page
{
    protected void RadGrid1_BatchEditCommand(object sender, Telerik.Web.UI.GridBatchEditingEventArgs e)
    {
        Response.Write("first grid updated<br />");
        //implement saving of the grid changes
        ExecuteCommonLogic();
    }

    protected void RadGrid2_BatchEditCommand(object sender, Telerik.Web.UI.GridBatchEditingEventArgs e)
    {
        Response.Write("secind grid updated<br />");
        //implement saving of the grid changes
        ExecuteCommonLogic();
    }

    protected void RadButton1_Click(object sender, EventArgs e)
    {
        ExecuteCommonLogic();
    }

    //a flag to ensure we go through the common logic only once because each batch edit command event will call it
    private bool isCommonLogicExecuted = false;

    private void ExecuteCommonLogic()
    {
        if (isCommonLogicExecuted) { return; }
        isCommonLogicExecuted = true;
        Response.Write("common logic executed<br />");
        //implement validation, gathering of regular user input and so on
    }


    protected void setGridData(object sender)
    {
        (sender as Telerik.Web.UI.RadGrid).DataSource = "abcdef";//a bad data source but it will suffice for the demo
    }
    protected void RadGrid1_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        setGridData(sender);
    }
    protected void RadGrid2_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        setGridData(sender);
    }

}