﻿
Partial Class Controls_AlertTemplate
    Inherits System.Web.UI.UserControl

End Class
