﻿
Partial Class Controls_ConfirmTemplate
    Inherits System.Web.UI.UserControl

End Class
