﻿
Partial Class ChangeTemplates_Vb
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        RadFileExplorer1.WindowManager.AlertTemplate = New AlertTemplate(Me.Page)
        RadFileExplorer1.WindowManager.ConfirmTemplate = New ConfirmTemplate(Me.Page)
        RadFileExplorer1.WindowManager.PromptTemplate = New PromptTemplate(Me.Page)
    End Sub
End Class
