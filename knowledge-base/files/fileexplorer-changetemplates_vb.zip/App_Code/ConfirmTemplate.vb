﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Web.UI
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls


Public Class ConfirmTemplate
    Implements ITemplate
    Private _page As Page

    Public Sub New(ByVal page As Page)
        Me._page = page
    End Sub

    Private Sub ITemplate_InstantiateIn(ByVal owner As Control) Implements ITemplate.InstantiateIn
        Dim ctrl As Control = _page.LoadControl("~/Controls/ConfirmTemplate.ascx")
        owner.Controls.Add(ctrl)
    End Sub
End Class
