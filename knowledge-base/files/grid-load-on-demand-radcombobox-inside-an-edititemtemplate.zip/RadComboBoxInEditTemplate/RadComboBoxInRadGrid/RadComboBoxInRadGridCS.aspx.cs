﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class RadComboBoxInRadGridCS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RadGrid1_UpdateCommand(object source, Telerik.Web.UI.GridCommandEventArgs e)
    {

        GridEditableItem editedItem = e.Item as GridEditableItem;
        RadComboBox comboBox = (RadComboBox)editedItem.FindControl("RadComboBox1");
        SqlDataSource1.UpdateParameters.Add(new Parameter("CategoryID", DbType.Int32, comboBox.SelectedValue));
        SqlDataSource1.UpdateParameters.Add(new Parameter("UnitPrice", DbType.Double, (e.Item.FindControl("UnitPriceTextBox") as TextBox).Text));
        SqlDataSource1.UpdateParameters.Add(new Parameter("ProductName", DbType.String, (e.Item.FindControl("ProductNameBox") as TextBox).Text));
        SqlDataSource1.UpdateParameters.Add(new Parameter("ProductID", DbType.Int32, (e.Item.FindControl("ProductIDBox") as TextBox).Text));
        SqlDataSource1.Update();

    }
    protected void RadGrid1_InsertCommand(object sender, GridCommandEventArgs e)
    {
        GridEditableItem editedItem = e.Item as GridEditableItem;
        RadComboBox comboBox = (RadComboBox)editedItem.FindControl("RadComboBox1");
        SqlDataSource1.InsertParameters.Add(new Parameter("CategoryID", DbType.Int32, comboBox.SelectedValue));
        SqlDataSource1.InsertParameters.Add(new Parameter("UnitPrice", DbType.Double, (e.Item.FindControl("UnitPriceTextBox") as TextBox).Text));
        SqlDataSource1.InsertParameters.Add(new Parameter("ProductName", DbType.String, (e.Item.FindControl("ProductNameBox") as TextBox).Text));
        SqlDataSource1.Insert();

    }

    protected void RadGrid1_DeleteCommand(object source, GridCommandEventArgs e)
    {
        GridDataItem item = (GridDataItem)e.Item;
        string ProductID = item.OwnerTableView.DataKeyValues[item.ItemIndex]["ProductID"].ToString();
        SqlDataSource1.DeleteParameters.Add(new Parameter("ProductID", DbType.Int32, ProductID));
        SqlDataSource1.Delete();

    }

    protected void RadComboBox1_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
    {
       
        string sql = "SELECT [CategoryID], [CategoryName], [Description] FROM [Categories]";
        SqlDataAdapter adapter = new SqlDataAdapter(sql,
            ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString);

        DataTable dt = new DataTable();
        adapter.Fill(dt);

        RadComboBox comboBox = (RadComboBox)sender;
        comboBox.Items.Clear();
        foreach (DataRow row in dt.Rows)
        {
            RadComboBoxItem item = new RadComboBoxItem();
            item.Text = row["CategoryName"].ToString();
            item.Value = row["CategoryID"].ToString();
            comboBox.Items.Add(item);
        }
    }
    protected void OnItemDataBoundHandler(object sender, GridItemEventArgs e)
    {
        if (e.Item.IsInEditMode)
        {
            GridEditableItem item = (GridEditableItem)e.Item;
            if (!(e.Item is IGridInsertItem))
            {
                RadComboBox combo = (RadComboBox)item.FindControl("RadComboBox1");
                RadComboBoxItem preselectedItem = new RadComboBoxItem();
                preselectedItem.Text = item["CategoryName"].Text;
                preselectedItem.Value = item["CategoryID"].Text;
                combo.Items.Insert(0, preselectedItem);
                combo.SelectedIndex = 0;

            }
        }
    }

}