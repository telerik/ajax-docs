﻿Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports Telerik.Web.UI


Partial Class RadComboBoxInRadGridAutomaticLODVB
    Inherits System.Web.UI.Page

    Protected Sub RadGrid1_UpdateCommand(ByVal source As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs)

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)
        Dim comboBox As RadComboBox = DirectCast(editedItem.FindControl("RadComboBox1"), RadComboBox)
        SqlDataSource1.UpdateParameters.Add(New Parameter("CategoryID", DbType.Int32, comboBox.SelectedValue))
        SqlDataSource1.UpdateParameters.Add(New Parameter("UnitPrice", DbType.[Double], TryCast(e.Item.FindControl("UnitPriceTextBox"), TextBox).Text))
        SqlDataSource1.UpdateParameters.Add(New Parameter("ProductName", DbType.[String], TryCast(e.Item.FindControl("ProductNameBox"), TextBox).Text))
        SqlDataSource1.UpdateParameters.Add(New Parameter("ProductID", DbType.Int32, TryCast(e.Item.FindControl("ProductIDBox"), TextBox).Text))
        SqlDataSource1.Update()

    End Sub
    Protected Sub RadGrid1_InsertCommand(ByVal sender As Object, ByVal e As GridCommandEventArgs)
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)
        Dim comboBox As RadComboBox = DirectCast(editedItem.FindControl("RadComboBox1"), RadComboBox)
        SqlDataSource1.InsertParameters.Add(New Parameter("CategoryID", DbType.Int32, comboBox.SelectedValue))
        SqlDataSource1.InsertParameters.Add(New Parameter("UnitPrice", DbType.[Double], TryCast(e.Item.FindControl("UnitPriceTextBox"), TextBox).Text))
        SqlDataSource1.InsertParameters.Add(New Parameter("ProductName", DbType.[String], TryCast(e.Item.FindControl("ProductNameBox"), TextBox).Text))
        SqlDataSource1.Insert()

    End Sub

    Protected Sub RadGrid1_DeleteCommand(ByVal source As Object, ByVal e As GridCommandEventArgs)
        Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
        Dim ProductID As String = item.OwnerTableView.DataKeyValues(item.ItemIndex)("ProductID").ToString()
        SqlDataSource1.DeleteParameters.Add(New Parameter("ProductID", DbType.Int32, ProductID))
        SqlDataSource1.Delete()

    End Sub

    Protected Sub OnItemDataBoundHandler(ByVal sender As Object, ByVal e As GridItemEventArgs)

        If e.Item.IsInEditMode Then
            Dim item As GridEditableItem = DirectCast(e.Item, GridEditableItem)
            If Not (TypeOf e.Item Is IGridInsertItem) Then
                Dim combo As RadComboBox = DirectCast(item.FindControl("RadComboBox1"), RadComboBox)
                Dim preselectedItem As New RadComboBoxItem()
                preselectedItem.Text = item("CategoryName").Text
                preselectedItem.Value = item("CategoryID").Text
                combo.Items.Insert(0, preselectedItem)
                combo.SelectedIndex = 0
            Else
                Dim textBoxID As TextBox = DirectCast(item.FindControl("ProductIDBox"), TextBox)

                textBoxID.Visible = False
            End If
        End If
    End Sub

End Class
