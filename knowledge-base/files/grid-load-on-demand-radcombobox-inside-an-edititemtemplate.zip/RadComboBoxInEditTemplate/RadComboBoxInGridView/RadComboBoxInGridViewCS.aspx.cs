﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Telerik.Web.UI;

public partial class RadComboBoxInGridViewCS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState & DataControlRowState.Edit) == DataControlRowState.Edit)
        {
            RadComboBox RadComboBox1 = (RadComboBox)e.Row.FindControl("RadComboBox1");
            GridViewRow formViewContainer = (GridViewRow)RadComboBox1.NamingContainer;
            DataRowView dataItem = (DataRowView)formViewContainer.DataItem;

            RadComboBoxItem preselectedItem = new RadComboBoxItem();
            preselectedItem.Text = dataItem["CategoryName"].ToString();
            preselectedItem.Value = dataItem["CategoryID"].ToString();
            RadComboBox1.Items.Insert(0, preselectedItem);
            RadComboBox1.SelectedIndex = 0;

        }
    }


    protected void RadComboBox1_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
    {

        string sql = "SELECT [CategoryID], [CategoryName], [Description] FROM [Categories]";
        SqlDataAdapter adapter = new SqlDataAdapter(sql,
            ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString);

        DataTable dt = new DataTable();
        adapter.Fill(dt);

        RadComboBox comboBox = (RadComboBox)sender;
        comboBox.Items.Clear();
        foreach (DataRow row in dt.Rows)
        {
            RadComboBoxItem item = new RadComboBoxItem();
            item.Text = row["CategoryName"].ToString();
            item.Value = row["CategoryID"].ToString();
            comboBox.Items.Add(item);
        }
    }

    protected void SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
    {
        if (this.Session["CategoryID"] != null)
        {
            this.Session["CategoryID"] = e.Value;
        }
        else
        {
            this.Session.Add("CategoryID", e.Value);
        }
    }
}