﻿Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Data
Imports Telerik.Web.UI


Partial Class RadComboBoxInGridViewVB
    Inherits System.Web.UI.Page

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow AndAlso (e.Row.RowState And DataControlRowState.Edit) = DataControlRowState.Edit Then
            Dim RadComboBox1 As RadComboBox = DirectCast(e.Row.FindControl("RadComboBox1"), RadComboBox)
            Dim formViewContainer As GridViewRow = DirectCast(RadComboBox1.NamingContainer, GridViewRow)
            Dim dataItem As DataRowView = DirectCast(formViewContainer.DataItem, DataRowView)

            Dim preselectedItem As New RadComboBoxItem()
            preselectedItem.Text = dataItem("CategoryName").ToString()
            preselectedItem.Value = dataItem("CategoryID").ToString()
            RadComboBox1.Items.Insert(0, preselectedItem)

            RadComboBox1.SelectedIndex = 0
        End If
    End Sub


    Protected Sub RadComboBox1_ItemsRequested(ByVal sender As Object, ByVal e As RadComboBoxItemsRequestedEventArgs)

        Dim sql As String = "SELECT [CategoryID], [CategoryName], [Description] FROM [Categories]"
        Dim adapter As New SqlDataAdapter(sql, ConfigurationManager.ConnectionStrings("Northwind").ConnectionString)

        Dim dt As New DataTable()
        adapter.Fill(dt)

        Dim comboBox As RadComboBox = DirectCast(sender, RadComboBox)
        comboBox.Items.Clear()
        For Each row As DataRow In dt.Rows
            Dim item As New RadComboBoxItem()
            item.Text = row("CategoryName").ToString()
            item.Value = row("CategoryID").ToString()
            comboBox.Items.Add(item)
        Next
    End Sub

    Protected Sub SelectedIndexChanged(ByVal sender As Object, ByVal e As RadComboBoxSelectedIndexChangedEventArgs)
        If Me.Session("CategoryID") IsNot Nothing Then
            Me.Session("CategoryID") = e.Value
        Else
            Me.Session.Add("CategoryID", e.Value)
        End If
    End Sub


End Class
