﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

using xls = Telerik.Web.UI.ExportInfrastructure;

public partial class export_formula_error_Default3 : System.Web.UI.Page
{
    protected void RadGrid1_InfrastructureExporting(object sender, GridInfrastructureExportingEventArgs e)
    {
        xls.Table table = e.ExportStructure.Tables[0];

        //loop through all cells and review their string values, to see if they contain a problematic character
        //and if so- escape or modify it in some manner - this adds brackets around it
        foreach (xls.Cell cell in e.ExportStructure.Tables[0].Cells)
        {
            string cellValue = cell.Value.ToString();
            cell.Value = Regex.Replace(cellValue, "^(-|=|\\+)(?=.)", "[$1]");
        }
    }
    protected void ExportButton_Click(object sender, EventArgs e)
    {
        foreach (GridColumn col in RadGrid1.Columns)
        {
            col.HeaderStyle.Width = Unit.Pixel(300);
        }
        RadGrid1.MasterTableView.ExportToExcel();
    }

    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetDummyData();
    }

    protected DataTable GetDummyData()
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("id", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("SomeProblematicCharacters", typeof(string)));
        tbl.Rows.Add(new object[] { 1, "-one" });
        tbl.Rows.Add(new object[] { 2, "=two" });
        tbl.Rows.Add(new object[] { 3, "+three" });
        tbl.Rows.Add(new object[] { -98, "=(four" });

        return tbl;
    }
}