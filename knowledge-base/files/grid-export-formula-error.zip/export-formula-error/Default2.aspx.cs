﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

using xls = Telerik.Web.UI.ExportInfrastructure;

public partial class export_formula_error_Default2 : System.Web.UI.Page
{
    protected void RadGrid1_InfrastructureExporting(object sender, GridInfrastructureExportingEventArgs e)
    {
        xls.Table table = e.ExportStructure.Tables[0];

        //set the string format for all cells in the sheet if you only have string data or you don't know where issues may come up
        for (int col = 0; col < (sender as RadGrid).MasterTableView.RenderColumns.Length; col++)
        {
            for (int row = 1; row <= table.Rows.Count; row++)
            {
                table.Cells[col, row].Format = "@";
            }
        }
    }
    protected void ExportButton_Click(object sender, EventArgs e)
    {
        foreach (GridColumn col in RadGrid1.Columns)
        {
            col.HeaderStyle.Width = Unit.Pixel(300);
        }
        RadGrid1.MasterTableView.ExportToExcel();
    }

    protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetDummyData();
    }

    protected DataTable GetDummyData()
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("id", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("SomeProblematicCharacters", typeof(string)));
        tbl.Rows.Add(new object[] { 1, "-one" });
        tbl.Rows.Add(new object[] { 2, "=two" });
        tbl.Rows.Add(new object[] { 3, "+three" });
        tbl.Rows.Add(new object[] { -98, "=(four" });

        return tbl;
    }
}