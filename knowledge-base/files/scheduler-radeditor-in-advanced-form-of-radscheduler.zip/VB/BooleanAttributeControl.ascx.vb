﻿Imports System
Imports System.Web.UI
Imports System.ComponentModel

Partial Class VB_BooleanAttributeControl
    Inherits System.Web.UI.UserControl
    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
        Public Property Value() As String
        Get
            Return AttributeValue.Checked.ToString()
        End Get

        Set(ByVal value As String)
            If String.IsNullOrEmpty(value) Then
                AttributeValue.Checked = False
            Else
                AttributeValue.Checked = Convert.ToBoolean(value)
            End If
        End Set
    End Property

    <Bindable(BindableSupport.Yes, BindingDirection.OneWay)> _
    Public Property Label() As String
        Get
            Return AttributeValue.Text
        End Get

        Set(ByVal value As String)
            AttributeValue.Text = value
        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)

    End Sub
End Class
