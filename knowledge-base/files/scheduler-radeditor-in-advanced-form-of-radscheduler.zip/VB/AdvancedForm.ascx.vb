﻿Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Drawing
Imports Telerik.Web.UI

''' <summary>
''' Specifies the advanced form mode.
''' </summary>
Public Enum AdvancedFormMode
    Insert
    Edit
End Enum
Partial Class VB_AdvancedForm
    Inherits System.Web.UI.UserControl

#Region "Private members"

    Private Shared ReadOnly DayOrdinalValues As String() = {"1", "2", "3", "4", "-1"}

    Private Shared ReadOnly DayMaskValues As String() = { _
      CInt(RecurrenceDay.EveryDay).ToString(), _
      CInt(RecurrenceDay.WeekDays).ToString(), _
      CInt(RecurrenceDay.WeekendDays).ToString(), _
      CInt(RecurrenceDay.Sunday).ToString(), _
      CInt(RecurrenceDay.Monday).ToString(), _
      CInt(RecurrenceDay.Tuesday).ToString(), _
      CInt(RecurrenceDay.Wednesday).ToString(), _
      CInt(RecurrenceDay.Thursday).ToString(), _
      CInt(RecurrenceDay.Friday).ToString(), _
      CInt(RecurrenceDay.Saturday).ToString()}

    Private DayOrdinalDescriptions As String()

    Private DayMaskDescriptions As String()

    Private ReadOnly InvariantMonthNames As String()

    Private Property FormInitialized() As Boolean
        Get
            Dim storedValue As Object = ViewState("FormInitialized")
            If storedValue IsNot Nothing Then
                Return CBool(storedValue)
            End If

            Return False
        End Get

        Set(ByVal value As Boolean)
            ViewState("FormInitialized") = value
        End Set
    End Property

    Private _mode As AdvancedFormMode = AdvancedFormMode.Insert

#End Region

#Region "Protected properties"

    Protected ReadOnly Property Owner() As RadScheduler
        Get
            Return Appointment.Owner
        End Get
    End Property

    Protected ReadOnly Property Appointment() As Appointment
        Get
            Dim container As SchedulerFormContainer = DirectCast(BindingContainer, SchedulerFormContainer)
            Return container.Appointment
        End Get
    End Property

    Protected ReadOnly Property Frequency() As RecurrenceFrequency
        Get
            If RecurrentAppointment IsNot Nothing AndAlso RecurrentAppointment.Checked Then
                If RepeatFrequencyHourly IsNot Nothing AndAlso RepeatFrequencyHourly.Checked Then
                    Return RecurrenceFrequency.Hourly
                End If

                If RepeatFrequencyDaily IsNot Nothing AndAlso RepeatFrequencyDaily.Checked Then
                    Return RecurrenceFrequency.Daily
                End If

                If RepeatFrequencyWeekly IsNot Nothing AndAlso RepeatFrequencyWeekly.Checked Then
                    Return RecurrenceFrequency.Weekly
                End If

                If RepeatFrequencyMonthly IsNot Nothing AndAlso RepeatFrequencyMonthly.Checked Then
                    Return RecurrenceFrequency.Monthly
                End If

                If RepeatFrequencyYearly IsNot Nothing AndAlso RepeatFrequencyYearly.Checked Then
                    Return RecurrenceFrequency.Yearly
                End If
            End If

            Return RecurrenceFrequency.None
        End Get
    End Property

    Protected ReadOnly Property Interval() As Integer
        Get
            Select Case Frequency
                Case RecurrenceFrequency.Hourly
                    Return Integer.Parse(HourlyRepeatInterval.Text)

                Case RecurrenceFrequency.Daily
                    If RepeatEveryNthDay.Checked Then
                        Return Integer.Parse(DailyRepeatInterval.Text)
                    End If
                    Exit Select

                Case RecurrenceFrequency.Weekly
                    Return Integer.Parse(WeeklyRepeatInterval.Text)

                Case RecurrenceFrequency.Monthly
                    If RepeatEveryNthMonthOnDate.Checked Then
                        Return Integer.Parse(MonthlyRepeatIntervalForDate.Text)
                    End If

                    Return Integer.Parse(MonthlyRepeatIntervalForGivenDay.Text)
            End Select

            Return 0
        End Get
    End Property

    Protected ReadOnly Property DaysOfWeekMask() As RecurrenceDay
        Get
            Select Case Frequency
                Case RecurrenceFrequency.Daily
                    Return IIf((RepeatEveryWeekday.Checked), RecurrenceDay.WeekDays, RecurrenceDay.EveryDay)

                Case RecurrenceFrequency.Weekly
                    Dim finalMask As RecurrenceDay = RecurrenceDay.None
                    finalMask = finalMask Or IIf(WeeklyWeekDayMonday.Checked, RecurrenceDay.Monday, finalMask)
                    finalMask = finalMask Or IIf(WeeklyWeekDayTuesday.Checked, RecurrenceDay.Tuesday, finalMask)
                    finalMask = finalMask Or IIf(WeeklyWeekDayWednesday.Checked, RecurrenceDay.Wednesday, finalMask)
                    finalMask = finalMask Or IIf(WeeklyWeekDayThursday.Checked, RecurrenceDay.Thursday, finalMask)
                    finalMask = finalMask Or IIf(WeeklyWeekDayFriday.Checked, RecurrenceDay.Friday, finalMask)
                    finalMask = finalMask Or IIf(WeeklyWeekDaySaturday.Checked, RecurrenceDay.Saturday, finalMask)
                    finalMask = finalMask Or IIf(WeeklyWeekDaySunday.Checked, RecurrenceDay.Sunday, finalMask)

                    Return finalMask


                Case RecurrenceFrequency.Monthly
                    If RepeatEveryNthMonthOnGivenDay.Checked Then
                        Return DirectCast([Enum].Parse(GetType(RecurrenceDay), MonthlyDayMaskDropDown.SelectedValue), RecurrenceDay)
                    End If
                    Exit Select

                Case RecurrenceFrequency.Yearly
                    If RepeatEveryYearOnGivenDay.Checked Then
                        Return DirectCast([Enum].Parse(GetType(RecurrenceDay), YearlyDayMaskDropDown.SelectedValue), RecurrenceDay)
                    End If
                    Exit Select
            End Select

            Return RecurrenceDay.None
        End Get
    End Property

    Protected ReadOnly Property DayOfMonth() As Integer
        Get
            Select Case Frequency
                Case RecurrenceFrequency.Monthly
                    Return (IIf(RepeatEveryNthMonthOnDate.Checked, Integer.Parse(MonthlyRepeatDate.Text), 0))
                Case RecurrenceFrequency.Yearly

                    Return (IIf(RepeatEveryYearOnDate.Checked, Integer.Parse(YearlyRepeatDate.Text), 0))
            End Select
        End Get
    End Property

    Protected ReadOnly Property DayOrdinal() As Integer
        Get
            Select Case Frequency
                Case RecurrenceFrequency.Monthly
                    If RepeatEveryNthMonthOnGivenDay.Checked Then
                        Return Integer.Parse(MonthlyDayOrdinalDropDown.SelectedValue)
                    End If
                    Exit Select

                Case RecurrenceFrequency.Yearly
                    If RepeatEveryYearOnGivenDay.Checked Then
                        Return Integer.Parse(YearlyDayOrdinalDropDown.SelectedValue)
                    End If
                    Exit Select
            End Select

            Return 0
        End Get
    End Property

    Protected ReadOnly Property Month() As RecurrenceMonth
        Get
            If Frequency = RecurrenceFrequency.Yearly Then
                Dim selectedMonth As String

                If RepeatEveryYearOnDate.Checked Then
                    selectedMonth = YearlyRepeatMonthForDate.SelectedValue
                Else
                    selectedMonth = YearlyRepeatMonthForGivenDay.SelectedValue
                End If

                Return DirectCast([Enum].Parse(GetType(RecurrenceMonth), selectedMonth), RecurrenceMonth)
            End If

            Return RecurrenceMonth.None
        End Get
    End Property

    Private ReadOnly Property Pattern() As RecurrencePattern
        Get
            If Not RecurrentAppointment.Checked Then
                Return Nothing
            End If

            Dim submittedPattern As New RecurrencePattern()
            submittedPattern.Frequency = Frequency
            submittedPattern.Interval = Interval
            submittedPattern.DaysOfWeekMask = DaysOfWeekMask
            submittedPattern.DayOfMonth = DayOfMonth
            submittedPattern.DayOrdinal = DayOrdinal
            submittedPattern.Month = Month

            If submittedPattern.Frequency = RecurrenceFrequency.Weekly Then
                submittedPattern.FirstDayOfWeek = Owner.FirstDayOfWeek
            End If

            Return submittedPattern
        End Get
    End Property

    Private ReadOnly Property Range() As RecurrenceRange
        Get
            Dim dateSpecified As Boolean = StartDate.SelectedDate.HasValue AndAlso EndDate.SelectedDate.HasValue
            Dim timeSpecified As Boolean = StartTime.SelectedDate.HasValue AndAlso EndTime.SelectedDate.HasValue

            If (AllDayEvent.Checked AndAlso Not dateSpecified) OrElse (Not AllDayEvent.Checked AndAlso Not (dateSpecified AndAlso timeSpecified)) Then
                Return New RecurrenceRange()
            End If

            Dim startDate__1 As DateTime = StartDate.SelectedDate.Value.[Date]
            Dim endDate__2 As DateTime = EndDate.SelectedDate.Value.[Date]

            If AllDayEvent.Checked Then
                startDate__1 = startDate__1.[Date]
                endDate__2 = endDate__2.[Date].AddDays(1)
            Else
                Dim startTime__3 As TimeSpan = StartTime.SelectedDate.Value.TimeOfDay
                startDate__1 = startDate__1.Add(startTime__3)

                Dim endTime__4 As TimeSpan = EndTime.SelectedDate.Value.TimeOfDay
                endDate__2 = endDate__2.Add(endTime__4)
            End If

            startDate__1 = Owner.DisplayToUtc(startDate__1)
            endDate__2 = Owner.DisplayToUtc(endDate__2)

            Dim rangeResult As New RecurrenceRange()
            rangeResult.Start = startDate__1
            rangeResult.EventDuration = endDate__2 - startDate__1
            rangeResult.MaxOccurrences = 0
            rangeResult.RecursUntil = DateTime.MaxValue

            If Owner.RecurrenceSupport Then
                If RepeatGivenOccurrences.Checked Then
                    Dim maxOccurrences As Integer
                    Integer.TryParse(RangeOccurrences.Text, maxOccurrences)
                    rangeResult.MaxOccurrences = maxOccurrences
                End If

                If RepeatUntilGivenDate.Checked AndAlso RangeEndDate.SelectedDate.HasValue Then
                    rangeResult.RecursUntil = Owner.DisplayToUtc(RangeEndDate.SelectedDate.Value)

                    If Not AllDayEvent.Checked Then
                        rangeResult.RecursUntil = rangeResult.RecursUntil.AddDays(1)
                    End If
                End If
            End If

            Return rangeResult
        End Get
    End Property

#End Region

#Region "Attributes and resources"

    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
Public Property Description() As String
        Get
            Return DescriptionText.Content
        End Get

        Set(ByVal value As String)
            DescriptionText.Content = value
        End Set
    End Property
    <Bindable(BindableSupport.Yes, BindingDirection.OneWay)> _
    Public ReadOnly Property DescriptionPlainText() As String
        Get
            Return DescriptionText.Text
        End Get
    End Property



    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property AppointmentColor() As String
        Get
            ' No color selected
            If AppointmentColorPicker.SelectedColor.A = 0 Then
                Return Nothing
            End If

            Return AppointmentColorPicker.SelectedColor.ToArgb().ToString()
        End Get

        Set(ByVal value As String)
            If String.IsNullOrEmpty(value) Then
                Return
            End If

            Dim argbValue As Integer
            If Integer.TryParse(value, argbValue) Then
                AppointmentColorPicker.SelectedColor = Color.FromArgb(argbValue)
            End If
        End Set
    End Property


    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property RoomID() As Object
        Get
            Return ResRoom.Value
        End Get

        Set(ByVal value As Object)
            ResRoom.Value = value
        End Set
    End Property

    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property UserID() As Object
        Get
            Return ResUser.Value
        End Get

        Set(ByVal value As Object)
            ResUser.Value = value
        End Set
    End Property

#End Region

#Region "Public properties"

    Public Property Mode() As AdvancedFormMode
        Get
            Return _mode
        End Get
        Set(ByVal value As AdvancedFormMode)
            _mode = value
        End Set
    End Property

    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property Subject() As String
        Get
            Return SubjectText.Text
        End Get

        Set(ByVal value As String)
            SubjectText.Text = value
        End Set
    End Property

    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property Start() As DateTime
        Get
            Return Range.Start
        End Get

        Set(ByVal value As DateTime)
            StartDate.SelectedDate = Owner.UtcToDisplay(value)
            StartTime.SelectedDate = Owner.UtcToDisplay(value)
        End Set
    End Property

    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property [End]() As DateTime
        Get
            Return Range.Start.Add(Range.EventDuration)
        End Get

        Set(ByVal value As DateTime)
            EndDate.SelectedDate = Owner.UtcToDisplay(value)
            EndTime.SelectedDate = Owner.UtcToDisplay(value)
        End Set
    End Property


    <Bindable(BindableSupport.Yes, BindingDirection.TwoWay)> _
    Public Property RecurrenceRuleText() As String
        Get
            If Owner.RecurrenceSupport Then
                Dim rrule As RecurrenceRule = RecurrenceRule.FromPatternAndRange(Pattern, Range)

                If rrule = Nothing Then
                    Return String.Empty
                End If

                Dim originalRule As RecurrenceRule = RecurrenceRule.Empty
                If RecurrenceRule.TryParse(OriginalRecurrenceRule.Value, originalRule) Then
                    rrule.Exceptions = originalRule.Exceptions
                End If

                Return rrule.ToString()
            End If

            Return String.Empty
        End Get

        Set(ByVal value As String)
            OriginalRecurrenceRule.Value = value
        End Set
    End Property
#End Region

    Public Sub New()
        InvariantMonthNames = New String(11) {}
        Array.Copy([Enum].GetNames(GetType(RecurrenceMonth)), 1, InvariantMonthNames, 0, 12)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
        UpdateButton.ValidationGroup = Owner.ValidationGroup

        If Mode = AdvancedFormMode.Edit Then
            UpdateButton.CommandName = "Update"
        Else
            UpdateButton.CommandName = "Insert"
        End If

        InitializeStrings()

        If Not FormInitialized Then
            PopulateDescriptions()
            InitializeMonthlyRecurrenceControls()
            InitializeYearlyRecurrenceControls()
            PrefillRecurrenceControls()
            UpdateResetExceptionsVisibility()
        End If
    End Sub

    Protected Overloads Overrides Sub OnPreRender(ByVal e As EventArgs)
        MyBase.OnPreRender(e)

        If Not FormInitialized Then
            If IsAllDayAppointment(Appointment) Then
                EndDate.SelectedDate = EndDate.SelectedDate.Value.AddDays(-1)
            End If

            FormInitialized = True
        End If
    End Sub

    Protected Sub BasicControlsPanel_DataBinding(ByVal sender As Object, ByVal e As EventArgs)
        AllDayEvent.Checked = IsAllDayAppointment(Appointment)
    End Sub

    Protected Sub RecurrencePatternPanel_DataBinding(ByVal sender As Object, ByVal e As EventArgs)
        Dim rrule As RecurrenceRule = RecurrenceRule.Empty
        If Not RecurrenceRule.TryParse(OriginalRecurrenceRule.Value, rrule) Then
            RecurrentAppointment.Checked = False
            Return
        End If

        RecurrentAppointment.Checked = True

        Dim interval As String = rrule.Pattern.Interval.ToString()
        Dim mask As Integer = DirectCast(rrule.Pattern.DaysOfWeekMask, Integer)

        Select Case rrule.Pattern.Frequency
            Case RecurrenceFrequency.Hourly
                RepeatFrequencyHourly.Checked = True
                HourlyRepeatInterval.Text = interval
                Exit Select

            Case RecurrenceFrequency.Daily
                RepeatFrequencyDaily.Checked = True

                If rrule.Pattern.DaysOfWeekMask = RecurrenceDay.WeekDays Then
                    RepeatEveryWeekday.Checked = True
                    RepeatEveryNthDay.Checked = False
                Else
                    RepeatEveryWeekday.Checked = False
                    RepeatEveryNthDay.Checked = True
                    DailyRepeatInterval.Text = interval
                End If
                Exit Select

            Case RecurrenceFrequency.Weekly
                RepeatFrequencyWeekly.Checked = True

                WeeklyRepeatInterval.Text = interval

                WeeklyWeekDayMonday.Checked = (RecurrenceDay.Monday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Monday
                WeeklyWeekDayTuesday.Checked = (RecurrenceDay.Tuesday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Tuesday
                WeeklyWeekDayWednesday.Checked = (RecurrenceDay.Wednesday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Wednesday
                WeeklyWeekDayThursday.Checked = (RecurrenceDay.Thursday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Thursday
                WeeklyWeekDayFriday.Checked = (RecurrenceDay.Friday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Friday
                WeeklyWeekDaySaturday.Checked = (RecurrenceDay.Saturday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Saturday
                WeeklyWeekDaySunday.Checked = (RecurrenceDay.Sunday And rrule.Pattern.DaysOfWeekMask) = RecurrenceDay.Sunday
                Exit Select

            Case RecurrenceFrequency.Monthly
                RepeatFrequencyMonthly.Checked = True

                If 0 < rrule.Pattern.DayOfMonth Then
                    RepeatEveryNthMonthOnDate.Checked = True
                    RepeatEveryNthMonthOnGivenDay.Checked = False
                    MonthlyRepeatDate.Text = rrule.Pattern.DayOfMonth.ToString()
                    MonthlyRepeatIntervalForDate.Text = interval
                Else
                    RepeatEveryNthMonthOnDate.Checked = False
                    RepeatEveryNthMonthOnGivenDay.Checked = True
                    MonthlyDayOrdinalDropDown.SelectedValue = rrule.Pattern.DayOrdinal.ToString()
                    MonthlyDayMaskDropDown.SelectedIndex = Array.IndexOf(DayMaskValues, (mask).ToString())
                    MonthlyRepeatIntervalForGivenDay.Text = interval
                End If
                Exit Select

            Case RecurrenceFrequency.Yearly
                RepeatFrequencyYearly.Checked = True

                If 0 < rrule.Pattern.DayOfMonth Then
                    RepeatEveryYearOnDate.Checked = True
                    RepeatEveryYearOnGivenDay.Checked = False
                    YearlyRepeatDate.Text = rrule.Pattern.DayOfMonth.ToString()
                    YearlyRepeatMonthForDate.SelectedIndex = (DirectCast(rrule.Pattern.Month, Integer)) - 1
                Else
                    RepeatEveryYearOnDate.Checked = False
                    RepeatEveryYearOnGivenDay.Checked = True
                    YearlyDayOrdinalDropDown.SelectedValue = rrule.Pattern.DayOrdinal.ToString()
                    YearlyDayMaskDropDown.SelectedIndex = Array.IndexOf(DayMaskValues, (mask).ToString())
                    YearlyRepeatMonthForGivenDay.SelectedIndex = (DirectCast(rrule.Pattern.Month, Integer)) - 1
                End If
                Exit Select
        End Select
    End Sub

    Protected Sub RecurrenceRangePanel_DataBinding(ByVal sender As Object, ByVal e As EventArgs)
        Dim rrule As RecurrenceRule = RecurrenceRule.Empty
        If Not RecurrenceRule.TryParse(OriginalRecurrenceRule.Value, rrule) Then
            Return
        End If

        Dim occurrencesLimit As Boolean = (rrule.Range.MaxOccurrences <> Integer.MaxValue)
        Dim timeLimit As Boolean = (rrule.Range.RecursUntil <> DateTime.MaxValue)

        If Not occurrencesLimit AndAlso Not timeLimit Then
            RepeatIndefinitely.Checked = True
            RepeatGivenOccurrences.Checked = False
            RepeatUntilGivenDate.Checked = False
        ElseIf occurrencesLimit Then
            RepeatIndefinitely.Checked = False
            RepeatGivenOccurrences.Checked = True
            RepeatUntilGivenDate.Checked = False

            RangeOccurrences.Text = rrule.Range.MaxOccurrences.ToString()
        Else
            RepeatIndefinitely.Checked = False
            RepeatGivenOccurrences.Checked = False
            RepeatUntilGivenDate.Checked = True

            RangeEndDate.SelectedDate = Owner.UtcToDisplay(rrule.Range.RecursUntil).AddDays(-1)
        End If
    End Sub

    Protected Sub DurationValidator_OnServerValidate(ByVal source As Object, ByVal args As ServerValidateEventArgs)
        args.IsValid = Range.EventDuration > TimeSpan.Zero
    End Sub

    Protected Sub ResetExceptions_OnClick(ByVal sender As Object, ByVal e As EventArgs)
        Owner.RemoveRecurrenceExceptions(Appointment)
        OriginalRecurrenceRule.Value = Appointment.RecurrenceRule
        ResetExceptions.Text = Owner.Localization.AdvancedDone
    End Sub

#Region "Private methods"

    Private Sub InitializeStrings()
        SubjectValidator.ErrorMessage = Owner.Localization.AdvancedSubjectRequired
        SubjectValidator.ValidationGroup = Owner.ValidationGroup

        AllDayEvent.Text = Owner.Localization.AdvancedAllDayEvent
        RecurrentAppointment.Text = Owner.Localization.AdvancedRecurrence

        StartDateValidator.ErrorMessage = Owner.Localization.AdvancedStartDateRequired
        StartDateValidator.ValidationGroup = Owner.ValidationGroup

        StartTimeValidator.ErrorMessage = Owner.Localization.AdvancedStartTimeRequired
        StartTimeValidator.ValidationGroup = Owner.ValidationGroup

        EndDateValidator.ErrorMessage = Owner.Localization.AdvancedEndDateRequired
        EndDateValidator.ValidationGroup = Owner.ValidationGroup

        EndTimeValidator.ErrorMessage = Owner.Localization.AdvancedEndTimeRequired
        EndTimeValidator.ValidationGroup = Owner.ValidationGroup

        DurationValidator.ErrorMessage = Owner.Localization.AdvancedStartTimeBeforeEndTime
        DurationValidator.ValidationGroup = Owner.ValidationGroup

        ResetExceptions.Text = Owner.Localization.AdvancedReset

        RepeatFrequencyHourly.Text = Owner.Localization.AdvancedHourly
        RepeatFrequencyDaily.Text = Owner.Localization.AdvancedDaily
        RepeatFrequencyWeekly.Text = Owner.Localization.AdvancedWeekly
        RepeatFrequencyMonthly.Text = Owner.Localization.AdvancedMonthly
        RepeatFrequencyYearly.Text = Owner.Localization.AdvancedYearly

        RepeatEveryNthDay.Text = Owner.Localization.AdvancedEvery

        RepeatEveryWeekday.Text = Owner.Localization.AdvancedEveryWeekday

        RepeatEveryNthMonthOnDate.Text = Owner.Localization.AdvancedDay

        RepeatEveryNthMonthOnGivenDay.Text = Owner.Localization.AdvancedThe

        RepeatEveryYearOnDate.Text = Owner.Localization.AdvancedEvery

        RepeatEveryYearOnGivenDay.Text = Owner.Localization.AdvancedThe

        RepeatIndefinitely.Text = Owner.Localization.AdvancedNoEndDate

        RepeatGivenOccurrences.Text = Owner.Localization.AdvancedEndAfter

        RepeatUntilGivenDate.Text = Owner.Localization.AdvancedEndByThisDate

        SharedCalendar.FastNavigationSettings.OkButtonCaption = Owner.Localization.AdvancedCalendarOK
        SharedCalendar.FastNavigationSettings.CancelButtonCaption = Owner.Localization.AdvancedCalendarCancel
        SharedCalendar.FastNavigationSettings.TodayButtonCaption = Owner.Localization.AdvancedCalendarToday

        WeeklyWeekDayMonday.Text = Owner.Culture.DateTimeFormat.DayNames(1)
        WeeklyWeekDayTuesday.Text = Owner.Culture.DateTimeFormat.DayNames(2)
        WeeklyWeekDayWednesday.Text = Owner.Culture.DateTimeFormat.DayNames(3)
        WeeklyWeekDayThursday.Text = Owner.Culture.DateTimeFormat.DayNames(4)
        WeeklyWeekDayFriday.Text = Owner.Culture.DateTimeFormat.DayNames(5)
        WeeklyWeekDaySaturday.Text = Owner.Culture.DateTimeFormat.DayNames(6)
        WeeklyWeekDaySunday.Text = Owner.Culture.DateTimeFormat.DayNames(0)
    End Sub

    Private Sub PopulateDescriptions()
        DayOrdinalDescriptions = New String(4) {}
        DayOrdinalDescriptions(0) = Owner.Localization.AdvancedFirst
        DayOrdinalDescriptions(1) = Owner.Localization.AdvancedSecond
        DayOrdinalDescriptions(2) = Owner.Localization.AdvancedThird
        DayOrdinalDescriptions(3) = Owner.Localization.AdvancedFourth
        DayOrdinalDescriptions(4) = Owner.Localization.AdvancedLast

        DayMaskDescriptions = New String(9) {}
        DayMaskDescriptions(0) = Owner.Localization.AdvancedMaskDay
        DayMaskDescriptions(1) = Owner.Localization.AdvancedMaskWeekday
        DayMaskDescriptions(2) = Owner.Localization.AdvancedMaskWeekendDay
        Array.Copy(Owner.Culture.DateTimeFormat.DayNames, 0, DayMaskDescriptions, 3, 7)
    End Sub

    Private Sub InitializeMonthlyRecurrenceControls()
        MonthlyDayOrdinalDropDown.Items.AddRange(CreateComboBoxItemArray(DayOrdinalDescriptions, DayOrdinalValues))
        MonthlyDayMaskDropDown.Items.AddRange(CreateComboBoxItemArray(DayMaskDescriptions, DayMaskValues))
    End Sub

    Private Sub InitializeYearlyRecurrenceControls()
        Dim monthNames As String() = New String(11) {}
        Array.Copy(Owner.Culture.DateTimeFormat.MonthNames, monthNames, 12)

        YearlyRepeatMonthForDate.Items.AddRange(CreateComboBoxItemArray(monthNames, InvariantMonthNames))

        YearlyDayOrdinalDropDown.Items.AddRange(CreateComboBoxItemArray(DayOrdinalDescriptions, DayOrdinalValues))
        YearlyDayMaskDropDown.Items.AddRange(CreateComboBoxItemArray(DayMaskDescriptions, DayMaskValues))

        YearlyRepeatMonthForGivenDay.Items.AddRange(CreateComboBoxItemArray(monthNames, InvariantMonthNames))
    End Sub

    Private Sub PrefillRecurrenceControls()
        Dim start As DateTime = Appointment.Start

        Select Case start.DayOfWeek
            Case DayOfWeek.Sunday
                WeeklyWeekDaySunday.Checked = True
                Exit Select

            Case DayOfWeek.Monday
                WeeklyWeekDayMonday.Checked = True
                Exit Select

            Case DayOfWeek.Tuesday
                WeeklyWeekDayTuesday.Checked = True
                Exit Select

            Case DayOfWeek.Wednesday
                WeeklyWeekDayWednesday.Checked = True
                Exit Select

            Case DayOfWeek.Thursday
                WeeklyWeekDayThursday.Checked = True
                Exit Select

            Case DayOfWeek.Friday
                WeeklyWeekDayFriday.Checked = True
                Exit Select

            Case DayOfWeek.Saturday
                WeeklyWeekDaySaturday.Checked = True
                Exit Select
            Case Else

                Throw New ArgumentOutOfRangeException()
        End Select

        MonthlyRepeatDate.Text = start.Day.ToString()

        YearlyRepeatMonthForDate.SelectedValue = InvariantMonthNames(start.Month - 1)
        YearlyRepeatMonthForGivenDay.SelectedValue = YearlyRepeatMonthForDate.SelectedValue
        YearlyRepeatDate.Text = start.Day.ToString()
    End Sub

    Private Sub UpdateResetExceptionsVisibility()
        ResetExceptions.Visible = False
        Dim rrule As RecurrenceRule = RecurrenceRule.Empty
        If RecurrenceRule.TryParse(Appointment.RecurrenceRule, rrule) Then
            ResetExceptions.Visible = rrule.Exceptions.Count > 0
        End If
    End Sub

    Private Function IsAllDayAppointment(ByVal appointment As Appointment) As Boolean
        Dim displayStart As DateTime = Owner.UtcToDisplay(appointment.Start)
        Dim displayEnd As DateTime = Owner.UtcToDisplay(appointment.[End])
        Return displayStart.CompareTo(displayStart.[Date]) = 0 AndAlso displayEnd.CompareTo(displayEnd.[Date]) = 0
    End Function

    Private Shared Function CreateComboBoxItemArray(ByVal descriptions As String()) As RadComboBoxItem()
        Dim listItems As RadComboBoxItem() = New RadComboBoxItem(descriptions.Length - 1) {}

        For i As Integer = 0 To descriptions.Length - 1
            listItems(i) = New RadComboBoxItem(descriptions(i))
        Next

        Return listItems
    End Function

    Private Shared Function CreateComboBoxItemArray(ByVal descriptions As String(), ByVal values As String()) As RadComboBoxItem()
        If descriptions.Length <> values.Length Then
            Throw New InvalidOperationException("There must be equal number of values and descriptions.")
        End If

        Dim listItems As RadComboBoxItem() = CreateComboBoxItemArray(descriptions)

        For i As Integer = 0 To values.Length - 1
            listItems(i).Value = values(i)
        Next

        Return listItems
    End Function
#End Region
End Class
