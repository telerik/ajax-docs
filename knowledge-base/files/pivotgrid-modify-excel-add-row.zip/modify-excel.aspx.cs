﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using eis = Telerik.Web.UI.ExportInfrastructure;

public partial class modify_excel : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		
	}

	#region for-both-excel-export-options
	
	protected void RadPivotGrid1_PivotGridInfrastructureExporting(object sender, PivotGridInfrastructureExportingEventArgs e)
	{
		//set custom cell text, will override the value for BIFF
		e.ExportStructure.Tables[0].ShiftRowsDown(1, 1);
		e.ExportStructure.Tables[0].Cells[1, 1].Value = "custom cell value from InfrastructureExporting event";
	}
	
	#endregion
	
	#region BiffExporting-specific
	
	protected void RadPivotGrid1_PivotGridBiffExporting(object sender, PivotGridBiffExportingEventArgs e)
	{
		//set custom cell text
		//e.ExportStructure.Tables[0].ShiftRowsDown(1, 1);
		//e.ExportStructure.Tables[0].Cells[1, 1].Value = "custom cell value from BiffExporting event";
		
		#region from-demo-unrelated
		
		if (CheckBox2.Checked)
		{
			eis.Table newWorksheet = new eis.Table("My New Worksheet");
			
			eis.Cell headerCell = newWorksheet.Cells[1, 1];
			headerCell.Value = "Legend";
			headerCell.Style.BorderBottomColor = System.Drawing.Color.Black;
			headerCell.Style.BorderBottomStyle = BorderStyle.Double;
			headerCell.Style.Font.Bold = true;
			headerCell.Colspan = 2;
			newWorksheet.Columns[1].Width = 32D;
			newWorksheet.Cells[1, 2].Value = "Cells";
			newWorksheet.Cells[1, 2].Style.Font.Bold = true;
			newWorksheet.Cells[2, 2].Value = "Color";
			newWorksheet.Cells[2, 2].Style.Font.Bold = true;
			
			newWorksheet.Cells[1, 3].Value = "Cells with values bigger than 100 000";
			newWorksheet.Cells[1, 4].Value = "Totals� cells";
			newWorksheet.Cells[1, 5].Value = "Grand totals� cells";
			newWorksheet.Cells[1, 6].Value = "Row and column header tables� cells";
			
			newWorksheet.Cells[2, 3].Value = "#33CCCC";
			newWorksheet.Cells[2, 3].Style.BackColor = Color.FromArgb(51, 204, 204);
			newWorksheet.Cells[2, 4].Value = "#969696";
			newWorksheet.Cells[2, 4].Style.BackColor = Color.FromArgb(150, 150, 150);
			newWorksheet.Cells[2, 5].Value = "#808080";
			newWorksheet.Cells[2, 5].Style.BackColor = Color.FromArgb(128, 128, 128);
			newWorksheet.Cells[2, 6].Value = "#C0C0C0";
			newWorksheet.Cells[2, 6].Style.BackColor = Color.FromArgb(192, 192, 192);
		
			e.ExportStructure.Tables.Add(newWorksheet);
		}

		#endregion
	}
	
	#endregion
	
	#region demo-code-unrelated
		
	protected void RadPivotGrid1_NeedDataSource(object sender, PivotGridNeedDataSourceEventArgs e)
	{
		(sender as RadPivotGrid).DataSource = GetDataTable("SELECT * FROM Transportation");
	}
		
	public DataTable GetDataTable(string query)
	{
		String ConnString = ConfigurationManager.ConnectionStrings["TelerikConnectionString"].ConnectionString;
		SqlConnection conn = new SqlConnection(ConnString);
		SqlDataAdapter adapter = new SqlDataAdapter();
		adapter.SelectCommand = new SqlCommand(query, conn);
		
		DataTable myDataTable = new DataTable();
		
		conn.Open();
		try
		{
			adapter.Fill(myDataTable);
		}
		finally
		{
			conn.Close();
		}
		
		return myDataTable;
	}
		
	protected void RadPivotGrid1_PivotGridCellExporting(object sender, PivotGridCellExportingArgs e)
	{
		if (!CheckBox3.Checked)
		{
			return;
		}
		PivotGridBaseModelCell modelDataCell = e.PivotGridModelCell as PivotGridBaseModelCell;
		if (modelDataCell != null)
		{
			AddStylesToDataCells(modelDataCell, e);
		}
			
		if (modelDataCell.TableCellType == PivotGridTableCellType.RowHeaderCell)
		{
			AddStylesToRowHeaderCells(modelDataCell, e);
		}
			
		if (modelDataCell.TableCellType == PivotGridTableCellType.ColumnHeaderCell)
		{
			AddStylesToColumnHeaderCells(modelDataCell, e);
		}
			
		if (modelDataCell.IsGrandTotalCell)
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(128, 128, 128);
			e.ExportedCell.Style.Font.Bold = true;
		}
			
		if (IsTotalDataCell(modelDataCell))
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(150, 150, 150);
			e.ExportedCell.Style.Font.Bold = true;
			AddBorders(e);
		}
			
		if (IsGrandTotalDataCell(modelDataCell))
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(128, 128, 128);
			e.ExportedCell.Style.Font.Bold = true;
			AddBorders(e);
		}
	}
		
	private void AddStylesToDataCells(PivotGridBaseModelCell modelDataCell, PivotGridCellExportingArgs e)
	{
		if (modelDataCell.Data != null && modelDataCell.Data.GetType() == typeof(decimal))
		{
			decimal value = Convert.ToDecimal(modelDataCell.Data);
			if (value > 100000)
			{
				e.ExportedCell.Style.BackColor = Color.FromArgb(51, 204, 204);
				AddBorders(e);
			}
	
			e.ExportedCell.Format = "$0.0";
		}
	}
		
	private void AddStylesToColumnHeaderCells(PivotGridBaseModelCell modelDataCell, PivotGridCellExportingArgs e)
	{
		if (e.ExportedCell.Table.Columns[e.ExportedCell.ColIndex].Width == 0)
		{
			e.ExportedCell.Table.Columns[e.ExportedCell.ColIndex].Width = 200D;
		}
			
		if (modelDataCell.IsTotalCell)
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(150, 150, 150);
			e.ExportedCell.Style.Font.Bold = true;
		}
		else
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(192, 192, 192);
		}
		AddBorders(e);
	}
		
	private void AddStylesToRowHeaderCells(PivotGridBaseModelCell modelDataCell, PivotGridCellExportingArgs e)
	{
		if (e.ExportedCell.Table.Columns[e.ExportedCell.ColIndex].Width == 0)
		{
			e.ExportedCell.Table.Columns[e.ExportedCell.ColIndex].Width = 80D;
		}
		if (modelDataCell.IsTotalCell)
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(150, 150, 150);
			e.ExportedCell.Style.Font.Bold = true;
		}
		else
		{
			e.ExportedCell.Style.BackColor = Color.FromArgb(192, 192, 192);
		}
		
		AddBorders(e);
	}
		
	private static void AddBorders(PivotGridCellExportingArgs e)
	{
		e.ExportedCell.Style.BorderBottomColor = Color.FromArgb(128, 128, 128);
		e.ExportedCell.Style.BorderBottomWidth = new Unit(1);
		e.ExportedCell.Style.BorderBottomStyle = BorderStyle.Solid;
		
		e.ExportedCell.Style.BorderRightColor = Color.FromArgb(128, 128, 128);
		e.ExportedCell.Style.BorderRightWidth = new Unit(1);
		e.ExportedCell.Style.BorderRightStyle = BorderStyle.Solid;
		
		e.ExportedCell.Style.BorderLeftColor = Color.FromArgb(128, 128, 128);
		e.ExportedCell.Style.BorderLeftWidth = new Unit(1);
		e.ExportedCell.Style.BorderLeftStyle = BorderStyle.Solid;
		
		e.ExportedCell.Style.BorderTopColor = Color.FromArgb(128, 128, 128);
		e.ExportedCell.Style.BorderTopWidth = new Unit(1);
		e.ExportedCell.Style.BorderTopStyle = BorderStyle.Solid;
	}
		
	private bool IsTotalDataCell(PivotGridBaseModelCell modelDataCell)
	{
		return modelDataCell.TableCellType == PivotGridTableCellType.DataCell &&
			   (modelDataCell.CellType == PivotGridDataCellType.ColumnTotalDataCell ||
				modelDataCell.CellType == PivotGridDataCellType.RowTotalDataCell ||
				modelDataCell.CellType == PivotGridDataCellType.RowAndColumnTotal);
	}
		
	private bool IsGrandTotalDataCell(PivotGridBaseModelCell modelDataCell)
	{
		return modelDataCell.TableCellType == PivotGridTableCellType.DataCell &&
			   (modelDataCell.CellType == PivotGridDataCellType.ColumnGrandTotalDataCell ||
				modelDataCell.CellType == PivotGridDataCellType.ColumnGrandTotalRowTotal ||
				modelDataCell.CellType == PivotGridDataCellType.RowGrandTotalColumnTotal ||
				modelDataCell.CellType == PivotGridDataCellType.RowGrandTotalDataCell ||
				modelDataCell.CellType == PivotGridDataCellType.RowAndColumnGrandTotal);
	}
		
	protected void ButtonExcel_Click(object sender, EventArgs e)
	{
		string alternateText = (sender as ImageButton).AlternateText;
		RadPivotGrid1.ExportSettings.Excel.Format = (PivotGridExcelFormat)Enum.Parse(typeof(PivotGridExcelFormat), alternateText);
		RadPivotGrid1.ExportSettings.IgnorePaging = CheckBox1.Checked;
		RadPivotGrid1.ExportToExcel();
	}
		
	protected void RadPivotGrid1_CellDataBound(object sender, PivotGridCellDataBoundEventArgs e)
	{
		PivotGridDataCell cell = e.Cell as PivotGridDataCell;
		if (cell != null && cell.DataItem != null && cell.DataItem.GetType() == typeof(decimal) && cell.CellType == PivotGridDataCellType.DataCell)
		{
			decimal value = Convert.ToDecimal(e.Cell.DataItem);
			if (value > 100000)
			{
				e.Cell.BackColor = Color.FromArgb(203, 239, 246);
			}
		}
	}
		
	protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
	{
		CheckBox2.Enabled = CheckBox3.Checked;
		if (!CheckBox3.Checked)
		{
			CheckBox2.Checked = false;
		}
	}

	#endregion 
}