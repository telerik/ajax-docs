﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.Linq;
using System.IO;

public partial class Default : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		//System.Threading.Thread.Sleep(100);
	}

	protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
	{
		DataTable table = new DataTable();
		table.Columns.Add("ID", typeof(int));
		table.Columns.Add("Continent", typeof(string));
		table.Columns.Add("Country", typeof(string));
		table.Columns.Add("City", typeof(string));
		table.Columns.Add("Numeric", typeof(int));
		table.Columns.Add("Date", typeof(DateTime));

		for (int i = 0; i < 50; i++)
		{
			table.Rows.Add(1, "North America", "United States", "Washington", 5, DateTime.Now);
			table.Rows.Add(2, "North America", "United States", "New York", 2, DateTime.Now);
			table.Rows.Add(3, "Europe", "England", "London", 10, DateTime.Now);
			table.Rows.Add(4, "Europe", "France", "Paris", 23, DateTime.Now);
			table.Rows.Add(5, "North America", "Mexico", "Guadalajara", 32, DateTime.Now);
			table.Rows.Add(6, "Europe", "France", "Caen", 4, DateTime.Now);

			(sender as RadGrid).DataSource = table;
		}
		
	}

	protected void RadComboBox1_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
	{
		RadComboBox comboBox = sender as RadComboBox;
		string columnName = e.Context["ColumnName"].ToString();
		string relatedValue = e.Context["RelatedValue"] != null ? e.Context["RelatedValue"].ToString() : "";


		//Retrieve the RadComboBox data, based on the relatedValue and the columnName
		//--------------------------------------------------------
		List<DemoItem> items = new List<DemoItem>();
		if (columnName == "Continent")
		{
			items = DemoRelatedValues.GetContinents();
		}
		else if (columnName == "Country")
		{
			items = DemoRelatedValues.GetCountries(relatedValue);
		}
		else if (columnName == "City")
		{
			items = DemoRelatedValues.GetCities(relatedValue);
		}

		if (items.Count > 0)
		{
			foreach (DemoItem item in items)
			{
				comboBox.Items.Add(new RadComboBoxItem(item.Text));
			}
		}
	}

	protected void RadGrid1_BatchEditCommand(object sender, GridBatchEditingEventArgs e)
	{

	}

	protected void Page_PreRender(object sender, EventArgs e)
	{
		GridTableView masterTable = RadGrid1.MasterTableView;
		foreach (GridColumn column in masterTable.RenderColumns)
		{
			if ((column is IGridEditableColumn) && (column as IGridEditableColumn).IsEditable && masterTable.GetBatchColumnEditor(column.UniqueName) != null)
			{
				Control container = (masterTable.GetBatchColumnEditor(column.UniqueName) as IGridColumnEditor).ContainerControl;
				if (container != null && container.Controls.Count > 0)
				{
					(container.Controls[0] as WebControl).Width = Unit.Percentage(100);
				}
			}
		}
	}
    protected void radAjaxMgr_AjaxRequest(object sender, AjaxRequestEventArgs e)
    {
        RadGrid1.Rebind();
    }
}


#region dummy-data

public static class DemoRelatedValues
{
	private static List<DemoItem> Continents()
	{
		List<DemoItem> items = new List<DemoItem>();
		items.Add(new DemoItem(1, "North America"));
		items.Add(new DemoItem(2, "Europe"));
		return items;
		//items.FindAll(x => x.Value == 1);
	}

	private static List<DemoItem> Countries()
	{
		List<DemoItem> items = new List<DemoItem>();
		int id = 1;
		items.Add(new DemoItem(id++, "United States", 1));
		items.Add(new DemoItem(id++, "Canada", 1));
		items.Add(new DemoItem(id++, "England", 2));
		items.Add(new DemoItem(id++, "France", 2));
		items.Add(new DemoItem(id++, "Mexico", 1));
		return items;
	}

	private static List<DemoItem> Cities()
	{
		List<DemoItem> items = new List<DemoItem>();
		int id = 1;
		int rel = 1;
		//United States
		items.Add(new DemoItem(id++, "Washington", rel));
		items.Add(new DemoItem(id++, "New York", rel));
		items.Add(new DemoItem(id++, "Los Angeles", rel));
		items.Add(new DemoItem(id++, "Chicago", rel));
		items.Add(new DemoItem(id++, "Phoenix", rel));
		items.Add(new DemoItem(id++, "Phoenix", rel));

		//Canada
		rel++;
		items.Add(new DemoItem(id++, "Ottawa", rel));
		items.Add(new DemoItem(id++, "Edmonton", rel));

		//England
		rel++;
		items.Add(new DemoItem(id++, "London", rel));
		items.Add(new DemoItem(id++, "Bristol", rel));
		items.Add(new DemoItem(id++, "Birmingham", rel));
		items.Add(new DemoItem(id++, "Bradford", rel));
		items.Add(new DemoItem(id++, "Canterbury", rel));

		//France
		rel++;
		items.Add(new DemoItem(id++, "Paris", rel));
		items.Add(new DemoItem(id++, "Nice", rel));
		items.Add(new DemoItem(id++, "Caen", rel));
		items.Add(new DemoItem(id++, "Nancy", rel));
		items.Add(new DemoItem(id++, "Créteil", rel));

		//Mexico
		rel++;
		items.Add(new DemoItem(id++, "Guadalajara", rel));
		items.Add(new DemoItem(id++, "Mexico City", rel));
		items.Add(new DemoItem(id++, "Puebla", rel));
		items.Add(new DemoItem(id++, "Tijuana", rel));


		return items;
	}

	public static List<DemoItem> GetContinents()
	{
		return Continents();
	}

	public static List<DemoItem> GetCountries(string filterValue)
	{
		int continentID = Continents().Where(x => x.Text == filterValue).ToList()[0].Value;
		return Countries().Where(x => x.Relation == continentID).ToList();
	}

	public static List<DemoItem> GetCities(string filterValue)
	{
		int countryID = Countries().Where(x => x.Text == filterValue).ToList()[0].Value;
		return Cities().Where(x => x.Relation == countryID).ToList();
	}
}

public class DemoItem
{
	public int Value { get; set; }
	public string Text { get; set; }
	public int Relation { get; set; }

	public DemoItem(int value, string text, int relation)
	{
		this.Value = value;
		this.Text = text;
		this.Relation = relation;
	}

	public DemoItem(int value, string text)
	{
		this.Value = value;
		this.Text = text;
	}
}

#endregion