﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SpecialUrlCharsHelperr
/// </summary>
public class SpecialUrlCharsHelperr
{
    private SpecialUrlCharsHelperr()
    {
    }

    private static string[] CHARS_FOR_ENCODE = new string[] { " " };
    /// <summary>
    /// Url encodes a string by specified symbols and replacements 
    /// </summary>
    /// <param name="stringForEncode"></param>
    /// <returns></returns>
    public static string UrlEncode(string stringForEncode)
    {// Covers scenarios that are not covered by the HttpUtility.UrlEncode method

        string encodedString = stringForEncode;
        foreach (string specString in CHARS_FOR_ENCODE)
        {
            encodedString = encodedString.Replace(specString, HttpUtility.UrlEncode(specString));
        }

        return encodedString;
    }

    /// <summary>
    /// Url decodes a string by specified symbols and replacements 
    /// </summary>
    /// <param name="stringForDecode"></param>
    /// <returns></returns>
    public static string UrlDecode(string stringForDecode)
    {// Covers scenarios that are not covered by the HttpUtility.UrlDecode method

        string decoddedString = stringForDecode;
        foreach (string specString in CHARS_FOR_ENCODE)
        {
            decoddedString = decoddedString.Replace(HttpUtility.UrlEncode(specString), specString);
        }

        return decoddedString;
    }
}
