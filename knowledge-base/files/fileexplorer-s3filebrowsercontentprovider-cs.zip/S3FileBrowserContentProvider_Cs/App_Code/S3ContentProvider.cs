﻿using System;
using System.Collections.Generic;
using System.Web;
using Telerik.Web.UI.Widgets;
using System.IO;
using System.Xml;
using Affirma.ThreeSharp;
using Affirma.ThreeSharp.Query;
using Affirma.ThreeSharp.Model;

/// <summary>
/// Summary description for CustomFileSistemProvider
/// </summary>
public class S3ContentProvider : FileBrowserContentProvider
{
    private string _itemHandlerPath = "S3FileSystemHandler.ashx";
    // Insert your AWS access keys here.
    private readonly string awsAccessKeyId = "";
    private readonly string awsSecretAccessKey = "";
    private readonly string BUCKET_NAME = "";
    private IThreeSharp service;

    protected string ItemHandlerPath
    {
        get { return this._itemHandlerPath; }
    }

    public S3ContentProvider(HttpContext context, string[] searchPatterns, string[] viewPaths, string[] uploadPaths, string[] deletePaths, string selectedUrl, string selectedItemTag)
        : base(context, searchPatterns, viewPaths, uploadPaths, deletePaths, selectedUrl, selectedItemTag)
    {
        ThreeSharpConfig config = new ThreeSharpConfig();
        config.AwsAccessKeyID = awsAccessKeyId;
        config.AwsSecretAccessKey = awsSecretAccessKey;
        this.service = new ThreeSharpQuery(config);
    }

    public override DirectoryItem ResolveRootDirectoryAsTree(string path)
    {
        path = VirtualPathUtility.AppendTrailingSlash(path);
        DirectoryItem[] subDirs = GetDirectories(path);
        // The files will be added in the ResolveDirectory method
        DirectoryItem result = new DirectoryItem(GetDirectoryName(path),
                                                    string.Empty,
                                                    path,
                                                    string.Empty,
                                                    GetPermissions(path),
                                                    null,
                                                    subDirs);

        return result;
    }

    public override DirectoryItem ResolveDirectory(string virtualPath)
    {
        FileItem[] childFiles = GetFiles(virtualPath);
        // The directories will be added in the ResolveRootDirectoryAsTree method
        DirectoryItem result = new DirectoryItem(GetDirectoryName(virtualPath),
                                                string.Empty,
                                                VirtualPathUtility.AppendTrailingSlash(virtualPath),
                                                virtualPath,
                                                GetPermissions(virtualPath),
                                                childFiles,
                                                null);
        return result;
    }

    public override string MoveDirectory(string virtualSourcePath, string virtualDestPath)
    {
        virtualSourcePath = VirtualPathUtility.AppendTrailingSlash(virtualSourcePath);
        virtualDestPath = VirtualPathUtility.AppendTrailingSlash(virtualDestPath);

        // Check whether the folder already exists ;
        if (IsDirectoryExists(virtualDestPath))
        {
            // Yes the folder exists :
            string message = "The folder  '" + virtualDestPath + "' already exists";
            return message;
        }

        // Check whether the source directory is parent of the destination directory ;
        if (IsParentOf(virtualSourcePath, virtualDestPath))
        {
            string message = ("The folder  '" + virtualSourcePath + "' is parent of the ") + virtualDestPath + "' directory. Operation is canceled !";
            return message;
        }

        // There is not permission issue with the FileExplorer's permissions ==> Move can be performed
        // There can be some S3 service error (interrupted internet connection for example) ;
        string result = S3CopyDirectory(virtualSourcePath, virtualDestPath);

        if (result != string.Empty)
        {
            return result;
        }
        // Else 
        result = DeleteDirectory(virtualSourcePath);
        // else 
        return result;
    }

    public override string MoveFile(string virtualSourcePath, string virtualDestPath)
    {
        // Check whether the file already exists in the destination folder ;
        if (IsFileExists(virtualDestPath))
        {
            // Yes the file exists :
            string message = "The file  '" + virtualDestPath + "' already exists";
            return message;
        }

        string result = CopyFile(virtualSourcePath, virtualDestPath);

        if (result != string.Empty)
        {
            return result;
        }
        // Else 
        result = DeleteFile(virtualSourcePath);
        // else 
        return result;
    }

    public override string DeleteDirectory(string virtualTargetPath)
    {
        virtualTargetPath = VirtualPathUtility.AppendTrailingSlash(virtualTargetPath);

        try
        {
            string realS3TargetPath = VirtualPathUtility.RemoveTrailingSlash(virtualTargetPath);
            realS3TargetPath = SpecialUrlCharsHelperr.UrlEncode(realS3TargetPath);

            using (ObjectDeleteRequest deleteRequest = new ObjectDeleteRequest(BUCKET_NAME, realS3TargetPath + "_$folder$"))
            {
                using (ObjectDeleteResponse deleteResponse = S3Service.ObjectDelete(deleteRequest))
                {
                }
            }
            List<XmlNode> responseResult = ListBucket(virtualTargetPath);
            foreach (XmlNode content in responseResult)
            {
                string currentElementTarget = GetKeyNode(content).InnerText;
                if (IsFile(currentElementTarget))
                {
                    string err = DeleteFile(currentElementTarget);
                    if (err != string.Empty)
                    {
                        return err;
                    }
                }
                else
                {
                    // Directory
                    currentElementTarget = currentElementTarget.Replace("_$folder$", "");
                    string err = DeleteDirectory(currentElementTarget);
                    if (err != string.Empty)
                    {
                        return err;
                    }
                }
            }

            return string.Empty;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'DeleteDirectory' method";
        }
    }

    public override string DeleteFile(string virtualTargetPath)
    {
        try
        {
            string realS3TargetPath = SpecialUrlCharsHelperr.UrlEncode(virtualTargetPath);
            using (ObjectDeleteRequest deleteRequest = new ObjectDeleteRequest(BUCKET_NAME, realS3TargetPath))
            {
                using (ObjectDeleteResponse deleteResponse = S3Service.ObjectDelete(deleteRequest))
                {
                }
            }

            return string.Empty;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'DeleteFile' method";
        }
        // else 
    }

    public override string CopyDirectory(string virtualSourcePath, string virtualDestPath)
    {
        virtualSourcePath = VirtualPathUtility.AppendTrailingSlash(virtualSourcePath);
        virtualDestPath = VirtualPathUtility.AppendTrailingSlash(virtualDestPath);

        // The realDestinationPath already contains a trailing slash 
        string newFolderName = virtualDestPath + GetDirectoryName(virtualSourcePath);

        // Check whether the folder already exists in the destination folder ;
        if (IsDirectoryExists(newFolderName))
        {
            // Yes the folder exists :
            string message = "The folder  '" + newFolderName + "' already exists";
            return message;
        }

        // Check whether the source directory is parent of the destination directory ;
        if (IsParentOf(virtualSourcePath, virtualDestPath))
        {
            string message = ("The folder  '" + virtualSourcePath + "' is parent of the ") + virtualDestPath + "' directory. Operation is canceled !";
            return message;
        }

        // FileSystem.CopyDirectory returns a string that contains the error or an empty string ;
        string errorMessage = S3CopyDirectory(virtualSourcePath, virtualDestPath + GetDirectoryName(virtualSourcePath) + "/");
        return errorMessage;
    }

    public override string CopyFile(string virtualSourcePath, string virtualDestPath)
    {
        // Check whether the file already exists in the destination folder ;
        if (IsFileExists(virtualDestPath))
        {
            // Yes the file exists :
            string message = "The file  '" + virtualDestPath + "' already exists. Operation canceled!";
            return message;
        }

        // There is not permission issue with the FileExplorer's permissions ==> Copy can be performed
        try
        {
            string realS3SourcePath = SpecialUrlCharsHelperr.UrlEncode(virtualSourcePath);
            string realS3DestPath = SpecialUrlCharsHelperr.UrlEncode(virtualDestPath);
            using (ObjectCopyRequest copyRequest = new ObjectCopyRequest(BUCKET_NAME, realS3SourcePath, BUCKET_NAME, realS3DestPath))
            {
                using (ObjectCopyResponse copyResponse = S3Service.ObjectCopy(copyRequest))
                {
                }
            }

            return string.Empty;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'CopyFile' method";
        }
    }

    public override string CreateDirectory(string virtualTargetPath, string name)
    {
        string virtualNewFolderPath = virtualTargetPath + name + "/";

        if (IsDirectoryExists(virtualNewFolderPath))
        {
            string error = "The directory '" + virtualNewFolderPath + "' already exists";
            return error;
        }


        string realS3TargetePath = VirtualPathUtility.AppendTrailingSlash(virtualTargetPath) + name;
        realS3TargetePath = SpecialUrlCharsHelperr.UrlEncode(realS3TargetePath);
        realS3TargetePath = realS3TargetePath + "_$folder$";

        try
        {
            using (ObjectAddRequest addRequest = new ObjectAddRequest(BUCKET_NAME, realS3TargetePath))
            {
                using (ObjectAddResponse addtResponse = S3Service.ObjectAdd(addRequest))
                {
                }
            }

            return string.Empty;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'CreateDirectory' method";
        }
    }

    public override bool CheckWritePermissions(string virtualTargetPath)
    {
        // The upload permission is no set ==> no write permission;
        bool uploadPermissions = HasUploadPermission(virtualTargetPath) | HasDeletePermission(virtualTargetPath);
        return uploadPermissions;
    }

    public override bool CheckDeletePermissions(string virtualTargetPath)
    {
        bool deletePermissions = HasDeletePermission(virtualTargetPath);
        return deletePermissions;
    }

    public override string StoreFile(Telerik.Web.UI.UploadedFile file, string path, string name, params string[] arguments)
    {
        BinaryReader binReader = new BinaryReader(file.InputStream);

        try
        {
            string virtualPathToNewFile = VirtualPathUtility.AppendTrailingSlash(path) + file.GetName();
            string realS3TargetePath = SpecialUrlCharsHelperr.UrlEncode(virtualPathToNewFile);
            using (ObjectAddRequest addRequest = new ObjectAddRequest(BUCKET_NAME, realS3TargetePath))
            {
                addRequest.LoadStreamWithBytes(binReader.ReadBytes((int)file.InputStream.Length), ThreeSharpUtils.ConvertExtensionToMimeType(file.GetExtension()));
                using (ObjectAddResponse addResponse = S3Service.ObjectAdd(addRequest))
                {
                }
            }
            return virtualPathToNewFile;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'CreateDirectory' method";
        }
    }

    // This function is obsolete ;
    public override string StoreFile(HttpPostedFile file, string path, string name, params string[] arguments)
    {
        throw new NotFiniteNumberException();
    }

    public override string StoreBitmap(System.Drawing.Bitmap bitmap, string url, System.Drawing.Imaging.ImageFormat format)
    {
        string virtualPath = RemoveProtocolNameAndServerName(url);

        MemoryStream memStream = new MemoryStream();
        bitmap.Save(memStream, format);
        try
        {
            string realS3TargetePath = SpecialUrlCharsHelperr.UrlEncode(virtualPath);
            using (ObjectAddRequest addRequest = new ObjectAddRequest(BUCKET_NAME, realS3TargetePath))
            {
                addRequest.LoadStreamWithBytes(memStream.ToArray(), ThreeSharpUtils.ConvertExtensionToMimeType(".bmp"));
                using (ObjectAddResponse addResponse = S3Service.ObjectAdd(addRequest))
                {
                }
            }

            return virtualPath;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'CreateDirectory' method";
        }
    }

    public override string GetFileName(string url)
    {
        return Path.GetFileName(RemoveProtocolNameAndServerName(url));
    }

    public override Stream GetFile(string url)
    {
        string virtualPath = RemoveProtocolNameAndServerName(url);
        if (!IsFileExists(virtualPath))
        {
            return null;
        }

        try
        {
            string realS3TargetePath = SpecialUrlCharsHelperr.UrlEncode(virtualPath);
            using (ObjectGetRequest getRequest = new ObjectGetRequest(BUCKET_NAME, realS3TargetePath))
            {
                using (ObjectGetResponse getResponse = S3Service.ObjectGet(getRequest))
                {
                    // getResponse.DataStream is not seekable and 
                    // getResponse.DataStream.Length will throw an exception
                    Stream responseStream = getResponse.DataStream;
                    MemoryStream memStream = new MemoryStream();// Memory stream is seekable
                    byte[] respBuffer = new byte[1024];

                    try
                    {
                        int bytesRead = responseStream.Read(respBuffer, 0, respBuffer.Length);
                        while (bytesRead > 0)
                        {// read the file from the S3Store into the memory
                            memStream.Write(respBuffer, 0, bytesRead);
                            bytesRead = responseStream.Read(respBuffer, 0, respBuffer.Length);
                        }
                    }
                    finally
                    {
                        responseStream.Close();
                    }

                    memStream.Position = 0;// Ready to be read
                    return memStream;
                }
            }
        }
        catch (ThreeSharpException ex)
        {
            return null;
        }
    }

    public override bool CanCreateDirectory
    {
        get { return true; }
    }

    public override string GetPath(string path)
    {
        // First add the '~/' signs in order to use the VirtualPathUtility.GetDirectory() method ;
        string pathWithTilde = "~/" + path;
        string virtualPath = VirtualPathUtility.GetDirectory(pathWithTilde);
        virtualPath = virtualPath.Remove(0, 2);
        // remove the '~' signs
        return virtualPath;
    }

    public override char PathSeparator
    {
        get { return '/'; }
    }


    /// <summary>
    /// Checks Upload permissions
    /// </summary>
    /// <param name="virtualPath"> The path to a folder in the S3 store</param>
    /// <returns></returns>
    private bool HasUploadPermission(string virtualPath)
    {
        foreach (string uploadPath in this.UploadPaths)
        {
            string t1 = VirtualPathUtility.AppendTrailingSlash(virtualPath);
            string t2 = VirtualPathUtility.AppendTrailingSlash(uploadPath);

            if (VirtualPathUtility.AppendTrailingSlash(virtualPath).StartsWith(VirtualPathUtility.AppendTrailingSlash(uploadPath), StringComparison.CurrentCultureIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Checks Delete permissions
    /// </summary>
    /// <param name="realPath"> The path to a folder in the S3 store</param>
    /// <returns></returns>
    private bool HasDeletePermission(string virtualPath)
    {
        foreach (string deletePath in this.DeletePaths)
        {
            if (VirtualPathUtility.AppendTrailingSlash(virtualPath).StartsWith(VirtualPathUtility.AppendTrailingSlash(deletePath), StringComparison.CurrentCultureIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Checks whether the first path is child of the second path
    /// </summary>
    /// <param name="virtualParent">Should be the parent path</param>
    /// <param name="virtualChild">Should be the child path</param>
    /// <returns></returns>
    protected bool IsParentOf(string virtualParent, string virtualChild)
    {
        if (virtualChild.Equals(virtualParent, StringComparison.CurrentCultureIgnoreCase))
        {
            return false;
        }

        // else if
        if (virtualChild.StartsWith(virtualParent, StringComparison.CurrentCultureIgnoreCase))
        {
            return true;
        }

        // else
        return false;
    }

    #region "Helper functions"

    /// <summary>
    /// Gets the name of the directory.
    /// Example 'folder2/Folder2' ==> the function returns 'Folder2' 
    /// </summary>
    /// <param name="virtualPath"></param>
    /// <returns></returns>
    public string GetDirectoryName(string path)
    {
        path = path.Replace("_$folder$", "");
        path = VirtualPathUtility.RemoveTrailingSlash(path);
        int lastIndexOfSlash = path.LastIndexOf("/");
        string name = string.Empty;
        if (lastIndexOfSlash >= 0)
        {
            name = path.Substring(lastIndexOfSlash + 1);
        }
        else
        {
            name = path;
        }

        return name;
    }

    private bool IsFile(string path)
    {
        bool isFolder = path.EndsWith("_$folder$");

        return !isFolder;
    }


    /// <summary>
    /// Gets the permissions granted to the passed path
    /// </summary>
    /// <param name="virtualPath">The path to an item (file or filder)</param>
    /// <returns>The permissions</returns>
    private PathPermissions GetPermissions(string virtualPath)
    {
        PathPermissions permission = PathPermissions.Read;
        permission = HasUploadPermission(virtualPath) ? permission | PathPermissions.Upload : permission;
        permission = HasDeletePermission(virtualPath) ? permission | PathPermissions.Delete : permission;

        return permission;
    }
    /// <summary>
    /// Gets the 'Size' child node of a 'Content' node 
    /// </summary>
    /// <param name="contentsNode">Node of type 'Content'</param>
    /// <returns>The 'Size' node</returns>
    private XmlNode GetSizeNode(XmlNode contentsNode)
    {
        foreach (XmlNode contentNodeChild in contentsNode.ChildNodes)
        {
            if (contentNodeChild.Name == "Size")
            {
                return contentNodeChild;
            }
        }

        return null;
    }

    /// <summary>
    /// Gets the 'Key' child node of a 'Content' node 
    /// </summary>
    /// <param name="contentsNode">Node of type 'Content'</param>
    /// <returns>The 'Size' node</returns>
    private XmlNode GetKeyNode(XmlNode contentsNode)
    {
        foreach (XmlNode contentNodeChild in contentsNode.ChildNodes)
        {
            if (contentNodeChild.Name == "Key")
            {
                contentNodeChild.InnerText = SpecialUrlCharsHelperr.UrlDecode(contentNodeChild.InnerText);
                return contentNodeChild;
            }
        }

        return null;
    }

    /// <summary>
    /// Lsits the folders and the files that are imediate children to the 'startsWith' folder 
    /// </summary>
    /// <param name="startsWith">Path to a folder</param>
    /// <returns>List of 'Contents' XmlNodes only</returns>
    private List<XmlNode> ListBucket(string startsWith)
    {
        startsWith = startsWith.Replace("_$folder$", "");
        startsWith = VirtualPathUtility.AppendTrailingSlash(startsWith);

        string realS3PathStartsWith = SpecialUrlCharsHelperr.UrlEncode(startsWith);
        XmlDocument responseResult = new XmlDocument();

        using (BucketListRequest request = new BucketListRequest(BUCKET_NAME))
        {
            request.QueryList.Add("prefix", realS3PathStartsWith);
            request.QueryList.Add("delimiter", "/");

            using (BucketListResponse response = S3Service.BucketList(request))
            {
                responseResult = response.StreamResponseToXmlDocument();
            }
        }

        XmlNodeList nodeList = responseResult.DocumentElement.ChildNodes;

        List<XmlNode> contentNodes = new List<XmlNode>();
        foreach (XmlNode node in nodeList)
        {
            if (node.Name == "Contents")
            {
                contentNodes.Add(node);
            }
        }

        return contentNodes;
    }

    /// <summary>
    /// Retrieves the child directories
    /// </summary>
    /// <param name="realDirectoryPath">The parent directory</param>
    /// <returns></returns>
    private DirectoryItem[] GetDirectories(string realDirectoryPath)
    {
        realDirectoryPath = VirtualPathUtility.AppendTrailingSlash(realDirectoryPath);
        List<DirectoryItem> directoriesResult = new List<DirectoryItem>();
        List<XmlNode> responseResult = ListBucket(realDirectoryPath);

        foreach (XmlNode content in responseResult)
        {
            string key = GetKeyNode(content).InnerText;

            if (key.EndsWith("_$folder$"))
            {
                string directoryFullPath = VirtualPathUtility.AppendTrailingSlash(realDirectoryPath) + GetDirectoryName(key);
                DirectoryItem dirItem = new DirectoryItem(GetDirectoryName(key),
                                                            string.Empty,
                                                            VirtualPathUtility.AppendTrailingSlash(directoryFullPath),
                                                            string.Empty,
                                                            GetPermissions(directoryFullPath),
                                                            GetFiles(key),
                                                            null);
                directoriesResult.Add(dirItem);
            }
        }
        return directoriesResult.ToArray();
    }

    /// <summary>
    /// Retrieves the child files
    /// </summary>
    /// <param name="realDirectoryPath">The parent directory</param>
    /// <returns></returns>
    private FileItem[] GetFiles(string realDirectoryPath)
    {
        List<FileItem> filesResult = new List<FileItem>();
        List<XmlNode> responseResult = ListBucket(realDirectoryPath);
        foreach (XmlNode content in responseResult)
        {
            string key = GetKeyNode(content).InnerText;
            if (!key.EndsWith("_$folder$"))
            {
                // This is a file, not a folder 
                string size = GetSizeNode(content).InnerText;
                string url = (ItemHandlerPath + "?path=") + HttpUtility.UrlEncode(key);
                string fileName = VirtualPathUtility.GetFileName("/" + key);

                FileItem fileItem = new FileItem(fileName, VirtualPathUtility.GetExtension(key), int.Parse(size), string.Empty, url, string.Empty, GetPermissions(key));

                filesResult.Add(fileItem);
            }
        }

        return filesResult.ToArray();
    }

    /// <summary>
    /// Checks whether a file exists in the S3 server
    /// </summary>
    /// <param name="virtualPath">Path to file</param>
    /// <returns></returns>
    private bool IsFileExists(string virtualPath)
    {
        try
        {
            string realS3Path = VirtualPathUtility.RemoveTrailingSlash(virtualPath);
            realS3Path = SpecialUrlCharsHelperr.UrlEncode(virtualPath);

            using (ObjectGetRequest getRequest = new ObjectGetRequest(BUCKET_NAME, realS3Path))
            {
                using (ObjectGetResponse getResponse = S3Service.ObjectGet(getRequest))
                {
                    return getResponse.StatusCode != System.Net.HttpStatusCode.NotFound;
                }
            }
        }
        catch (ThreeSharpException ex)
        {
            return false;
        }
    }

    /// <summary>
    /// Checks whether a file exists in the S3 server
    /// </summary>
    /// <param name="virtualPath">Path to file</param>
    /// <returns></returns>
    public bool IsDirectoryExists(string virtualPath)
    {
        string realS3Path = VirtualPathUtility.RemoveTrailingSlash(virtualPath);
        realS3Path = SpecialUrlCharsHelperr.UrlEncode(virtualPath);
        string folderPath = VirtualPathUtility.RemoveTrailingSlash(realS3Path) + "_$folder$";

        // The code is the same;
        return IsFileExists(folderPath);
    }

    /// <summary>
    /// Copies a directory in the Amazon's server
    /// </summary>
    /// <param name="virtualSourcePath">Path to the source diredctory</param>
    /// <param name="virtualDestPath">Path to the destination directory</param>
    /// <returns></returns>
    private string S3CopyDirectory(string virtualSourcePath, string virtualDestPath)
    {
        try
        {
            string realS3SourcePath = VirtualPathUtility.RemoveTrailingSlash(virtualSourcePath);
            string realS3DestPath = VirtualPathUtility.RemoveTrailingSlash(virtualDestPath);
            realS3SourcePath = SpecialUrlCharsHelperr.UrlEncode(realS3SourcePath);
            realS3DestPath = SpecialUrlCharsHelperr.UrlEncode(realS3DestPath);
            realS3SourcePath = realS3SourcePath + "_$folder$";
            realS3DestPath = realS3DestPath + "_$folder$";

            using (ObjectCopyRequest copyRequest = new ObjectCopyRequest(BUCKET_NAME, realS3SourcePath, BUCKET_NAME, realS3DestPath))
            {
                using (ObjectCopyResponse copyResponse = S3Service.ObjectCopy(copyRequest))
                {
                }
            }

            virtualSourcePath = VirtualPathUtility.AppendTrailingSlash(virtualSourcePath);
            virtualDestPath = VirtualPathUtility.AppendTrailingSlash(virtualDestPath);
            List<XmlNode> responseResult = ListBucket(virtualSourcePath);

            foreach (XmlNode content in responseResult)
            {
                string currentElementSource = GetKeyNode(content).InnerText;

                if (IsFile(currentElementSource))
                {
                    string currentElementTarget = virtualDestPath + currentElementSource.Replace(virtualSourcePath, "");
                    string err = CopyFile(currentElementSource, currentElementTarget);
                    if (err != string.Empty)
                    {
                        return err;
                    }
                }
                else
                {
                    // Directory 
                    currentElementSource = currentElementSource.Replace("_$folder$", "");
                    currentElementSource = VirtualPathUtility.AppendTrailingSlash(currentElementSource);

                    string err = S3CopyDirectory(currentElementSource, virtualDestPath + currentElementSource.Replace(virtualSourcePath, ""));
                    if (err != string.Empty)
                    {
                        return err;
                    }
                }
            }

            return string.Empty;
        }
        catch (ThreeSharpException ex)
        {
            return "Unhandled exeption occured in 'CopyDirectory' method";
        }
    }

    private IThreeSharp S3Service
    {
        get { return service; }
    }
    #endregion
}
