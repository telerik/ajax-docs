﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] viewPaths = new string[] { "testFolder1/", "testFolder2/" };
        string[] deleteUploadPaths = new string[] { "testFolder1/NewFolder/Folder_2" };
        RadFileExplorer1.Configuration.ViewPaths = viewPaths;
        RadFileExplorer1.Configuration.DeletePaths = deleteUploadPaths;
        RadFileExplorer1.Configuration.UploadPaths = deleteUploadPaths;
        RadFileExplorer1.Configuration.ContentProviderTypeName = typeof(S3ContentProvider).AssemblyQualifiedName;
    }
}
