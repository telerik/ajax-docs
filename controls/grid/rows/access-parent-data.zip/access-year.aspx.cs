﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class access_year : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void RadGrid1_PreRender(object sender, EventArgs e)
    {

    }

    protected void RadGrid1_ItemDataBound(object sender, Telerik.Web.UI.GridItemEventArgs e)
    {
        //check which table is being bound. This is necessary in case not all tablew view contain the same data and the same data key names
        //in this example it is removed to illustrate how you can acccess data from parent tables

        //if (e.Item.OwnerTableView.Name == "Year") 
        //{
            GridDataItem item = e.Item as GridDataItem;
            if (item != null) //check item type, you need the data items only
            {
                //use the GetDataKeyValue method. Must be combined with the table view name check above
                //this will not work for detail tables, especially with different data sources
            
                //string currYear = item.GetDataKeyValue("Year").ToString();


                //use the DataItem approach, in some cases it can be used to acccess data from parent tables if they share the same fields
                //this will work only if the data item contains the same fields in all table views
                //otherwise, combine it with a check for the owner table
                
                //string currYear = DataBinder.Eval(item.DataItem, "Year").ToString(); 

                //to get data from a parent table view, you can traverse the hierarchy of the tables
                //and reach the desired table to use its GetDataKeyValue() method
                //if you are in the ItemDataBound event, you could also use the DataItem approach that is commented above as well
                string currYear = GetKeyFromTable("Year", "Year", item);

                Response.Write(string.Format("table view: {0}, current year: {1}<br />", e.Item.OwnerTableView.Name, currYear));
            }
        //}
    }

    protected string GetKeyFromTable(string key, string targetTableName, GridDataItem gridRow)
    {
        //note that this works recursively and relies on correct data being passed
        //in an actual application you may want to add defensive checks
        string data = string.Empty;
        if (gridRow.OwnerTableView.Name == targetTableName)
        {
            data = gridRow.GetDataKeyValue(key).ToString();
        }
        else if (gridRow.OwnerTableView.ParentItem != null)
        {
            data = GetKeyFromTable(key, targetTableName, gridRow.OwnerTableView.ParentItem);
        }
        return data;
    }

    protected void RadGrid1_DetailTableDataBind(object sender, Telerik.Web.UI.GridDetailTableDataBindEventArgs e)
    {
        // example check, which is ont really needed in this simplistic example but in a real app it will likely be required
        //in this case, all table views share the same data source for illustration purposes
        if (e.DetailTableView.Name == "Site" || e.DetailTableView.Name == "Surgeon" || e.DetailTableView.Name == "Service")
        {
            e.DetailTableView.DataSource = GetData();
        }
    }

    protected void RadGrid1_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
    {
        if (!e.IsFromDetailTable)
        {
            (sender as RadGrid).DataSource = GetData();
        }
    }

    protected DataTable GetData()
    {
        //note how the data in two columns matches so a correct parent-child relation can be created
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("Site", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("Service", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("Year", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("Surgeon", typeof(string)));
        tbl.Rows.Add(new object[] { 1, 1, 2017, "firstRecord4" });
        tbl.Rows.Add(new object[] { 2, 2, 2018, "secondRecord4" });
        tbl.Rows.Add(new object[] { 3, 3, 2019, "thirdRecord4" });
        tbl.Rows.Add(new object[] { 4, 4, 2020, "fourthRecord4" });

        return tbl;
    }
}