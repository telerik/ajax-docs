using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using Telerik.Web.UI;

namespace Telerik.Web.Examples.Grid.Integration.GridWithTreeViewComboBoxEditors
{
    public partial class DefaultCS : Page
    {
        protected void RadGrid1_ItemCreated(object sender, GridItemEventArgs e)
        {
            //if a grid item is in edit mode, wire the ItemsRequested event of the customersCombo to filter the items in it based on the selection in the freight combo
            if (e.Item is GridEditableItem && e.Item.IsInEditMode)
            {
                if (Page.IsCallback)
                {
                    RadComboBox customersCombo = (e.Item as GridEditableItem)["CustomerName"].Controls[0] as RadComboBox;
                    customersCombo.ItemsRequested += new RadComboBoxItemsRequestedEventHandler(customersCombo_ItemsRequested);
                }
            }
        }
        protected void RadGrid1_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridEditableItem && e.Item.IsInEditMode && (!e.Item.OwnerTableView.IsItemInserted))
            {
                //wire the OnClientSelectedIndexChanged event of the first LOD combo editor to initiate callback on item selection
                RadComboBox freightCombo = (e.Item as GridEditableItem)["Freight"].Controls[0] as RadComboBox;
                freightCombo.OnClientSelectedIndexChanged = "freightComboClientSelectedIndexChangedHandler";

                //set the selected value for the Employees combobox to match the value in the edited cell
                RadComboBox employeesCombo = (e.Item as GridEditableItem).FindControl("RadComboBox1") as RadComboBox;
                employeesCombo.Items[0].Text = DataBinder.Eval(e.Item.DataItem, "LastName").ToString();

                //set the selection in the treeview inside the combobox to match the value in the edited cell
                RadTreeView employeesTreeView = employeesCombo.Items[0].FindControl("RadTreeView1") as RadTreeView;
                employeesTreeView.FindNodeByText(DataBinder.Eval(e.Item.DataItem, "LastName").ToString()).Selected = true;
                //Expand all nodes to scroll the selected into view. Have in mind that load-on-demand is recommended with very large number of nodes in the treeview 
                employeesTreeView.ExpandAllNodes();

                //register script block which holds the client id of the employeesComboBox. Will be used to reference the client object of the combobox in the RadTreeView's OnClientNodeClicking event handler
                RadScriptManager.RegisterClientScriptBlock(this.Page, typeof(Page), "employeesComboScript", "<script type='text/javascript'>window['comboId'] = '" +  e.Item.FindControl("RadComboBox1").ClientID + "';</script>", false);

            }
            else if (e.Item is GridDataInsertItem)
            {
                //wire the OnClientSelectedIndexChanged event of the first LOD combo editor to initiate callback on item selection
                RadComboBox freightCombo = (e.Item as GridDataInsertItem)["Freight"].Controls[0] as RadComboBox;
                freightCombo.OnClientSelectedIndexChanged = "freightComboClientSelectedIndexChangedHandler";

                //register script block which holds the client id of the employeesComboBox. Will be used to reference the client object of the combobox in the RadTreeView's OnClientNodeClicking event handler
                RadScriptManager.RegisterClientScriptBlock(this.Page, typeof(Page), "employeesComboScript", "<script type='text/javascript'>window['comboId'] = '" + e.Item.FindControl("RadComboBox1").ClientID + "';</script>", false);
            }
        }
        void customersCombo_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
        {
            LoadFilteredCustomersManually(e.Text, sender as RadComboBox);
        }
        protected void LoadFilteredCustomersManually(string freight, RadComboBox customersCombo)
        {
            //if the orderID value cannot be parsed as integer(i.e. auto LOD is triggered), exit the handler
            try
            {
                System.Double.Parse(freight);
            }
            catch
            {
                return;
            }

            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["NorthwindConnectionString35"].ConnectionString);
            connection.Open();

            //select customer name based on the orderID
            SqlCommand comm = new SqlCommand("SELECT CustomerID FROM [Orders] WHERE Freight=@Freight", connection);
            comm.Parameters.AddWithValue("@Freight", freight);

            string cid = comm.ExecuteScalar().ToString();

            comm = new SqlCommand("SELECT CustomerID, ContactName from [Customers] WHERE CustomerID = '"+ cid + "'", connection);
            SqlDataAdapter adapter = new SqlDataAdapter(comm);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            //populate the customers combo with the new set of items
            customersCombo.Items.Clear();

            foreach (DataRow row in dt.Rows)
            {
                customersCombo.Items.Add(new RadComboBoxItem(row["ContactName"].ToString(), row["CustomerID"].ToString()));
            }
            connection.Close();
        }

        protected void RadGrid1_UpdateCommand(object sender, GridCommandEventArgs e)
        {
            string empId = (((e.Item as GridEditableItem).FindControl("RadComboBox1") as RadComboBox).Items[0].FindControl("RadTreeView1") as RadTreeView).SelectedNode.Value;

            //if the EmployeeID value is empty, cancel the update operation
            if(empId == string.Empty)
            {
                e.Canceled = true;
                SetMessage("Order cannot be updated. You must select an employee from the provided list");
            }
            else{
                OrdersDataSource.UpdateParameters["EmployeeID"].DefaultValue = empId;
            }
        }
        protected void RadGrid1_InsertCommand(object sender, GridCommandEventArgs e)
        {
            //if the EmployeeID value is empty, cancel the insert operation
            if((((e.Item as GridEditableItem).FindControl("RadComboBox1") as RadComboBox).Items[0].FindControl("RadTreeView1") as RadTreeView).SelectedNode == null)
            {
                e.Canceled = true;
                SetMessage("Order cannot be inserted. You must select an employee from the provided list");
            }
            else
            {
                string empId = (((e.Item as GridEditableItem).FindControl("RadComboBox1") as RadComboBox).Items[0].FindControl("RadTreeView1") as RadTreeView).SelectedNode.Value;
                OrdersDataSource.InsertParameters["EmployeeID"].DefaultValue = empId;
            }
        }
        protected void RadGrid1_ItemCommand(object sender, GridCommandEventArgs e)
        {
            //switch the edit/insert modes to ensure that only one operation will be processed at given time
            if (e.CommandName == RadGrid.EditCommandName)
            {
                e.Item.OwnerTableView.IsItemInserted = false;
            }
            else if (e.CommandName == RadGrid.InitInsertCommandName)
            {
                RadGrid1.EditIndexes.Clear();
            }

        }
        public void SetMessage(string message)
        {
            lblMessage.Text = message;
        }
}
}
