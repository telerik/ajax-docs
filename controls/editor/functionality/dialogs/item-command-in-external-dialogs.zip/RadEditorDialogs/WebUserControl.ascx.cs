﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class RadEditorDialogs_WebUserControl : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        (this.Parent.FindControl("RadFileExplorer1") as RadFileExplorer).ItemCommand += RadFileExplorer1_ItemCommand;
    }

    protected void RadFileExplorer1_ItemCommand(object sender, RadFileExplorerEventArgs e)
    {
        //NOTE: the example below is for illustrative purposes
        //You must employ strong protection according to the application logic and user actions
        bool suspiciousActivityDetected = false;
        string[] searchPatterns = (sender as RadFileExplorer).Configuration.SearchPatterns;
        if (!string.IsNullOrEmpty(e.Path))
        {
            suspiciousActivityDetected = IsSuspiciousActivity(e.Path, searchPatterns);
        }

        if (!string.IsNullOrEmpty(e.NewPath))
        {
            suspiciousActivityDetected = suspiciousActivityDetected ? suspiciousActivityDetected : IsSuspiciousActivity(e.NewPath, searchPatterns);
        }
        e.Cancel = suspiciousActivityDetected;
    }

    protected bool IsSuspiciousActivity(string pathToCheck, string[] allowedExtensions)
    {
        //this is a basic example that checks for the extensions in a simplistic manner
        //you should implement stronger logic that fits your application needs

        string currExtension = pathToCheck.Substring(pathToCheck.LastIndexOf("."));
        currExtension = string.Concat("*", currExtension);

        //add sample extensions that must never be allowed regardless of control configuration
        string[] prohibitedExtensions = { "*.aspx", "*.config" };
        //check if the operation includes prohibited files
        if (prohibitedExtensions.Contains(currExtension))
        {
            return true;
        }

        //or, simply check for the presence of potentially harmful strings in the file names, which can be useful when uploading files
        if (pathToCheck.Contains(".aspx") || pathToCheck.Contains(".config"))
        {
            return true;
        }

        //Add other high priority checks/denial conditions here

        //Then check if you can allow the action
        //For example, if the extension is whitelisted in the control configuration

        //check if the operation includes allowed files that are not covered by the prohibited extensions
        //this example deliberately does not take into account the default *.* pattern
        if (allowedExtensions.Contains(currExtension))
        {
            return false;
        }

        return false;
    }
}