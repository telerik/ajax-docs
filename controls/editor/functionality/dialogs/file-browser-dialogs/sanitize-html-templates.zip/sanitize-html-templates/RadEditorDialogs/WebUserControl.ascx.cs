﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class RadEditorDialogs_WebUserControl : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        (this.Parent.FindControl("RadFileExplorer1") as RadFileExplorer).ItemCommand += RadFileExplorer1_ItemCommand;
        //the code below sanitizies the template file after it was uploaded.
        //an alternative would be to use a custom upload handler for the RadAsyncUpload but it is harder to implement
        //https://docs.telerik.com/devtools/aspnet-ajax/controls/asyncupload/how-to/how-to-extend-the-radasyncupload-handler
        this.Page.PreRenderComplete += Page_PreRenderComplete;
    }

    private List<string> filesToTouch = new List<string>();

    protected void Page_PreRenderComplete(object sender, EventArgs e)
    {
        if (filesToTouch != null)
        {
            foreach (string fileToSanitize in filesToTouch)
            {
                string actualPath = Server.MapPath(fileToSanitize);
                string content = string.Empty;
                using (StreamReader sr = new StreamReader(actualPath))
                {
                    content = sr.ReadToEnd();
                }
                //sanitize content
                content = RemoveScriptBlocks(content);
                //overwrite the newly uploaded template file with the sanitized version
                System.IO.File.WriteAllText(actualPath, content);
            }
        }
    }

    protected void RadFileExplorer1_ItemCommand(object sender, RadFileExplorerEventArgs e)
    {
        if (e.Command == "UploadFile" && isTemplate(e.Path))
        {
            //store a list of the uploaded template paths because they are not in the file system yet
            //since this event is cancellable it fires before the files are saved to the destination
            filesToTouch.Add(e.Path);
        }
    }

    //sample sanitization that removes <script> tags
    private string RemoveScriptBlocks(string initContent)
    {
        string content = initContent;
        if (!String.IsNullOrEmpty(content))
        {
            content = Regex.Replace(content, "<(SCRIPT)([^>]*)/>", "", RegexOptions.IgnoreCase);
            content = Regex.Replace(content, "<(SCRIPT)([^>]*)>[\\s\\S]*?</(SCRIPT)([^>]*)>", "", RegexOptions.IgnoreCase);
        }
        return content;
    }

    //sample check whether a template is being uploaded because the event handler will be hit for other files
    //like images for the image manager dialog
    protected bool isTemplate(string path)
    {
        return path.EndsWith(".html") || path.EndsWith(".htm");
    }

}