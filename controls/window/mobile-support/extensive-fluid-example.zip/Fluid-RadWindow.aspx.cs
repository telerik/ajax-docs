﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Fluid_RadWindow :  System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //read more at https://docs.telerik.com/devtools/aspnet-ajax/controls/raddevicedetectionframework
        Telerik.Web.Device.Detection.DeviceScreenSize screenSize = Telerik.Web.Device.Detection.Detector.GetScreenSize(Request.UserAgent);
        if (screenSize == Telerik.Web.Device.Detection.DeviceScreenSize.Medium ||
            screenSize == Telerik.Web.Device.Detection.DeviceScreenSize.Small)
        {
            string script = "var isSmallScreen = true;";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "adaptiveWndFlag", script, true);
        }
    }
}